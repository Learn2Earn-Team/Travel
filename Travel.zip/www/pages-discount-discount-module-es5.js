(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-discount-discount-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/discount/discount.page.html":
    /*!*****************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/discount/discount.page.html ***!
      \*****************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPagesDiscountDiscountPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-content>\n    <div class=\"main_content_div\">\n\n        <ion-icon name=\"arrow-back-outline\" class=\"back_btn\" (click)=\"goToBack()\"></ion-icon>\n\n        <div class=\"flex_header\">\n            <img src=\"assets/imgs/discount.png\">\n            <ion-label>Your Discount</ion-label>\n        </div>\n\n        <ion-label class=\"grey_lbl\">We prepared some amaizing discouns for your next trips. We hope they will be useful!</ion-label>\n\n        <div class=\"grey_box\">\n            <div class=\"round_box\">\n                <img src=\"assets/imgs/booking.png\">\n            </div>\n            <div class=\"content_div\">\n                <ion-label class=\"bold_lbl\">15% hotel discount</ion-label>\n                <ion-label class=\"small_lbl\">Booking.com - Valid until 24/07</ion-label>\n            </div>\n        </div>\n\n        <div class=\"grey_box\">\n            <div class=\"round_box\">\n                <img src=\"assets/imgs/wizz.png\">\n            </div>\n            <div class=\"content_div\">\n                <ion-label class=\"bold_lbl\">50% off First Class</ion-label>\n                <ion-label class=\"small_lbl\">WizzAir - Valid until 24/07</ion-label>\n            </div>\n        </div>\n\n        <div class=\"grey_box\">\n            <div class=\"round_box\">\n                <img src=\"assets/imgs/wizz.png\">\n            </div>\n            <div class=\"content_div\">\n                <ion-label class=\"bold_lbl\">10% off all flights</ion-label>\n                <ion-label class=\"small_lbl\">WizzAir - Valid until 24/07</ion-label>\n            </div>\n        </div>\n\n    </div>\n</ion-content>\n\n<ion-footer>\n    <ion-label>Create more plans to get more discount</ion-label>\n</ion-footer>\n";
      /***/
    },

    /***/
    "./src/app/pages/discount/discount-routing.module.ts":
    /*!***********************************************************!*\
      !*** ./src/app/pages/discount/discount-routing.module.ts ***!
      \***********************************************************/

    /*! exports provided: DiscountPageRoutingModule */

    /***/
    function srcAppPagesDiscountDiscountRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "DiscountPageRoutingModule", function () {
        return DiscountPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _discount_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./discount.page */
      "./src/app/pages/discount/discount.page.ts");

      var routes = [{
        path: '',
        component: _discount_page__WEBPACK_IMPORTED_MODULE_3__["DiscountPage"]
      }];

      var DiscountPageRoutingModule = function DiscountPageRoutingModule() {
        _classCallCheck(this, DiscountPageRoutingModule);
      };

      DiscountPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], DiscountPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/pages/discount/discount.module.ts":
    /*!***************************************************!*\
      !*** ./src/app/pages/discount/discount.module.ts ***!
      \***************************************************/

    /*! exports provided: DiscountPageModule */

    /***/
    function srcAppPagesDiscountDiscountModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "DiscountPageModule", function () {
        return DiscountPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _discount_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./discount-routing.module */
      "./src/app/pages/discount/discount-routing.module.ts");
      /* harmony import */


      var _discount_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./discount.page */
      "./src/app/pages/discount/discount.page.ts");

      var DiscountPageModule = function DiscountPageModule() {
        _classCallCheck(this, DiscountPageModule);
      };

      DiscountPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _discount_routing_module__WEBPACK_IMPORTED_MODULE_5__["DiscountPageRoutingModule"]],
        declarations: [_discount_page__WEBPACK_IMPORTED_MODULE_6__["DiscountPage"]]
      })], DiscountPageModule);
      /***/
    },

    /***/
    "./src/app/pages/discount/discount.page.scss":
    /*!***************************************************!*\
      !*** ./src/app/pages/discount/discount.page.scss ***!
      \***************************************************/

    /*! exports provided: default */

    /***/
    function srcAppPagesDiscountDiscountPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-label {\n  display: block;\n}\n\n.main_content_div {\n  padding: 16px;\n  padding-top: 50px;\n}\n\n.main_content_div .back_btn {\n  font-size: 30px;\n}\n\n.main_content_div .flex_header {\n  display: flex;\n  align-items: center;\n  margin-top: 20px;\n}\n\n.main_content_div .flex_header ion-label {\n  font-size: 26px;\n  font-family: \"semi-bold\";\n  margin-left: 16px;\n}\n\n.main_content_div .flex_header img {\n  width: 25px;\n  height: 25px;\n  min-width: 25px;\n}\n\n.main_content_div .grey_lbl {\n  font-size: 15px;\n  color: grey;\n  margin-top: 10px;\n}\n\n.main_content_div .grey_box {\n  background: #f5f5f5;\n  padding: 16px;\n  margin-top: 16px;\n  display: flex;\n  align-items: center;\n}\n\n.main_content_div .grey_box .round_box {\n  height: 40px;\n  width: 40px;\n  border-radius: 50%;\n  background: lightgray;\n  position: relative;\n}\n\n.main_content_div .grey_box .round_box img {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  width: 30px;\n}\n\n.main_content_div .grey_box .content_div {\n  padding-left: 16px;\n}\n\n.main_content_div .grey_box .content_div .bold_lbl {\n  font-family: \"semi-bold\";\n  margin-bottom: 3px;\n}\n\n.main_content_div .grey_box .content_div .small_lbl {\n  font-size: 14px;\n  color: grey;\n}\n\nion-footer ion-label {\n  padding: 16px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvZGlzY291bnQvZGlzY291bnQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksY0FBQTtBQUNKOztBQUNBO0VBQ0ksYUFBQTtFQUNBLGlCQUFBO0FBRUo7O0FBQUk7RUFDSSxlQUFBO0FBRVI7O0FBQ0k7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtBQUNSOztBQUNRO0VBQ0ksZUFBQTtFQUNBLHdCQUFBO0VBQ0EsaUJBQUE7QUFDWjs7QUFDUTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtBQUNaOztBQUdJO0VBQ0ksZUFBQTtFQUNBLFdBQUE7RUFDQSxnQkFBQTtBQURSOztBQUlJO0VBQ0ksbUJBQUE7RUFDQSxhQUFBO0VBQ0EsZ0JBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7QUFGUjs7QUFJUTtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxxQkFBQTtFQUNBLGtCQUFBO0FBRlo7O0FBSVk7RUFDSSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsZ0NBQUE7RUFDQSxXQUFBO0FBRmhCOztBQU1RO0VBQ0ksa0JBQUE7QUFKWjs7QUFNWTtFQUNJLHdCQUFBO0VBQ0Esa0JBQUE7QUFKaEI7O0FBT1k7RUFDSSxlQUFBO0VBQ0EsV0FBQTtBQUxoQjs7QUFZSTtFQUNJLGFBQUE7QUFUUiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2Rpc2NvdW50L2Rpc2NvdW50LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1sYWJlbCB7XG4gICAgZGlzcGxheTogYmxvY2s7XG59XG4ubWFpbl9jb250ZW50X2RpdiB7XG4gICAgcGFkZGluZzogMTZweDtcbiAgICBwYWRkaW5nLXRvcDogNTBweDtcblxuICAgIC5iYWNrX2J0biB7XG4gICAgICAgIGZvbnQtc2l6ZTogMzBweDtcbiAgICB9XG5cbiAgICAuZmxleF9oZWFkZXIge1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICBtYXJnaW4tdG9wOiAyMHB4O1xuXG4gICAgICAgIGlvbi1sYWJlbCB7XG4gICAgICAgICAgICBmb250LXNpemU6IDI2cHg7XG4gICAgICAgICAgICBmb250LWZhbWlseTogJ3NlbWktYm9sZCc7XG4gICAgICAgICAgICBtYXJnaW4tbGVmdDogMTZweDtcbiAgICAgICAgfVxuICAgICAgICBpbWcge1xuICAgICAgICAgICAgd2lkdGg6IDI1cHg7XG4gICAgICAgICAgICBoZWlnaHQ6IDI1cHg7XG4gICAgICAgICAgICBtaW4td2lkdGg6IDI1cHg7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAuZ3JleV9sYmwge1xuICAgICAgICBmb250LXNpemU6IDE1cHg7XG4gICAgICAgIGNvbG9yOiBncmV5O1xuICAgICAgICBtYXJnaW4tdG9wOiAxMHB4O1xuICAgIH1cblxuICAgIC5ncmV5X2JveCB7XG4gICAgICAgIGJhY2tncm91bmQ6ICNmNWY1ZjU7XG4gICAgICAgIHBhZGRpbmc6IDE2cHg7XG4gICAgICAgIG1hcmdpbi10b3A6IDE2cHg7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG5cbiAgICAgICAgLnJvdW5kX2JveCB7XG4gICAgICAgICAgICBoZWlnaHQ6IDQwcHg7XG4gICAgICAgICAgICB3aWR0aDogNDBweDtcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpZ2h0Z3JheTtcbiAgICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcblxuICAgICAgICAgICAgaW1nIHtcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICAgICAgdG9wOiA1MCU7XG4gICAgICAgICAgICAgICAgbGVmdDogNTAlO1xuICAgICAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsLTUwJSk7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDMwcHg7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAuY29udGVudF9kaXYge1xuICAgICAgICAgICAgcGFkZGluZy1sZWZ0OiAxNnB4O1xuXG4gICAgICAgICAgICAuYm9sZF9sYmwge1xuICAgICAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAnc2VtaS1ib2xkJztcbiAgICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAzcHg7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC5zbWFsbF9sYmwge1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgICAgICAgICAgICBjb2xvcjogZ3JleTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn1cblxuaW9uLWZvb3RlciB7XG4gICAgaW9uLWxhYmVsIHtcbiAgICAgICAgcGFkZGluZzogMTZweDtcbiAgICB9XG59Il19 */";
      /***/
    },

    /***/
    "./src/app/pages/discount/discount.page.ts":
    /*!*************************************************!*\
      !*** ./src/app/pages/discount/discount.page.ts ***!
      \*************************************************/

    /*! exports provided: DiscountPage */

    /***/
    function srcAppPagesDiscountDiscountPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "DiscountPage", function () {
        return DiscountPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

      var DiscountPage = /*#__PURE__*/function () {
        function DiscountPage(navCrtl) {
          _classCallCheck(this, DiscountPage);

          this.navCrtl = navCrtl;
        }

        _createClass(DiscountPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "goToBack",
          value: function goToBack() {
            this.navCrtl.back();
          }
        }]);

        return DiscountPage;
      }();

      DiscountPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["NavController"]
        }];
      };

      DiscountPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
        selector: 'app-discount',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./discount.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/discount/discount.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./discount.page.scss */
        "./src/app/pages/discount/discount.page.scss"))["default"]]
      })], DiscountPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-discount-discount-module-es5.js.map