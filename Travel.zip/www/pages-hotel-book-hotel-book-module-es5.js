(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-hotel-book-hotel-book-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/hotel-book/hotel-book.page.html":
    /*!*********************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/hotel-book/hotel-book.page.html ***!
      \*********************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPagesHotelBookHotelBookPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n      <ion-button fill=\"clear\" (click)=\"goBack()\">\n          <ion-icon name=\"arrow-back\" style=\"color: black;\"></ion-icon>\n      </ion-button>\n      <ion-title>Book Hotel</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <div class=\"main_content_div\">\n        <ion-label class=\"bold_lbl\">Enter Detail</ion-label>\n\n        <ion-label class=\"simp_lbl\">Check-in</ion-label>\n        <ion-datetime display-format=\"DD/MM/YYYY\" placeholder=\"Check-in\"></ion-datetime>\n\n        <ion-label class=\"simp_lbl\">Check-out</ion-label>\n        <ion-datetime display-format=\"DD/MM/YYYY\" placeholder=\"Check-out\"></ion-datetime>\n        \n\n        <ion-label class=\"simp_lbl\">How many guest ?</ion-label>\n\n        <ion-row>\n            <ion-col size=\"6\">\n                <ion-input type=\"text\" placeholder=\"Adults\"></ion-input>\n            </ion-col>\n            <ion-col size=\"6\">\n                <ion-input type=\"text\" placeholder=\"Children\"></ion-input>\n            </ion-col>\n        </ion-row>\n\n        <ion-label class=\"simp_lbl\">How many rooms ?</ion-label>\n        <ion-input type=\"text\" placeholder=\"Rooms\"></ion-input>\n        \n\n        <ion-button (click)=\"goToPlanTrip()\" expand=\"block\" shape=\"round\">\n            Book Hotel\n        </ion-button>\n\n    </div>\n</ion-content>\n";
      /***/
    },

    /***/
    "./src/app/pages/hotel-book/hotel-book-routing.module.ts":
    /*!***************************************************************!*\
      !*** ./src/app/pages/hotel-book/hotel-book-routing.module.ts ***!
      \***************************************************************/

    /*! exports provided: HotelBookPageRoutingModule */

    /***/
    function srcAppPagesHotelBookHotelBookRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HotelBookPageRoutingModule", function () {
        return HotelBookPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _hotel_book_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./hotel-book.page */
      "./src/app/pages/hotel-book/hotel-book.page.ts");

      var routes = [{
        path: '',
        component: _hotel_book_page__WEBPACK_IMPORTED_MODULE_3__["HotelBookPage"]
      }];

      var HotelBookPageRoutingModule = function HotelBookPageRoutingModule() {
        _classCallCheck(this, HotelBookPageRoutingModule);
      };

      HotelBookPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], HotelBookPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/pages/hotel-book/hotel-book.module.ts":
    /*!*******************************************************!*\
      !*** ./src/app/pages/hotel-book/hotel-book.module.ts ***!
      \*******************************************************/

    /*! exports provided: HotelBookPageModule */

    /***/
    function srcAppPagesHotelBookHotelBookModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HotelBookPageModule", function () {
        return HotelBookPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _hotel_book_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./hotel-book-routing.module */
      "./src/app/pages/hotel-book/hotel-book-routing.module.ts");
      /* harmony import */


      var _hotel_book_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./hotel-book.page */
      "./src/app/pages/hotel-book/hotel-book.page.ts");

      var HotelBookPageModule = function HotelBookPageModule() {
        _classCallCheck(this, HotelBookPageModule);
      };

      HotelBookPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _hotel_book_routing_module__WEBPACK_IMPORTED_MODULE_5__["HotelBookPageRoutingModule"]],
        declarations: [_hotel_book_page__WEBPACK_IMPORTED_MODULE_6__["HotelBookPage"]]
      })], HotelBookPageModule);
      /***/
    },

    /***/
    "./src/app/pages/hotel-book/hotel-book.page.scss":
    /*!*******************************************************!*\
      !*** ./src/app/pages/hotel-book/hotel-book.page.scss ***!
      \*******************************************************/

    /*! exports provided: default */

    /***/
    function srcAppPagesHotelBookHotelBookPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".main_content_div {\n  padding: 16px;\n}\n.main_content_div ion-label {\n  display: block;\n}\n.main_content_div .icn_plane {\n  color: var(--ion-color-primary);\n  font-size: 30px;\n  transform: rotate(30deg);\n}\n.main_content_div .bold_lbl {\n  font-size: 18px;\n  font-family: \"semi-bold\";\n  margin-bottom: 16px;\n}\n.main_content_div .simp_lbl {\n  color: grey;\n  margin-bottom: 5px;\n  font-size: 14px;\n}\n.main_content_div ion-input, .main_content_div ion-datetime {\n  border: 1px solid lightgrey;\n  border-radius: 25px;\n  height: 48px;\n  --padding-start: 16px;\n  --padding-end: 16px;\n  margin-bottom: 20px;\n  font-family: \"semi-bold\";\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvaG90ZWwtYm9vay9ob3RlbC1ib29rLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGFBQUE7QUFDSjtBQUNJO0VBQ0ksY0FBQTtBQUNSO0FBSUk7RUFDSSwrQkFBQTtFQUNBLGVBQUE7RUFDQSx3QkFBQTtBQUZSO0FBS0k7RUFDSSxlQUFBO0VBQ0Esd0JBQUE7RUFDQSxtQkFBQTtBQUhSO0FBS0k7RUFDSSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FBSFI7QUFLSTtFQUNJLDJCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EscUJBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0Esd0JBQUE7QUFIUiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2hvdGVsLWJvb2svaG90ZWwtYm9vay5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubWFpbl9jb250ZW50X2RpdiB7XG4gICAgcGFkZGluZzogMTZweDtcblxuICAgIGlvbi1sYWJlbCB7XG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIH1cblxuICAgXG4gICAgXG4gICAgLmljbl9wbGFuZSB7XG4gICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gICAgICAgIGZvbnQtc2l6ZTogMzBweDtcbiAgICAgICAgdHJhbnNmb3JtOiByb3RhdGUoMzBkZWcpO1xuICAgIH1cblxuICAgIC5ib2xkX2xibCB7XG4gICAgICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICAgICAgZm9udC1mYW1pbHk6ICdzZW1pLWJvbGQnO1xuICAgICAgICBtYXJnaW4tYm90dG9tOiAxNnB4O1xuICAgIH1cbiAgICAuc2ltcF9sYmwge1xuICAgICAgICBjb2xvcjogZ3JleTtcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogNXB4O1xuICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgfVxuICAgIGlvbi1pbnB1dCwgaW9uLWRhdGV0aW1lIHtcbiAgICAgICAgYm9yZGVyOiAxcHggc29saWQgbGlnaHRncmV5O1xuICAgICAgICBib3JkZXItcmFkaXVzOiAyNXB4O1xuICAgICAgICBoZWlnaHQ6IDQ4cHg7XG4gICAgICAgIC0tcGFkZGluZy1zdGFydDogMTZweDtcbiAgICAgICAgLS1wYWRkaW5nLWVuZDogMTZweDtcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogMjBweDtcbiAgICAgICAgZm9udC1mYW1pbHk6ICdzZW1pLWJvbGQnO1xuICAgIH1cblxufSJdfQ== */";
      /***/
    },

    /***/
    "./src/app/pages/hotel-book/hotel-book.page.ts":
    /*!*****************************************************!*\
      !*** ./src/app/pages/hotel-book/hotel-book.page.ts ***!
      \*****************************************************/

    /*! exports provided: HotelBookPage */

    /***/
    function srcAppPagesHotelBookHotelBookPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HotelBookPage", function () {
        return HotelBookPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

      var HotelBookPage = /*#__PURE__*/function () {
        function HotelBookPage(navCtrl, router) {
          _classCallCheck(this, HotelBookPage);

          this.navCtrl = navCtrl;
          this.router = router;
        }

        _createClass(HotelBookPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "goBack",
          value: function goBack() {
            this.navCtrl.back();
          }
        }, {
          key: "goToPlanTrip",
          value: function goToPlanTrip() {
            this.router.navigate(['/trip-plan']);
          }
        }]);

        return HotelBookPage;
      }();

      HotelBookPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]
        }];
      };

      HotelBookPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-hotel-book',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./hotel-book.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/hotel-book/hotel-book.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./hotel-book.page.scss */
        "./src/app/pages/hotel-book/hotel-book.page.scss"))["default"]]
      })], HotelBookPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-hotel-book-hotel-book-module-es5.js.map