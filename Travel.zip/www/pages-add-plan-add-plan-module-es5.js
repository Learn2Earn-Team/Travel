(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-add-plan-add-plan-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-plan/add-plan.page.html":
    /*!*****************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-plan/add-plan.page.html ***!
      \*****************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPagesAddPlanAddPlanPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header mode=\"ios\" class=\"ion-no-border\">\n    <ion-toolbar>\n        <ion-buttons slot=\"start\" mode=\"md\">\n            <ion-back-button></ion-back-button>\n        </ion-buttons>\n        <ion-title>New Plan</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <div class=\"main_content_div\">\n\n        <div class=\"back_image\" [style.backgroundImage]=\"'url(assets/imgs/nature1.jpg)'\">\n            <ion-label class=\"small_lbl\">Destination</ion-label>\n            <ion-label class=\"place_lbl\">Bali, Indonesia</ion-label>\n        </div>\n\n        <div class=\"calendar_div\">\n            <ion-label class=\"bold_lbl\">Select Dates</ion-label>\n\n            <ion-calendar [(ngModel)]=\"dateRange\"\n                [options]=\"optionsRange\"\n                [type]=\"type\"\n                [format]=\"'YYYY-MM-DD'\">\n            </ion-calendar>\n\n        </div>\n\n        <ion-label class=\"bold_lbl\">Add People</ion-label>\n        <div class=\"search_flex\">\n            <ion-input type=\"text\" placeholder=\"Search people...\">\n                <ion-icon name=\"people-outline\"></ion-icon>\n            </ion-input>\n            <div class=\"option_back\">\n                <ion-icon name=\"paper-plane-outline\"></ion-icon>\n            </div>\n        </div>\n\n        <div class=\"search_flex\">\n            <ion-label>Send invites via e-mail</ion-label>\n            <ion-toggle mode=\"ios\"></ion-toggle>\n        </div>\n\n        <ion-button (click)=\"goToAddDayPlan()\" expand=\"block\" shape=\"round\">\n          Next Step\n        </ion-button>\n\n    </div>\n</ion-content>\n";
      /***/
    },

    /***/
    "./src/app/pages/add-plan/add-plan-routing.module.ts":
    /*!***********************************************************!*\
      !*** ./src/app/pages/add-plan/add-plan-routing.module.ts ***!
      \***********************************************************/

    /*! exports provided: AddPlanPageRoutingModule */

    /***/
    function srcAppPagesAddPlanAddPlanRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AddPlanPageRoutingModule", function () {
        return AddPlanPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _add_plan_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./add-plan.page */
      "./src/app/pages/add-plan/add-plan.page.ts");

      var routes = [{
        path: '',
        component: _add_plan_page__WEBPACK_IMPORTED_MODULE_3__["AddPlanPage"]
      }];

      var AddPlanPageRoutingModule = function AddPlanPageRoutingModule() {
        _classCallCheck(this, AddPlanPageRoutingModule);
      };

      AddPlanPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], AddPlanPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/pages/add-plan/add-plan.module.ts":
    /*!***************************************************!*\
      !*** ./src/app/pages/add-plan/add-plan.module.ts ***!
      \***************************************************/

    /*! exports provided: AddPlanPageModule */

    /***/
    function srcAppPagesAddPlanAddPlanModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AddPlanPageModule", function () {
        return AddPlanPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _add_plan_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./add-plan-routing.module */
      "./src/app/pages/add-plan/add-plan-routing.module.ts");
      /* harmony import */


      var _add_plan_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./add-plan.page */
      "./src/app/pages/add-plan/add-plan.page.ts");
      /* harmony import */


      var ion2_calendar__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ion2-calendar */
      "./node_modules/ion2-calendar/__ivy_ngcc__/dist/index.js");
      /* harmony import */


      var ion2_calendar__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(ion2_calendar__WEBPACK_IMPORTED_MODULE_7__);

      var AddPlanPageModule = function AddPlanPageModule() {
        _classCallCheck(this, AddPlanPageModule);
      };

      AddPlanPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _add_plan_routing_module__WEBPACK_IMPORTED_MODULE_5__["AddPlanPageRoutingModule"], ion2_calendar__WEBPACK_IMPORTED_MODULE_7__["CalendarModule"]],
        declarations: [_add_plan_page__WEBPACK_IMPORTED_MODULE_6__["AddPlanPage"]]
      })], AddPlanPageModule);
      /***/
    },

    /***/
    "./src/app/pages/add-plan/add-plan.page.scss":
    /*!***************************************************!*\
      !*** ./src/app/pages/add-plan/add-plan.page.scss ***!
      \***************************************************/

    /*! exports provided: default */

    /***/
    function srcAppPagesAddPlanAddPlanPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".main_content_div {\n  padding: 16px;\n}\n.main_content_div ion-label {\n  display: block;\n}\n.main_content_div .back_image {\n  width: 100%;\n  height: 100px;\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: cover;\n  border-radius: 5px;\n  padding: 16px;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n}\n.main_content_div .back_image .small_lbl {\n  font-size: 14px;\n  color: white;\n  margin-bottom: 5px;\n}\n.main_content_div .back_image .place_lbl {\n  font-size: 20px;\n  font-family: \"my-family\";\n  color: white;\n}\n.main_content_div .bold_lbl {\n  font-family: \"semi-bold\";\n}\n.main_content_div .calendar_div {\n  position: relative;\n  margin-top: 40px;\n}\n.main_content_div .calendar_div ion-calendar {\n  padding: 0px;\n  padding-top: 20px;\n  padding-bottom: 20px;\n}\n.main_content_div .calendar_div ion-calendar .title {\n  position: absolute !important;\n  top: -12px !important;\n  right: 0 !important;\n}\n.main_content_div .search_flex {\n  display: flex;\n  margin-top: 16px;\n  margin-bottom: 16px;\n  align-items: center;\n  justify-content: space-between;\n}\n.main_content_div .search_flex ion-input {\n  border: 1px solid lightgrey;\n  border-radius: 25px;\n  --padding-start: 8px;\n  --padding-end: 8px;\n  height: 45px;\n}\n.main_content_div .search_flex ion-input ion-icon {\n  margin-left: 16px;\n  color: gray;\n  font-size: 22px;\n}\n.main_content_div .search_flex .option_back {\n  height: 45px;\n  width: 45px;\n  border-radius: 50%;\n  background: var(--ion-color-primary);\n  position: relative;\n  margin-left: 16px;\n}\n.main_content_div .search_flex .option_back ion-icon {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  color: white;\n  font-size: 24px;\n}\nion-button {\n  letter-spacing: 0.6px;\n  text-transform: capitalize;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvYWRkLXBsYW4vYWRkLXBsYW4ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksYUFBQTtBQUNKO0FBQ0k7RUFDSSxjQUFBO0FBQ1I7QUFFSTtFQUNJLFdBQUE7RUFDQSxhQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsdUJBQUE7QUFBUjtBQUVRO0VBQ0ksZUFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQUFaO0FBR1E7RUFDSSxlQUFBO0VBQ0Esd0JBQUE7RUFDQSxZQUFBO0FBRFo7QUFLSTtFQUNJLHdCQUFBO0FBSFI7QUFNSTtFQUNJLGtCQUFBO0VBQ0EsZ0JBQUE7QUFKUjtBQU1RO0VBQ0ksWUFBQTtFQUNBLGlCQUFBO0VBQ0Esb0JBQUE7QUFKWjtBQU1ZO0VBQ0ksNkJBQUE7RUFDQSxxQkFBQTtFQUNBLG1CQUFBO0FBSmhCO0FBU0k7RUFDSSxhQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EsOEJBQUE7QUFQUjtBQVVRO0VBQ0ksMkJBQUE7RUFDQSxtQkFBQTtFQUNBLG9CQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0FBUlo7QUFVWTtFQUNJLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7QUFSaEI7QUFZUTtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxvQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7QUFWWjtBQVlZO0VBQ0ksa0JBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLGdDQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7QUFWaEI7QUFnQkE7RUFDSSxxQkFBQTtFQUNBLDBCQUFBO0FBYkoiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9hZGQtcGxhbi9hZGQtcGxhbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubWFpbl9jb250ZW50X2RpdiB7XG4gICAgcGFkZGluZzogMTZweDtcblxuICAgIGlvbi1sYWJlbCB7XG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIH1cblxuICAgIC5iYWNrX2ltYWdlIHtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIGhlaWdodDogMTAwcHg7XG4gICAgICAgIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcbiAgICAgICAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbiAgICAgICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgICAgICBwYWRkaW5nOiAxNnB4O1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcblxuICAgICAgICAuc21hbGxfbGJsIHtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDVweDtcbiAgICAgICAgfVxuXG4gICAgICAgIC5wbGFjZV9sYmwge1xuICAgICAgICAgICAgZm9udC1zaXplOiAyMHB4O1xuICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdteS1mYW1pbHknO1xuICAgICAgICAgICAgY29sb3I6IHdoaXRlO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLmJvbGRfbGJsIHtcbiAgICAgICAgZm9udC1mYW1pbHk6ICdzZW1pLWJvbGQnO1xuICAgIH1cblxuICAgIC5jYWxlbmRhcl9kaXYge1xuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgIG1hcmdpbi10b3A6IDQwcHg7XG5cbiAgICAgICAgaW9uLWNhbGVuZGFyIHtcbiAgICAgICAgICAgIHBhZGRpbmc6IDBweDtcbiAgICAgICAgICAgIHBhZGRpbmctdG9wOiAyMHB4O1xuICAgICAgICAgICAgcGFkZGluZy1ib3R0b206IDIwcHg7XG5cbiAgICAgICAgICAgIC50aXRsZSB7XG4gICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlICFpbXBvcnRhbnQ7XG4gICAgICAgICAgICAgICAgdG9wOiAtMTJweCAhaW1wb3J0YW50O1xuICAgICAgICAgICAgICAgIHJpZ2h0OiAwICFpbXBvcnRhbnQ7IFxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLnNlYXJjaF9mbGV4IHtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgbWFyZ2luLXRvcDogMTZweDtcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogMTZweDtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgICAgICAvLyBwYWRkaW5nOiAxNnB4O1xuXG4gICAgICAgIGlvbi1pbnB1dCB7XG4gICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCBsaWdodGdyZXk7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAyNXB4O1xuICAgICAgICAgICAgLS1wYWRkaW5nLXN0YXJ0OiA4cHg7XG4gICAgICAgICAgICAtLXBhZGRpbmctZW5kOiA4cHg7XG4gICAgICAgICAgICBoZWlnaHQ6IDQ1cHg7XG5cbiAgICAgICAgICAgIGlvbi1pY29uIHtcbiAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDogMTZweDtcbiAgICAgICAgICAgICAgICBjb2xvcjogZ3JheTtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDIycHg7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAub3B0aW9uX2JhY2sge1xuICAgICAgICAgICAgaGVpZ2h0OiA0NXB4O1xuICAgICAgICAgICAgd2lkdGg6IDQ1cHg7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgICAgICBtYXJnaW4tbGVmdDogMTZweDtcblxuICAgICAgICAgICAgaW9uLWljb24ge1xuICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICAgICAgICB0b3A6IDUwJTtcbiAgICAgICAgICAgICAgICBsZWZ0OiA1MCU7XG4gICAgICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwtNTAlKTtcbiAgICAgICAgICAgICAgICBjb2xvcjogd2hpdGU7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAyNHB4O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuXG5pb24tYnV0dG9uIHtcbiAgICBsZXR0ZXItc3BhY2luZzogMC42cHg7XG4gICAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XG59Il19 */";
      /***/
    },

    /***/
    "./src/app/pages/add-plan/add-plan.page.ts":
    /*!*************************************************!*\
      !*** ./src/app/pages/add-plan/add-plan.page.ts ***!
      \*************************************************/

    /*! exports provided: AddPlanPage */

    /***/
    function srcAppPagesAddPlanAddPlanPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AddPlanPage", function () {
        return AddPlanPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

      var AddPlanPage = /*#__PURE__*/function () {
        function AddPlanPage(router) {
          _classCallCheck(this, AddPlanPage);

          this.router = router;
          this.optionsRange = {
            pickMode: 'range'
          };
        }

        _createClass(AddPlanPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "goToAddDayPlan",
          value: function goToAddDayPlan() {
            this.router.navigate(['/add-day-plan']);
          }
        }]);

        return AddPlanPage;
      }();

      AddPlanPage.ctorParameters = function () {
        return [{
          type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]
        }];
      };

      AddPlanPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
        selector: 'app-add-plan',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./add-plan.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-plan/add-plan.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./add-plan.page.scss */
        "./src/app/pages/add-plan/add-plan.page.scss"))["default"]]
      })], AddPlanPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-add-plan-add-plan-module-es5.js.map