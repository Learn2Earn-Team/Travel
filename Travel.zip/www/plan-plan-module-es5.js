(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["plan-plan-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/plan/plan.page.html":
    /*!*********************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/plan/plan.page.html ***!
      \*********************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPagesPlanPlanPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header mode=\"ios\" class=\"ion-no-border\">\n    <ion-toolbar>\n        <ion-title>Oslo Trip Plan</ion-title>\n        <ion-icon slot=\"end\" name=\"options-outline\" class=\"opt_icn\"></ion-icon>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <div class=\"main_content_div\">\n\n        <div class=\"chip_flex\">\n            <div class=\"chip_div\" [class.active]=\"chipID == 1\" (click)=\"chipID = 1\">\n                <ion-label>Calendar</ion-label>\n            </div>\n            <div class=\"chip_div\" [class.active]=\"chipID == 2\" (click)=\"chipID = 2\">\n                <ion-label>Bookings</ion-label>\n            </div>\n            <div class=\"chip_div\" [class.active]=\"chipID == 3\" (click)=\"chipID = 3\">\n                <ion-label>Map</ion-label>\n            </div>\n        </div>\n\n        <div class=\"flex_div\">\n            <div class=\"inner_div\" [class.active]=\"tabID == 1\" (click)=\"tabID = 1\">\n                <ion-label class=\"bold_lbl\">Day 1</ion-label>\n                <ion-label class=\"grey_lbl\">March 21</ion-label>\n            </div>\n            <div class=\"inner_div\" [class.active]=\"tabID == 2\" (click)=\"tabID = 2\">\n                <ion-label class=\"bold_lbl\">Day 2</ion-label>\n                <ion-label class=\"grey_lbl\">March 22</ion-label>\n            </div>\n            <div class=\"inner_div\" [class.active]=\"tabID == 3\" (click)=\"tabID = 3\">\n                <ion-label class=\"bold_lbl\">Day 3</ion-label>\n                <ion-label class=\"grey_lbl\">March 23</ion-label>\n            </div>\n        </div>\n\n        <div class=\"grey_box\">\n\n            <div class=\"tracking_div\">\n\n                <div class=\"first\">\n                    <span *ngFor=\"let item of orderDetail\">\n                        <ion-label>{{item.time}}</ion-label>\n                    </span>\n                </div>\n\n                <div class=\"left\">\n                    <span *ngFor=\"let item of orderDetail\">\n                        <div class=\"line_div\" [class.line_div_darkgray]=\"item.status == 1\"></div>\n                        <div class=\"round_div_gray\" [class.round_div_red]=\"item.status == 2\"\n                            [class.round_div_darkgray]=\"item.status == 1\">\n                            <ion-icon name=\"checkmark\"></ion-icon>\n                        </div>\n                    </span>\n                </div>\n\n                <div class=\"right\">\n                    <span *ngFor=\"let item of orderDetail\" style=\"width: 100%;\">\n                        <div class=\"round_div_gray\" [class.round_div_red]=\"item.status == 2\"\n                            [class.round_div_darkgray]=\"item.status == 1\">\n                            <div class=\"content_flex\">\n                                <div>\n                                    <ion-label class=\"act_lbl\">{{item.activity}}</ion-label>\n                                    <ion-label class=\"place_lbl\">{{item.location}}</ion-label>\n                                </div>\n                                <div class=\"image_div\">\n                                    <img src=\"{{item.img}}\">\n                                </div>\n                            </div>\n                        </div>\n                    </span>\n                </div>\n\n            </div>\n\n            <ion-button expand=\"block\" shape=\"round\" class=\"light_btn\">\n                See on map\n            </ion-button>\n\n        </div>\n\n    </div>\n</ion-content>";
      /***/
    },

    /***/
    "./src/app/pages/plan/plan-routing.module.ts":
    /*!***************************************************!*\
      !*** ./src/app/pages/plan/plan-routing.module.ts ***!
      \***************************************************/

    /*! exports provided: PlanPageRoutingModule */

    /***/
    function srcAppPagesPlanPlanRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PlanPageRoutingModule", function () {
        return PlanPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _plan_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./plan.page */
      "./src/app/pages/plan/plan.page.ts");

      var routes = [{
        path: '',
        component: _plan_page__WEBPACK_IMPORTED_MODULE_3__["PlanPage"]
      }];

      var PlanPageRoutingModule = function PlanPageRoutingModule() {
        _classCallCheck(this, PlanPageRoutingModule);
      };

      PlanPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], PlanPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/pages/plan/plan.module.ts":
    /*!*******************************************!*\
      !*** ./src/app/pages/plan/plan.module.ts ***!
      \*******************************************/

    /*! exports provided: PlanPageModule */

    /***/
    function srcAppPagesPlanPlanModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PlanPageModule", function () {
        return PlanPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _plan_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./plan-routing.module */
      "./src/app/pages/plan/plan-routing.module.ts");
      /* harmony import */


      var _plan_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./plan.page */
      "./src/app/pages/plan/plan.page.ts");
      /* harmony import */


      var ion2_calendar__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ion2-calendar */
      "./node_modules/ion2-calendar/__ivy_ngcc__/dist/index.js");
      /* harmony import */


      var ion2_calendar__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(ion2_calendar__WEBPACK_IMPORTED_MODULE_7__);

      var PlanPageModule = function PlanPageModule() {
        _classCallCheck(this, PlanPageModule);
      };

      PlanPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _plan_routing_module__WEBPACK_IMPORTED_MODULE_5__["PlanPageRoutingModule"], ion2_calendar__WEBPACK_IMPORTED_MODULE_7__["CalendarModule"]],
        declarations: [_plan_page__WEBPACK_IMPORTED_MODULE_6__["PlanPage"]]
      })], PlanPageModule);
      /***/
    },

    /***/
    "./src/app/pages/plan/plan.page.scss":
    /*!*******************************************!*\
      !*** ./src/app/pages/plan/plan.page.scss ***!
      \*******************************************/

    /*! exports provided: default */

    /***/
    function srcAppPagesPlanPlanPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-header .opt_icn {\n  margin-right: 16px;\n  font-size: 24px;\n}\n\nion-content {\n  --background: #f7f7f7;\n}\n\n.main_content_div ion-label {\n  display: block;\n}\n\n.main_content_div .chip_flex {\n  background: white;\n  display: flex;\n  justify-content: space-around;\n  padding: 16px;\n}\n\n.main_content_div .chip_flex .chip_div {\n  border: 1px solid lightgrey;\n  width: 100px;\n  border-radius: 25px;\n  padding-top: 10px;\n  padding-bottom: 10px;\n}\n\n.main_content_div .chip_flex .chip_div ion-label {\n  text-align: center;\n  color: grey;\n}\n\n.main_content_div .chip_flex .active {\n  background: var(--ion-color-primary);\n}\n\n.main_content_div .chip_flex .active ion-label {\n  color: white;\n}\n\n.main_content_div .flex_div {\n  display: flex;\n  justify-content: space-around;\n  padding: 16px;\n  padding-bottom: 0px;\n  padding-top: 0px;\n  background: white;\n}\n\n.main_content_div .flex_div .inner_div {\n  padding-top: 16px;\n  padding-bottom: 16px;\n  padding-left: 10px;\n  padding-right: 10px;\n}\n\n.main_content_div .flex_div .active {\n  border-bottom: 3px solid var(--ion-color-primary);\n}\n\n.main_content_div .flex_div .bold_lbl {\n  font-family: \"semi-bold\";\n  text-align: center;\n  margin-bottom: 3px;\n}\n\n.main_content_div .flex_div .grey_lbl {\n  color: gray;\n  text-align: center;\n  font-size: 14px;\n}\n\n.main_content_div .grey_box {\n  background: #F7F7F7;\n  padding: 16px;\n}\n\n.main_content_div .grey_box .tracking_div {\n  margin-top: 30px;\n  display: flex;\n  flex-direction: row;\n}\n\n.main_content_div .grey_box .tracking_div .first {\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  width: 20px;\n  min-width: 20px;\n}\n\n.main_content_div .grey_box .tracking_div .first ion-label {\n  margin-top: 65px;\n}\n\n.main_content_div .grey_box .tracking_div .left {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  width: 100px;\n  min-width: 100px;\n}\n\n.main_content_div .grey_box .tracking_div .left .line_div {\n  height: 60px;\n  width: 4px;\n  background: linear-gradient(to bottom, var(--ion-color-primary) 0%, var(--ion-color-primary) 60%, lightgrey 50%, lightgrey 100%);\n}\n\n.main_content_div .grey_box .tracking_div .left .line_div_darkgray {\n  height: 60px;\n  width: 4px;\n  background: var(--ion-color-primary);\n}\n\n.main_content_div .grey_box .tracking_div .left .round_div_gray {\n  height: 26px;\n  width: 26px;\n  background-color: transparent;\n  border: 2px solid lightgrey;\n  border-radius: 50%;\n  margin-left: -10px;\n  position: relative;\n}\n\n.main_content_div .grey_box .tracking_div .left .round_div_gray ion-icon {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  font-size: 17px;\n  font-family: \"semi-bold\";\n  color: #f7f7f7;\n}\n\n.main_content_div .grey_box .tracking_div .left .round_div_darkgray {\n  height: 26px;\n  width: 26px;\n  background-color: var(--ion-color-primary);\n  border-radius: 50%;\n  margin-left: -10px;\n  border: 2px solid var(--ion-color-primary);\n}\n\n.main_content_div .grey_box .tracking_div .left .round_div_red {\n  height: 26px;\n  width: 26px;\n  background-color: var(--ion-color-primary);\n  border-radius: 50%;\n  margin-left: -10px;\n}\n\n.main_content_div .grey_box .tracking_div .right {\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  width: 100%;\n}\n\n.main_content_div .grey_box .tracking_div .right .content_flex {\n  padding-top: 50px;\n  display: flex;\n  justify-content: space-between;\n}\n\n.main_content_div .grey_box .tracking_div .right .content_flex .act_lbl {\n  font-family: \"semi-bold\";\n  color: black;\n}\n\n.main_content_div .grey_box .tracking_div .right .content_flex .place_lbl {\n  color: gray;\n}\n\n.main_content_div .grey_box .tracking_div .right .content_flex .image_div {\n  height: 40px;\n  width: 40px;\n  border-radius: 50%;\n  background: #ebebeb;\n  position: relative;\n}\n\n.main_content_div .grey_box .tracking_div .right .content_flex .image_div img {\n  width: 25px;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n}\n\n.main_content_div .grey_box .light_btn {\n  margin-top: 30px;\n  --background: rgba(63, 211, 161, 0.4);\n}\n\nion-footer {\n  background: #f7f7f7;\n  padding: 16px;\n}\n\nion-button {\n  letter-spacing: 0.6px;\n  text-transform: capitalize;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvcGxhbi9wbGFuLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDSTtFQUNJLGtCQUFBO0VBQ0EsZUFBQTtBQUFSOztBQUlBO0VBQ0kscUJBQUE7QUFESjs7QUFNSTtFQUNJLGNBQUE7QUFIUjs7QUFNSTtFQUNJLGlCQUFBO0VBQ0EsYUFBQTtFQUNBLDZCQUFBO0VBQ0EsYUFBQTtBQUpSOztBQU1RO0VBQ0ksMkJBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLG9CQUFBO0FBSlo7O0FBTVk7RUFDSSxrQkFBQTtFQUNBLFdBQUE7QUFKaEI7O0FBUVE7RUFDSSxvQ0FBQTtBQU5aOztBQU9ZO0VBQ0ksWUFBQTtBQUxoQjs7QUFVSTtFQUNJLGFBQUE7RUFDQSw2QkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QUFSUjs7QUFVUTtFQUNJLGlCQUFBO0VBQ0Esb0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FBUlo7O0FBV1E7RUFDSSxpREFBQTtBQVRaOztBQVlRO0VBQ0ksd0JBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FBVlo7O0FBWVE7RUFDSSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FBVlo7O0FBY0k7RUFDSSxtQkFBQTtFQUNBLGFBQUE7QUFaUjs7QUFjUTtFQUNJLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FBWlo7O0FBY1k7RUFDSSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSx1QkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0FBWmhCOztBQWNnQjtFQUNJLGdCQUFBO0FBWnBCOztBQWdCWTtFQUNJLGFBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FBZGhCOztBQWVnQjtFQUNJLFlBQUE7RUFDQSxVQUFBO0VBQ0EsZ0lBQUE7QUFicEI7O0FBc0JnQjtFQUNJLFlBQUE7RUFDQSxVQUFBO0VBQ0Esb0NBQUE7QUFwQnBCOztBQStCZ0I7RUFDSSxZQUFBO0VBQ0EsV0FBQTtFQUNBLDZCQUFBO0VBQ0EsMkJBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QUE3QnBCOztBQStCb0I7RUFDSSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsZ0NBQUE7RUFDQSxlQUFBO0VBQ0Esd0JBQUE7RUFDQSxjQUFBO0FBN0J4Qjs7QUFnQ2dCO0VBQ0ksWUFBQTtFQUNBLFdBQUE7RUFDQSwwQ0FBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSwwQ0FBQTtBQTlCcEI7O0FBZ0NnQjtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0EsMENBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FBOUJwQjs7QUFrQ1k7RUFDSSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSx1QkFBQTtFQUNBLFdBQUE7QUFoQ2hCOztBQWtDZ0I7RUFDSSxpQkFBQTtFQUNBLGFBQUE7RUFDQSw4QkFBQTtBQWhDcEI7O0FBa0NvQjtFQUNJLHdCQUFBO0VBQ0EsWUFBQTtBQWhDeEI7O0FBbUNvQjtFQUNJLFdBQUE7QUFqQ3hCOztBQW9Db0I7RUFDSSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQWxDeEI7O0FBb0N3QjtFQUNJLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsZ0NBQUE7QUFsQzVCOztBQXlDUTtFQUNJLGdCQUFBO0VBQ0EscUNBQUE7QUF2Q1o7O0FBNENBO0VBQ0ksbUJBQUE7RUFDQSxhQUFBO0FBekNKOztBQTRDQTtFQUNJLHFCQUFBO0VBQ0EsMEJBQUE7QUF6Q0oiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9wbGFuL3BsYW4ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlciB7XG4gICAgLm9wdF9pY24ge1xuICAgICAgICBtYXJnaW4tcmlnaHQ6IDE2cHg7XG4gICAgICAgIGZvbnQtc2l6ZTogMjRweDtcbiAgICB9XG59XG5cbmlvbi1jb250ZW50IHtcbiAgICAtLWJhY2tncm91bmQ6ICNmN2Y3Zjc7XG59XG5cbi5tYWluX2NvbnRlbnRfZGl2IHtcblxuICAgIGlvbi1sYWJlbCB7XG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIH1cblxuICAgIC5jaGlwX2ZsZXgge1xuICAgICAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1hcm91bmQ7XG4gICAgICAgIHBhZGRpbmc6IDE2cHg7XG4gICAgICAgIFxuICAgICAgICAuY2hpcF9kaXYge1xuICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgbGlnaHRncmV5O1xuICAgICAgICAgICAgd2lkdGg6IDEwMHB4O1xuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMjVweDtcbiAgICAgICAgICAgIHBhZGRpbmctdG9wOiAxMHB4O1xuICAgICAgICAgICAgcGFkZGluZy1ib3R0b206IDEwcHg7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIGlvbi1sYWJlbCB7XG4gICAgICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgICAgICAgICAgIGNvbG9yOiBncmV5O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLmFjdGl2ZSB7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gICAgICAgICAgICBpb24tbGFiZWwge1xuICAgICAgICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5mbGV4X2RpdiB7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYXJvdW5kO1xuICAgICAgICBwYWRkaW5nOiAxNnB4O1xuICAgICAgICBwYWRkaW5nLWJvdHRvbTogMHB4O1xuICAgICAgICBwYWRkaW5nLXRvcDogMHB4O1xuICAgICAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcblxuICAgICAgICAuaW5uZXJfZGl2IHtcbiAgICAgICAgICAgIHBhZGRpbmctdG9wOiAxNnB4O1xuICAgICAgICAgICAgcGFkZGluZy1ib3R0b206IDE2cHg7XG4gICAgICAgICAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gICAgICAgICAgICBwYWRkaW5nLXJpZ2h0OiAxMHB4O1xuICAgICAgICB9XG5cbiAgICAgICAgLmFjdGl2ZSB7XG4gICAgICAgICAgICBib3JkZXItYm90dG9tOiAzcHggc29saWQgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgICAgICB9XG5cbiAgICAgICAgLmJvbGRfbGJsIHtcbiAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAnc2VtaS1ib2xkJztcbiAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDNweDtcbiAgICAgICAgfVxuICAgICAgICAuZ3JleV9sYmwge1xuICAgICAgICAgICAgY29sb3I6IGdyYXk7XG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAuZ3JleV9ib3h7XG4gICAgICAgIGJhY2tncm91bmQ6ICNGN0Y3Rjc7XG4gICAgICAgIHBhZGRpbmc6IDE2cHg7XG4gICAgICAgIFxuICAgICAgICAudHJhY2tpbmdfZGl2e1xuICAgICAgICAgICAgbWFyZ2luLXRvcDogMzBweDtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICAgICAgICBcbiAgICAgICAgICAgIC5maXJzdCB7XG4gICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0O1xuICAgICAgICAgICAgICAgIHdpZHRoOiAyMHB4O1xuICAgICAgICAgICAgICAgIG1pbi13aWR0aDogMjBweDtcbiAgICAgICAgXG4gICAgICAgICAgICAgICAgaW9uLWxhYmVsIHtcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLXRvcDogNjVweDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICAgICAgLmxlZnR7XG4gICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDEwMHB4O1xuICAgICAgICAgICAgICAgIG1pbi13aWR0aDogMTAwcHg7XG4gICAgICAgICAgICAgICAgLmxpbmVfZGl2e1xuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDYwcHg7XG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiA0cHg7XG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudChcbiAgICAgICAgICAgICAgICAgICAgICAgIHRvIGJvdHRvbSwgXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSkgMCUsIFxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpIDYwJSwgXG4gICAgICAgICAgICAgICAgICAgICAgICBsaWdodGdyZXkgNTAlLCBcbiAgICAgICAgICAgICAgICAgICAgICAgIGxpZ2h0Z3JleSAxMDAlXG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgICAgICAgICAubGluZV9kaXZfZGFya2dyYXl7XG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogNjBweDtcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDRweDtcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgLy8gYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KFxuICAgICAgICAgICAgICAgICAgICAvLyAgICAgdG8gYm90dG9tLCBcbiAgICAgICAgICAgICAgICAgICAgLy8gICAgIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KSAwJSwgXG4gICAgICAgICAgICAgICAgICAgIC8vICAgICB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSkgNjAlLCBcbiAgICAgICAgICAgICAgICAgICAgLy8gICAgIGxpZ2h0Z3JleSA1MCUsIFxuICAgICAgICAgICAgICAgICAgICAvLyAgICAgbGlnaHRncmV5IDEwMCVcbiAgICAgICAgICAgICAgICAgICAgLy8gKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICAgICAgICAgIC5yb3VuZF9kaXZfZ3JheXtcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiAyNnB4O1xuICAgICAgICAgICAgICAgICAgICB3aWR0aDogMjZweDtcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gICAgICAgICAgICAgICAgICAgIGJvcmRlcjogMnB4IHNvbGlkIGxpZ2h0Z3JleTtcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDogLTEwcHg7XG4gICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIGlvbi1pY29uIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRvcDogNTAlO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGVmdDogNTAlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwtNTAlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTdweDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAnc2VtaS1ib2xkJztcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjZjdmN2Y3O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC5yb3VuZF9kaXZfZGFya2dyYXl7XG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogMjZweDtcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDI2cHg7XG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDogLTEwcHg7XG4gICAgICAgICAgICAgICAgICAgIGJvcmRlcjogMnB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLnJvdW5kX2Rpdl9yZWR7XG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogMjZweDtcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDI2cHg7XG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6dmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgICAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAtMTBweDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICAgICAgLnJpZ2h0e1xuICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogZmxleC1zdGFydDtcbiAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgXG4gICAgICAgICAgICAgICAgLmNvbnRlbnRfZmxleCB7XG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmctdG9wOiA1MHB4O1xuICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAuYWN0X2xibCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb250LWZhbWlseTogJ3NlbWktYm9sZCc7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogYmxhY2s7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAucGxhY2VfbGJsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBncmF5O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAuaW1hZ2VfZGl2IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogNDBweDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOiA0MHB4O1xuICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogI2ViZWJlYjtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgICAgICBpbWcge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOiAyNXB4O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3A6IDUwJTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZWZ0OiA1MCU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwtNTAlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC5saWdodF9idG57XG4gICAgICAgICAgICBtYXJnaW4tdG9wOiAzMHB4O1xuICAgICAgICAgICAgLS1iYWNrZ3JvdW5kOiByZ2JhKDYzLCAyMTEsIDE2MSwgMC40KTtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuaW9uLWZvb3RlciB7XG4gICAgYmFja2dyb3VuZDogI2Y3ZjdmNztcbiAgICBwYWRkaW5nOiAxNnB4O1xufVxuXG5pb24tYnV0dG9uIHtcbiAgICBsZXR0ZXItc3BhY2luZzogMC42cHg7XG4gICAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XG59Il19 */";
      /***/
    },

    /***/
    "./src/app/pages/plan/plan.page.ts":
    /*!*****************************************!*\
      !*** ./src/app/pages/plan/plan.page.ts ***!
      \*****************************************/

    /*! exports provided: PlanPage */

    /***/
    function srcAppPagesPlanPlanPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PlanPage", function () {
        return PlanPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

      var PlanPage = /*#__PURE__*/function () {
        function PlanPage() {
          _classCallCheck(this, PlanPage);

          this.chipID = 1;
          this.tabID = 1;
          this.orderDetail = [{
            status: 1,
            time: '05:30',
            activity: 'Trekking',
            location: 'Lofoten',
            img: 'assets/imgs/surfer.png'
          }, {
            status: 1,
            time: '07:00',
            activity: 'Breakfast',
            location: 'at the Hotel',
            img: 'assets/imgs/breakfast.png'
          }, {
            status: 1,
            time: '08:30',
            activity: 'Surfing',
            location: 'on the Lake',
            img: 'assets/imgs/surfer.png'
          }, {
            status: 0,
            time: '11:30',
            activity: 'Taking Some rest',
            location: 'at the Hotel',
            img: 'assets/imgs/bed.png'
          }];
        }

        _createClass(PlanPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return PlanPage;
      }();

      PlanPage.ctorParameters = function () {
        return [];
      };

      PlanPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-plan',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./plan.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/plan/plan.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./plan.page.scss */
        "./src/app/pages/plan/plan.page.scss"))["default"]]
      })], PlanPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=plan-plan-module-es5.js.map