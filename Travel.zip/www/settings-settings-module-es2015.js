(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["settings-settings-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/settings/settings.page.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/settings/settings.page.html ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\n    <div class=\"main_content_div\">\n\n        <ion-label class=\"title_lbl\">Your Preferences</ion-label>\n\n        <div class=\"main_div\">\n            <div class=\"user_div\" [style.backgroundImage]=\"'url(assets/imgs/user.jpg)'\"></div>\n            <div class=\"detail_div\">\n                <ion-label class=\"bold_lbl\">Adam</ion-label>\n                <ion-label class=\"grey_lbl\">Photographer</ion-label>\n            </div>\n            <ion-button shape=\"round\" size=\"small\" class=\"edit_profile\" (click)=\"goToEditProfile()\">\n                Edit Profile\n            </ion-button>\n        </div>\n\n        <div class=\"main_div\" (click)=\"goToCards()\">\n            <div class=\"grey_div\">\n                <ion-icon name=\"wallet\"></ion-icon>\n            </div>\n            <div class=\"detail_div\">\n                <ion-label class=\"bold_lbl\">Payment Method</ion-label>\n                <ion-label class=\"grey_lbl\">Manage your cards</ion-label>\n            </div>\n            <ion-icon name=\"arrow-forward\" class=\"next_arrow\"></ion-icon>\n        </div>\n\n        <div class=\"main_div\" (click)=\"goToDiscount()\">\n            <div class=\"grey_div\">\n                <ion-icon name=\"wallet\"></ion-icon>\n            </div>\n            <div class=\"detail_div\">\n                <ion-label class=\"bold_lbl\">Discounts</ion-label>\n                <ion-label class=\"grey_lbl\">Check out your discounts</ion-label>\n            </div>\n            <ion-icon name=\"arrow-forward\" class=\"next_arrow\"></ion-icon>\n        </div>\n\n        <div class=\"main_div\" (click)=\"goToNotification()\">\n            <div class=\"grey_div\">\n                <ion-icon name=\"notifications\"></ion-icon>\n            </div>\n            <div class=\"detail_div\">\n                <ion-label class=\"bold_lbl\">Notifications</ion-label>\n                <ion-label class=\"grey_lbl\">Notification preferences</ion-label>\n            </div>\n            <ion-icon name=\"arrow-forward\" class=\"next_arrow\"></ion-icon>\n        </div>\n\n        <div class=\"main_div\" (click)=\"goToTimezone()\">\n            <div class=\"grey_div\">\n                <ion-icon name=\"time\"></ion-icon>\n            </div>\n            <div class=\"detail_div\">\n                <ion-label class=\"bold_lbl\">Time Zone</ion-label>\n                <ion-label class=\"grey_lbl\">Change your time zone</ion-label>\n            </div>\n            <ion-icon name=\"arrow-forward\" class=\"next_arrow\"></ion-icon>\n        </div>\n\n        <div class=\"logout_div\" (click)=\"logout()\">\n            <ion-icon name=\"exit\"></ion-icon>\n            <ion-label>Logout</ion-label>\n        </div>\n\n    </div>\n</ion-content>");

/***/ }),

/***/ "./src/app/pages/settings/settings-routing.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/pages/settings/settings-routing.module.ts ***!
  \***********************************************************/
/*! exports provided: SettingsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsPageRoutingModule", function() { return SettingsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _settings_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./settings.page */ "./src/app/pages/settings/settings.page.ts");




const routes = [
    {
        path: '',
        component: _settings_page__WEBPACK_IMPORTED_MODULE_3__["SettingsPage"]
    }
];
let SettingsPageRoutingModule = class SettingsPageRoutingModule {
};
SettingsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SettingsPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/settings/settings.module.ts":
/*!***************************************************!*\
  !*** ./src/app/pages/settings/settings.module.ts ***!
  \***************************************************/
/*! exports provided: SettingsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsPageModule", function() { return SettingsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _settings_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./settings-routing.module */ "./src/app/pages/settings/settings-routing.module.ts");
/* harmony import */ var _settings_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./settings.page */ "./src/app/pages/settings/settings.page.ts");







let SettingsPageModule = class SettingsPageModule {
};
SettingsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _settings_routing_module__WEBPACK_IMPORTED_MODULE_5__["SettingsPageRoutingModule"]
        ],
        declarations: [_settings_page__WEBPACK_IMPORTED_MODULE_6__["SettingsPage"]]
    })
], SettingsPageModule);



/***/ }),

/***/ "./src/app/pages/settings/settings.page.scss":
/*!***************************************************!*\
  !*** ./src/app/pages/settings/settings.page.scss ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-label {\n  display: block;\n}\n\n.main_content_div {\n  padding: 16px;\n  padding-top: 50px;\n}\n\n.main_content_div .title_lbl {\n  font-size: 26px;\n  font-family: \"semi-bold\";\n}\n\n.main_content_div .main_div {\n  border-bottom: 1px solid lightgrey;\n  padding: 20px 0px;\n  display: flex;\n  align-items: center;\n  position: relative;\n}\n\n.main_content_div .main_div .user_div {\n  height: 45px;\n  width: 45px;\n  border-radius: 50%;\n  background-position: center;\n  background-size: cover;\n  background-repeat: no-repeat;\n}\n\n.main_content_div .main_div .edit_profile {\n  --background: rgba(63, 211, 161, 0.4);\n}\n\n.main_content_div .main_div .grey_div {\n  height: 45px;\n  width: 45px;\n  background: #f3f3f3;\n  border-radius: 50%;\n  position: relative;\n}\n\n.main_content_div .main_div .grey_div ion-icon {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n}\n\n.main_content_div .main_div .detail_div {\n  padding-left: 16px;\n}\n\n.main_content_div .main_div .detail_div .bold_lbl {\n  font-family: \"semi-bold\";\n  font-size: 15px;\n  margin-bottom: 3px;\n}\n\n.main_content_div .main_div .detail_div .grey_lbl {\n  font-size: 14px;\n  color: grey;\n}\n\n.main_content_div .main_div .next_arrow {\n  position: absolute;\n  right: 0;\n  color: grey;\n  font-size: 20px;\n}\n\n.main_content_div .main_div ion-button {\n  position: absolute;\n  right: 0;\n  margin: 0;\n  height: 30px;\n  width: 100px;\n}\n\n.main_content_div .logout_div {\n  margin-top: 20px;\n  display: flex;\n  align-items: center;\n  color: red;\n}\n\n.main_content_div .logout_div ion-icon {\n  font-size: 20px;\n}\n\n.main_content_div .logout_div ion-label {\n  margin-left: 16px;\n  font-family: \"semi-bold\";\n  color: red;\n}\n\nion-button {\n  letter-spacing: 0.6px;\n  text-transform: capitalize;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvc2V0dGluZ3Mvc2V0dGluZ3MucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksY0FBQTtBQUNKOztBQUNBO0VBQ0ksYUFBQTtFQUNBLGlCQUFBO0FBRUo7O0FBQUk7RUFDSSxlQUFBO0VBQ0Esd0JBQUE7QUFFUjs7QUFDSTtFQUNJLGtDQUFBO0VBQ0EsaUJBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQUNSOztBQUNRO0VBQ0ksWUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLDJCQUFBO0VBQ0Esc0JBQUE7RUFDQSw0QkFBQTtBQUNaOztBQUVRO0VBQ0kscUNBQUE7QUFBWjs7QUFHUTtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FBRFo7O0FBR1k7RUFDSSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsZ0NBQUE7QUFEaEI7O0FBS1E7RUFDSSxrQkFBQTtBQUhaOztBQUtZO0VBQ0ksd0JBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7QUFIaEI7O0FBTVk7RUFDSSxlQUFBO0VBQ0EsV0FBQTtBQUpoQjs7QUFRUTtFQUNJLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0FBTlo7O0FBU1E7RUFDSSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7QUFQWjs7QUFXSTtFQUNJLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsVUFBQTtBQVRSOztBQVdRO0VBQ0ksZUFBQTtBQVRaOztBQVdRO0VBQ0ksaUJBQUE7RUFDQSx3QkFBQTtFQUNBLFVBQUE7QUFUWjs7QUFjQTtFQUNJLHFCQUFBO0VBQ0EsMEJBQUE7QUFYSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3NldHRpbmdzL3NldHRpbmdzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1sYWJlbCB7XG4gICAgZGlzcGxheTogYmxvY2s7XG59XG4ubWFpbl9jb250ZW50X2RpdiB7XG4gICAgcGFkZGluZzogMTZweDtcbiAgICBwYWRkaW5nLXRvcDogNTBweDtcblxuICAgIC50aXRsZV9sYmwge1xuICAgICAgICBmb250LXNpemU6IDI2cHg7XG4gICAgICAgIGZvbnQtZmFtaWx5OiAnc2VtaS1ib2xkJztcbiAgICB9XG5cbiAgICAubWFpbl9kaXYge1xuICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgbGlnaHRncmV5O1xuICAgICAgICBwYWRkaW5nOiAyMHB4IDBweDtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuXG4gICAgICAgIC51c2VyX2RpdiB7XG4gICAgICAgICAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgICAgICAgICB3aWR0aDogNDVweDtcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICAgICAgICAgIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcbiAgICAgICAgICAgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICAgICAgICB9XG5cbiAgICAgICAgLmVkaXRfcHJvZmlsZSB7XG4gICAgICAgICAgICAtLWJhY2tncm91bmQ6IHJnYmEoNjMsIDIxMSwgMTYxLCAwLjQpO1xuICAgICAgICB9XG5cbiAgICAgICAgLmdyZXlfZGl2IHtcbiAgICAgICAgICAgIGhlaWdodDogNDVweDtcbiAgICAgICAgICAgIHdpZHRoOiA0NXB4O1xuICAgICAgICAgICAgYmFja2dyb3VuZDogI2YzZjNmMztcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcblxuICAgICAgICAgICAgaW9uLWljb24ge1xuICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICAgICAgICB0b3A6IDUwJTtcbiAgICAgICAgICAgICAgICBsZWZ0OiA1MCU7XG4gICAgICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwtNTAlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC5kZXRhaWxfZGl2IHtcbiAgICAgICAgICAgIHBhZGRpbmctbGVmdDogMTZweDtcblxuICAgICAgICAgICAgLmJvbGRfbGJsIHtcbiAgICAgICAgICAgICAgICBmb250LWZhbWlseTogJ3NlbWktYm9sZCc7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNXB4O1xuICAgICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDNweDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLmdyZXlfbGJsIHtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgICAgICAgICAgY29sb3I6IGdyZXk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAubmV4dF9hcnJvdyB7XG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICByaWdodDogMDtcbiAgICAgICAgICAgIGNvbG9yOiBncmV5O1xuICAgICAgICAgICAgZm9udC1zaXplOiAyMHB4O1xuICAgICAgICB9XG5cbiAgICAgICAgaW9uLWJ1dHRvbiB7XG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICByaWdodDogMDtcbiAgICAgICAgICAgIG1hcmdpbjogMDtcbiAgICAgICAgICAgIGhlaWdodDogMzBweDtcbiAgICAgICAgICAgIHdpZHRoOiAxMDBweDtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5sb2dvdXRfZGl2IHtcbiAgICAgICAgbWFyZ2luLXRvcDogMjBweDtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgY29sb3I6IHJlZDtcblxuICAgICAgICBpb24taWNvbiB7XG4gICAgICAgICAgICBmb250LXNpemU6IDIwcHg7XG4gICAgICAgIH1cbiAgICAgICAgaW9uLWxhYmVsIHtcbiAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAxNnB4O1xuICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdzZW1pLWJvbGQnO1xuICAgICAgICAgICAgY29sb3I6IHJlZDtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuaW9uLWJ1dHRvbiB7XG4gICAgbGV0dGVyLXNwYWNpbmc6IDAuNnB4O1xuICAgIHRleHQtdHJhbnNmb3JtOiBjYXBpdGFsaXplO1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/pages/settings/settings.page.ts":
/*!*************************************************!*\
  !*** ./src/app/pages/settings/settings.page.ts ***!
  \*************************************************/
/*! exports provided: SettingsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsPage", function() { return SettingsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _change_timezone_change_timezone_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../change-timezone/change-timezone.page */ "./src/app/pages/change-timezone/change-timezone.page.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");





let SettingsPage = class SettingsPage {
    constructor(router, modalCtrl) {
        this.router = router;
        this.modalCtrl = modalCtrl;
    }
    ngOnInit() {
    }
    goToDiscount() {
        this.router.navigate(['/discount']);
    }
    goToEditProfile() {
        this.router.navigate(['/edit-profile']);
    }
    goToCards() {
        this.router.navigate(['/card-list']);
    }
    goToNotification() {
        this.router.navigate(['/notification']);
    }
    goToTimezone() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _change_timezone_change_timezone_page__WEBPACK_IMPORTED_MODULE_1__["ChangeTimezonePage"],
                cssClass: 'custom-modal'
            });
            return yield modal.present();
        });
    }
    logout() {
        this.router.navigate(['/']);
    }
};
SettingsPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] }
];
SettingsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-settings',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./settings.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/settings/settings.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./settings.page.scss */ "./src/app/pages/settings/settings.page.scss")).default]
    })
], SettingsPage);



/***/ })

}]);
//# sourceMappingURL=settings-settings-module-es2015.js.map