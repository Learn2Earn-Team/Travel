(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-place-detail-place-detail-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/place-detail/place-detail.page.html":
    /*!*************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/place-detail/place-detail.page.html ***!
      \*************************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPagesPlaceDetailPlaceDetailPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-content>\n    <div class=\"main_content_div\" [style.background-image]=\"'url(assets/imgs/nature3.jpg)'\">\n\n      <ion-icon name=\"arrow-back-outline\" class=\"back_btn\" (click)=\"goToBack()\"></ion-icon>\n      \n      <div class=\"flex_div\">\n          <ion-label class=\"place_name\">Bali, Indonesia</ion-label>\n          <ion-label class=\"desc_lbl\">\n            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Beatae id assumenda ipsum \n            asperiores aspernatur nulla commodi alias quos sunt eius quod possimus cupiditate \n            libero et nobis perferendis, nemo dolor molestias.\n          </ion-label>\n\n          <div class=\"rate_flex\">\n              <div style=\"display: flex;align-items: center;\">\n                  <ion-rating [rate]=\"rate\" readonly=\"false\" size=\"small\" (rateChange)=\"onRateChange($event)\"></ion-rating>\n                  <ion-label style=\"margin-left: 5px;\">4.9(32 Reviews)</ion-label>\n              </div>\n              <ion-label>See Reviews</ion-label>\n          </div>\n\n          <ion-grid>\n            <ion-row>\n              <ion-col size=\"6\">\n                  <ion-button class=\"more_btn\" expand=\"block\" fill=\"clear\" shape=\"round\">\n                    Read More\n                  </ion-button>\n              </ion-col>\n              <ion-col size=\"6\">\n                  <ion-button class=\"trip_btn\" expand=\"block\" fill=\"clear\" shape=\"round\" (click)=\"goToPlanTrip()\">\n                    Plan Trip\n                  </ion-button>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n\n      </div>\n    \n    </div>\n</ion-content>\n";
      /***/
    },

    /***/
    "./src/app/pages/place-detail/place-detail-routing.module.ts":
    /*!*******************************************************************!*\
      !*** ./src/app/pages/place-detail/place-detail-routing.module.ts ***!
      \*******************************************************************/

    /*! exports provided: PlaceDetailPageRoutingModule */

    /***/
    function srcAppPagesPlaceDetailPlaceDetailRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PlaceDetailPageRoutingModule", function () {
        return PlaceDetailPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _place_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./place-detail.page */
      "./src/app/pages/place-detail/place-detail.page.ts");

      var routes = [{
        path: '',
        component: _place_detail_page__WEBPACK_IMPORTED_MODULE_3__["PlaceDetailPage"]
      }];

      var PlaceDetailPageRoutingModule = function PlaceDetailPageRoutingModule() {
        _classCallCheck(this, PlaceDetailPageRoutingModule);
      };

      PlaceDetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], PlaceDetailPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/pages/place-detail/place-detail.module.ts":
    /*!***********************************************************!*\
      !*** ./src/app/pages/place-detail/place-detail.module.ts ***!
      \***********************************************************/

    /*! exports provided: PlaceDetailPageModule */

    /***/
    function srcAppPagesPlaceDetailPlaceDetailModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PlaceDetailPageModule", function () {
        return PlaceDetailPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _place_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./place-detail-routing.module */
      "./src/app/pages/place-detail/place-detail-routing.module.ts");
      /* harmony import */


      var _place_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./place-detail.page */
      "./src/app/pages/place-detail/place-detail.page.ts");
      /* harmony import */


      var ionic_rating__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ionic-rating */
      "./node_modules/ionic-rating/__ivy_ngcc__/fesm2015/ionic-rating.js");

      var PlaceDetailPageModule = function PlaceDetailPageModule() {
        _classCallCheck(this, PlaceDetailPageModule);
      };

      PlaceDetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _place_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__["PlaceDetailPageRoutingModule"], ionic_rating__WEBPACK_IMPORTED_MODULE_7__["IonicRatingModule"]],
        declarations: [_place_detail_page__WEBPACK_IMPORTED_MODULE_6__["PlaceDetailPage"]]
      })], PlaceDetailPageModule);
      /***/
    },

    /***/
    "./src/app/pages/place-detail/place-detail.page.scss":
    /*!***********************************************************!*\
      !*** ./src/app/pages/place-detail/place-detail.page.scss ***!
      \***********************************************************/

    /*! exports provided: default */

    /***/
    function srcAppPagesPlaceDetailPlaceDetailPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".main_content_div {\n  width: 100%;\n  height: 100%;\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: cover;\n}\n.main_content_div ion-label {\n  display: block;\n}\n.main_content_div .back_btn {\n  font-size: 30px;\n  color: white;\n  margin-left: 16px;\n  margin-top: 40px;\n}\n.main_content_div .flex_div {\n  padding: 16px;\n  position: absolute;\n  bottom: 0px;\n}\n.main_content_div .flex_div .place_name {\n  font-size: 30px;\n  color: white;\n  font-family: \"my-family\";\n}\n.main_content_div .flex_div .desc_lbl {\n  font-size: 14px;\n  color: white;\n}\n.main_content_div .rate_flex {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  font-size: 14px;\n  color: white;\n}\n.main_content_div .rate_flex ion-button {\n  margin: 0px;\n}\n.main_content_div ion-grid {\n  padding: 0;\n}\n.main_content_div .more_btn {\n  --background: rgba(0,0,0,0.5);\n  color: white;\n  margin: 0;\n}\n.main_content_div .trip_btn {\n  --background: white;\n  color: black;\n  margin: 0;\n}\nion-rating {\n  --color: blue;\n  --color-filled: green;\n}\nion-button {\n  letter-spacing: 0.6px;\n  text-transform: capitalize;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvcGxhY2UtZGV0YWlsL3BsYWNlLWRldGFpbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7RUFDQSxzQkFBQTtBQUNKO0FBQ0k7RUFDSSxjQUFBO0FBQ1I7QUFFSTtFQUNJLGVBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtBQUFSO0FBR0k7RUFDSSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0FBRFI7QUFHUTtFQUNJLGVBQUE7RUFDQSxZQUFBO0VBQ0Esd0JBQUE7QUFEWjtBQUdRO0VBQ0ksZUFBQTtFQUNBLFlBQUE7QUFEWjtBQUtJO0VBQ0ksYUFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtBQUhSO0FBS1E7RUFDSSxXQUFBO0FBSFo7QUFPSTtFQUNJLFVBQUE7QUFMUjtBQVFJO0VBQ0ksNkJBQUE7RUFDQSxZQUFBO0VBQ0EsU0FBQTtBQU5SO0FBU0k7RUFDSSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxTQUFBO0FBUFI7QUFXQTtFQUNJLGFBQUE7RUFDQSxxQkFBQTtBQVJKO0FBV0E7RUFDSSxxQkFBQTtFQUNBLDBCQUFBO0FBUkoiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9wbGFjZS1kZXRhaWwvcGxhY2UtZGV0YWlsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tYWluX2NvbnRlbnRfZGl2IHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcblxuICAgIGlvbi1sYWJlbCB7XG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIH1cblxuICAgIC5iYWNrX2J0bntcbiAgICAgICAgZm9udC1zaXplOiAzMHB4O1xuICAgICAgICBjb2xvcjogd2hpdGU7XG4gICAgICAgIG1hcmdpbi1sZWZ0OiAxNnB4O1xuICAgICAgICBtYXJnaW4tdG9wOiA0MHB4O1xuICAgIH1cblxuICAgIC5mbGV4X2RpdiB7XG4gICAgICAgIHBhZGRpbmc6IDE2cHg7XG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgYm90dG9tOiAwcHg7XG5cbiAgICAgICAgLnBsYWNlX25hbWUge1xuICAgICAgICAgICAgZm9udC1zaXplOiAzMHB4O1xuICAgICAgICAgICAgY29sb3I6IHdoaXRlO1xuICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdteS1mYW1pbHknO1xuICAgICAgICB9XG4gICAgICAgIC5kZXNjX2xibCB7XG4gICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgICAgICBjb2xvcjogd2hpdGU7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAucmF0ZV9mbGV4IHtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgIGNvbG9yOiB3aGl0ZTsgXG5cbiAgICAgICAgaW9uLWJ1dHRvbiB7XG4gICAgICAgICAgICBtYXJnaW46IDBweDtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGlvbi1ncmlkIHtcbiAgICAgICAgcGFkZGluZzogMDtcbiAgICB9XG5cbiAgICAubW9yZV9idG4ge1xuICAgICAgICAtLWJhY2tncm91bmQ6IHJnYmEoMCwwLDAsMC41KTtcbiAgICAgICAgY29sb3I6IHdoaXRlO1xuICAgICAgICBtYXJnaW46IDA7XG4gICAgfVxuXG4gICAgLnRyaXBfYnRuIHtcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgICAgICAgY29sb3I6IGJsYWNrO1xuICAgICAgICBtYXJnaW46IDA7XG4gICAgfVxufVxuXG5pb24tcmF0aW5nIHtcbiAgICAtLWNvbG9yOiBibHVlO1xuICAgIC0tY29sb3ItZmlsbGVkOiBncmVlbjtcbn1cblxuaW9uLWJ1dHRvbiB7XG4gICAgbGV0dGVyLXNwYWNpbmc6IDAuNnB4O1xuICAgIHRleHQtdHJhbnNmb3JtOiBjYXBpdGFsaXplO1xufSJdfQ== */";
      /***/
    },

    /***/
    "./src/app/pages/place-detail/place-detail.page.ts":
    /*!*********************************************************!*\
      !*** ./src/app/pages/place-detail/place-detail.page.ts ***!
      \*********************************************************/

    /*! exports provided: PlaceDetailPage */

    /***/
    function srcAppPagesPlaceDetailPlaceDetailPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PlaceDetailPage", function () {
        return PlaceDetailPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

      var PlaceDetailPage = /*#__PURE__*/function () {
        function PlaceDetailPage(router, navCrtl) {
          _classCallCheck(this, PlaceDetailPage);

          this.router = router;
          this.navCrtl = navCrtl;
          this.rate = 4;
        }

        _createClass(PlaceDetailPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "onRateChange",
          value: function onRateChange(eve) {
            console.log(eve);
          }
        }, {
          key: "goToPlanTrip",
          value: function goToPlanTrip() {
            this.router.navigate(['/trip-plan']);
          }
        }, {
          key: "goToBack",
          value: function goToBack() {
            this.navCrtl.back();
          }
        }]);

        return PlaceDetailPage;
      }();

      PlaceDetailPage.ctorParameters = function () {
        return [{
          type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["NavController"]
        }];
      };

      PlaceDetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-place-detail',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./place-detail.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/place-detail/place-detail.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./place-detail.page.scss */
        "./src/app/pages/place-detail/place-detail.page.scss"))["default"]]
      })], PlaceDetailPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-place-detail-place-detail-module-es5.js.map