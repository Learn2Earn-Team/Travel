(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-add-day-plan-add-day-plan-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-day-plan/add-day-plan.page.html":
    /*!*************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-day-plan/add-day-plan.page.html ***!
      \*************************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPagesAddDayPlanAddDayPlanPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header mode=\"ios\" class=\"ion-no-border\">\n    <ion-toolbar>\n        <ion-buttons slot=\"start\" mode=\"md\">\n            <ion-back-button></ion-back-button>\n        </ion-buttons>\n        <ion-title>Add Day Plan</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <div class=\"main_content_div\">\n        <div class=\"flex_div\">\n            <div class=\"inner_div\" [class.active]=\"tabID == 1\" (click)=\"tabID = 1\">\n                <ion-label class=\"bold_lbl\">Day 1</ion-label>\n                <ion-label class=\"grey_lbl\">March 21</ion-label>\n            </div>\n            <div class=\"inner_div\" [class.active]=\"tabID == 2\" (click)=\"tabID = 2\">\n                <ion-label class=\"bold_lbl\">Day 2</ion-label>\n                <ion-label class=\"grey_lbl\">March 22</ion-label>\n            </div>\n            <div class=\"inner_div\" [class.active]=\"tabID == 3\" (click)=\"tabID = 3\">\n                <ion-label class=\"bold_lbl\">Day 3</ion-label>\n                <ion-label class=\"grey_lbl\">March 23</ion-label>\n            </div>\n        </div>\n\n        <div class=\"grey_div\">\n\n            <div class=\"inner_flex\" *ngFor=\"let item of activity\">\n                <div class=\"watch_div\">\n                  <ion-icon name=\"time-outline\"></ion-icon>\n                  <ion-label>{{item.time}}</ion-label>\n                </div>\n                <div class=\"activity_div\">\n                    <ion-label>{{item.name}}</ion-label>\n                    <div class=\"image_div\">\n                        <img src=\"{{item.img}}\">\n                    </div>\n                </div>\n            </div>\n\n            <ion-button expand=\"block\" shape=\"round\" class=\"light_btn\" (click)=\"goToAddActivity()\">\n                Add Activity\n            </ion-button>\n\n        </div>\n\n    </div>\n</ion-content>\n\n<ion-footer>\n    <ion-button expand=\"block\" shape=\"round\" (click)=\"goToHotelFlight()\">\n      Next Step\n    </ion-button>\n</ion-footer>\n";
      /***/
    },

    /***/
    "./src/app/pages/add-day-plan/add-day-plan-routing.module.ts":
    /*!*******************************************************************!*\
      !*** ./src/app/pages/add-day-plan/add-day-plan-routing.module.ts ***!
      \*******************************************************************/

    /*! exports provided: AddDayPlanPageRoutingModule */

    /***/
    function srcAppPagesAddDayPlanAddDayPlanRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AddDayPlanPageRoutingModule", function () {
        return AddDayPlanPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _add_day_plan_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./add-day-plan.page */
      "./src/app/pages/add-day-plan/add-day-plan.page.ts");

      var routes = [{
        path: '',
        component: _add_day_plan_page__WEBPACK_IMPORTED_MODULE_3__["AddDayPlanPage"]
      }];

      var AddDayPlanPageRoutingModule = function AddDayPlanPageRoutingModule() {
        _classCallCheck(this, AddDayPlanPageRoutingModule);
      };

      AddDayPlanPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], AddDayPlanPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/pages/add-day-plan/add-day-plan.module.ts":
    /*!***********************************************************!*\
      !*** ./src/app/pages/add-day-plan/add-day-plan.module.ts ***!
      \***********************************************************/

    /*! exports provided: AddDayPlanPageModule */

    /***/
    function srcAppPagesAddDayPlanAddDayPlanModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AddDayPlanPageModule", function () {
        return AddDayPlanPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _add_day_plan_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./add-day-plan-routing.module */
      "./src/app/pages/add-day-plan/add-day-plan-routing.module.ts");
      /* harmony import */


      var _add_day_plan_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./add-day-plan.page */
      "./src/app/pages/add-day-plan/add-day-plan.page.ts");

      var AddDayPlanPageModule = function AddDayPlanPageModule() {
        _classCallCheck(this, AddDayPlanPageModule);
      };

      AddDayPlanPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _add_day_plan_routing_module__WEBPACK_IMPORTED_MODULE_5__["AddDayPlanPageRoutingModule"]],
        declarations: [_add_day_plan_page__WEBPACK_IMPORTED_MODULE_6__["AddDayPlanPage"]]
      })], AddDayPlanPageModule);
      /***/
    },

    /***/
    "./src/app/pages/add-day-plan/add-day-plan.page.scss":
    /*!***********************************************************!*\
      !*** ./src/app/pages/add-day-plan/add-day-plan.page.scss ***!
      \***********************************************************/

    /*! exports provided: default */

    /***/
    function srcAppPagesAddDayPlanAddDayPlanPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-content {\n  --background: #f7f7f7;\n}\n\n.main_content_div ion-label {\n  display: block;\n}\n\n.main_content_div .flex_div {\n  display: flex;\n  justify-content: space-around;\n  padding: 16px;\n  padding-bottom: 0px;\n  background: white;\n}\n\n.main_content_div .flex_div .inner_div {\n  padding-top: 16px;\n  padding-bottom: 16px;\n  padding-left: 10px;\n  padding-right: 10px;\n}\n\n.main_content_div .flex_div .active {\n  border-bottom: 3px solid var(--ion-color-primary);\n}\n\n.main_content_div .flex_div .bold_lbl {\n  font-family: \"semi-bold\";\n  text-align: center;\n  margin-bottom: 3px;\n}\n\n.main_content_div .flex_div .grey_lbl {\n  color: gray;\n  text-align: center;\n  font-size: 14px;\n}\n\n.main_content_div .grey_div {\n  padding: 16px;\n  background: #f7f7f7;\n}\n\n.main_content_div .grey_div .inner_flex {\n  display: flex;\n  margin-bottom: 16px;\n}\n\n.main_content_div .grey_div .inner_flex .watch_div {\n  border: 1px solid lightgrey;\n  border-radius: 25px;\n  display: flex;\n  align-items: center;\n  height: 50px;\n  padding-left: 15px;\n  padding-right: 15px;\n}\n\n.main_content_div .grey_div .inner_flex .watch_div ion-icon {\n  color: grey;\n}\n\n.main_content_div .grey_div .inner_flex .watch_div ion-label {\n  margin-left: 10px;\n}\n\n.main_content_div .grey_div .inner_flex .activity_div {\n  margin-left: 16px;\n  height: 50px;\n  padding-left: 10px;\n  padding-right: 5px;\n  border: 1px solid lightgrey;\n  border-radius: 25px;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  width: 100%;\n}\n\n.main_content_div .grey_div .inner_flex .activity_div .image_div {\n  height: 40px;\n  width: 40px;\n  border-radius: 50%;\n  background: #ebebeb;\n  position: relative;\n}\n\n.main_content_div .grey_div .inner_flex .activity_div .image_div img {\n  width: 25px;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n}\n\n.main_content_div .grey_div .light_btn {\n  --background: rgba(63, 211, 161, 0.4);\n}\n\nion-footer {\n  background: #f7f7f7;\n  padding: 16px;\n}\n\nion-button {\n  letter-spacing: 0.6px;\n  text-transform: capitalize;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvYWRkLWRheS1wbGFuL2FkZC1kYXktcGxhbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxxQkFBQTtBQUNKOztBQUdJO0VBQ0ksY0FBQTtBQUFSOztBQUdJO0VBQ0ksYUFBQTtFQUNBLDZCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7QUFEUjs7QUFHUTtFQUNJLGlCQUFBO0VBQ0Esb0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FBRFo7O0FBSVE7RUFDSSxpREFBQTtBQUZaOztBQUtRO0VBQ0ksd0JBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FBSFo7O0FBS1E7RUFDSSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FBSFo7O0FBT0k7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7QUFMUjs7QUFPUTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtBQUxaOztBQU9ZO0VBQ0ksMkJBQUE7RUFDQSxtQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FBTGhCOztBQU9nQjtFQUNJLFdBQUE7QUFMcEI7O0FBUWdCO0VBQ0ksaUJBQUE7QUFOcEI7O0FBVVk7RUFDSSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsMkJBQUE7RUFDQSxtQkFBQTtFQUNBLGFBQUE7RUFDQSw4QkFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtBQVJoQjs7QUFVZ0I7RUFDSSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQVJwQjs7QUFVb0I7RUFDSSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLGdDQUFBO0FBUnhCOztBQWNRO0VBQ0kscUNBQUE7QUFaWjs7QUFpQkE7RUFDSSxtQkFBQTtFQUNBLGFBQUE7QUFkSjs7QUFpQkE7RUFDSSxxQkFBQTtFQUNBLDBCQUFBO0FBZEoiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9hZGQtZGF5LXBsYW4vYWRkLWRheS1wbGFuLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50IHtcbiAgICAtLWJhY2tncm91bmQ6ICNmN2Y3Zjc7XG59XG4ubWFpbl9jb250ZW50X2RpdiB7XG5cbiAgICBpb24tbGFiZWwge1xuICAgICAgICBkaXNwbGF5OiBibG9jaztcbiAgICB9XG5cbiAgICAuZmxleF9kaXYge1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWFyb3VuZDtcbiAgICAgICAgcGFkZGluZzogMTZweDtcbiAgICAgICAgcGFkZGluZy1ib3R0b206IDBweDtcbiAgICAgICAgYmFja2dyb3VuZDogd2hpdGU7XG5cbiAgICAgICAgLmlubmVyX2RpdiB7XG4gICAgICAgICAgICBwYWRkaW5nLXRvcDogMTZweDtcbiAgICAgICAgICAgIHBhZGRpbmctYm90dG9tOiAxNnB4O1xuICAgICAgICAgICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICAgICAgICAgICAgcGFkZGluZy1yaWdodDogMTBweDtcbiAgICAgICAgfVxuXG4gICAgICAgIC5hY3RpdmUge1xuICAgICAgICAgICAgYm9yZGVyLWJvdHRvbTogM3B4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgICAgICAgfVxuXG4gICAgICAgIC5ib2xkX2xibCB7XG4gICAgICAgICAgICBmb250LWZhbWlseTogJ3NlbWktYm9sZCc7XG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAzcHg7XG4gICAgICAgIH1cbiAgICAgICAgLmdyZXlfbGJsIHtcbiAgICAgICAgICAgIGNvbG9yOiBncmF5O1xuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLmdyZXlfZGl2IHtcbiAgICAgICAgcGFkZGluZzogMTZweDtcbiAgICAgICAgYmFja2dyb3VuZDogI2Y3ZjdmNztcblxuICAgICAgICAuaW5uZXJfZmxleCB7XG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMTZweDtcblxuICAgICAgICAgICAgLndhdGNoX2RpdiB7XG4gICAgICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgbGlnaHRncmV5O1xuICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDI1cHg7XG4gICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgICAgIGhlaWdodDogNTBweDtcbiAgICAgICAgICAgICAgICBwYWRkaW5nLWxlZnQ6IDE1cHg7XG4gICAgICAgICAgICAgICAgcGFkZGluZy1yaWdodDogMTVweDtcblxuICAgICAgICAgICAgICAgIGlvbi1pY29uIHtcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6IGdyZXk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgaW9uLWxhYmVsIHtcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAuYWN0aXZpdHlfZGl2IHtcbiAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDogMTZweDtcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDUwcHg7XG4gICAgICAgICAgICAgICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICAgICAgICAgICAgICAgIHBhZGRpbmctcmlnaHQ6IDVweDtcbiAgICAgICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCBsaWdodGdyZXk7XG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMjVweDtcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuXG4gICAgICAgICAgICAgICAgLmltYWdlX2RpdiB7XG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogNDBweDtcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDQwcHg7XG4gICAgICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogI2ViZWJlYjtcbiAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuXG4gICAgICAgICAgICAgICAgICAgIGltZyB7XG4gICAgICAgICAgICAgICAgICAgICAgICB3aWR0aDogMjVweDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRvcDogNTAlO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGVmdDogNTAlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwtNTAlKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC5saWdodF9idG57XG4gICAgICAgICAgICAtLWJhY2tncm91bmQ6IHJnYmEoNjMsIDIxMSwgMTYxLCAwLjQpO1xuICAgICAgICB9XG4gICAgfVxufVxuXG5pb24tZm9vdGVyIHtcbiAgICBiYWNrZ3JvdW5kOiAjZjdmN2Y3O1xuICAgIHBhZGRpbmc6IDE2cHg7XG59XG5cbmlvbi1idXR0b24ge1xuICAgIGxldHRlci1zcGFjaW5nOiAwLjZweDtcbiAgICB0ZXh0LXRyYW5zZm9ybTogY2FwaXRhbGl6ZTtcbn0iXX0= */";
      /***/
    },

    /***/
    "./src/app/pages/add-day-plan/add-day-plan.page.ts":
    /*!*********************************************************!*\
      !*** ./src/app/pages/add-day-plan/add-day-plan.page.ts ***!
      \*********************************************************/

    /*! exports provided: AddDayPlanPage */

    /***/
    function srcAppPagesAddDayPlanAddDayPlanPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AddDayPlanPage", function () {
        return AddDayPlanPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _add_activity_add_activity_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./../add-activity/add-activity.page */
      "./src/app/pages/add-activity/add-activity.page.ts");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

      var AddDayPlanPage = /*#__PURE__*/function () {
        function AddDayPlanPage(router, modalCtrl) {
          _classCallCheck(this, AddDayPlanPage);

          this.router = router;
          this.modalCtrl = modalCtrl;
          this.activity = [{
            time: '05:30',
            name: 'Wake up',
            img: 'assets/imgs/bed.png'
          }, {
            time: '06:00',
            name: 'Breakfast',
            img: 'assets/imgs/breakfast.png'
          }, {
            time: '07:00',
            name: 'Surfing',
            img: 'assets/imgs/surfer.png'
          }, {
            time: '09:30',
            name: 'Sunbathing',
            img: 'assets/imgs/sunny.png'
          }];
          this.tabID = 1;
        }

        _createClass(AddDayPlanPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "goToHotelFlight",
          value: function goToHotelFlight() {
            this.router.navigate(['/add-hotel-flight']);
          }
        }, {
          key: "goToAddActivity",
          value: function goToAddActivity() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var modal;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.modalCtrl.create({
                        component: _add_activity_add_activity_page__WEBPACK_IMPORTED_MODULE_1__["AddActivityPage"],
                        cssClass: 'custom-modal'
                      });

                    case 2:
                      modal = _context.sent;
                      _context.next = 5;
                      return modal.present();

                    case 5:
                      return _context.abrupt("return", _context.sent);

                    case 6:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }]);

        return AddDayPlanPage;
      }();

      AddDayPlanPage.ctorParameters = function () {
        return [{
          type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"]
        }];
      };

      AddDayPlanPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-add-day-plan',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./add-day-plan.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-day-plan/add-day-plan.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./add-day-plan.page.scss */
        "./src/app/pages/add-day-plan/add-day-plan.page.scss"))["default"]]
      })], AddDayPlanPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-add-day-plan-add-day-plan-module-es5.js.map