(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-hotel-detail-hotel-detail-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/hotel-detail/hotel-detail.page.html":
    /*!*************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/hotel-detail/hotel-detail.page.html ***!
      \*************************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPagesHotelDetailHotelDetailPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-content>\n  <div class=\"main_content_div\">\n\n      <div class=\"back_image\" [style.backgroundImage]=\"'url(assets/imgs/nature1.jpg)'\">  \n          <ion-icon name=\"arrow-back-outline\" (click)=\"goBack()\"></ion-icon>\n      </div>\n\n      <div class=\"white_div\">\n\n        <ion-label class=\"head_lbl\">About Hanging Garden Bali Hotel</ion-label>\n\n        <ion-label class=\"detail_lbl\">\n            Lorem ipsum dolor sit amet, consectetur adipisicing elit. \n            Cum commodi maxime dolore saepe adipisci perspiciatis quo, quidem hic iusto \n            tempore odit eveniet illum minima esse nulla \n            voluptates, natus itaque doloribus?\n        </ion-label>\n\n        <div class=\"flex_div\" style=\"margin-top: 20px;\">\n            <div class=\"inner_div\">\n                <ion-label class=\"grey_lbl\">Price</ion-label>\n                <ion-label class=\"bold_lbl\">$400</ion-label>\n            </div>\n            <div  class=\"inner_div\">\n                <ion-label class=\"grey_lbl\">Ratings</ion-label>\n                <ion-label class=\"star_lbl\">\n                  <ion-icon name=\"star\"></ion-icon>\n                  <ion-icon name=\"star\"></ion-icon>\n                  <ion-icon name=\"star\"></ion-icon>\n                  <ion-icon name=\"star\"></ion-icon>\n                  <ion-icon name=\"star\"></ion-icon>\n                    <span>(4.9)</span>\n                </ion-label>\n            </div>\n        </div>\n\n        <ion-label class=\"head_lbl\">Amenities</ion-label>\n\n        <div class=\"flex_div\">\n            <div class=\"light_box\">\n                <ion-icon name=\"bed\"></ion-icon>\n            </div>\n            <div class=\"light_box\">\n                <ion-icon name=\"wifi\"></ion-icon>\n            </div>\n            <div class=\"light_box\">\n                <ion-icon name=\"fast-food\"></ion-icon>\n            </div>\n            <div class=\"light_box\">\n                <ion-icon name=\"beer\"></ion-icon>\n            </div>\n            <div class=\"light_box\">\n                <ion-icon name=\"beer\"></ion-icon>\n            </div>\n        </div>\n\n        <ion-button expand=\"block\" shape=\"round\" (click)=\"goToHotelBook()\">\n            Book Hotel\n        </ion-button>\n      </div>\n\n  </div>\n</ion-content>\n";
      /***/
    },

    /***/
    "./src/app/pages/hotel-detail/hotel-detail-routing.module.ts":
    /*!*******************************************************************!*\
      !*** ./src/app/pages/hotel-detail/hotel-detail-routing.module.ts ***!
      \*******************************************************************/

    /*! exports provided: HotelDetailPageRoutingModule */

    /***/
    function srcAppPagesHotelDetailHotelDetailRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HotelDetailPageRoutingModule", function () {
        return HotelDetailPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _hotel_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./hotel-detail.page */
      "./src/app/pages/hotel-detail/hotel-detail.page.ts");

      var routes = [{
        path: '',
        component: _hotel_detail_page__WEBPACK_IMPORTED_MODULE_3__["HotelDetailPage"]
      }];

      var HotelDetailPageRoutingModule = function HotelDetailPageRoutingModule() {
        _classCallCheck(this, HotelDetailPageRoutingModule);
      };

      HotelDetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], HotelDetailPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/pages/hotel-detail/hotel-detail.module.ts":
    /*!***********************************************************!*\
      !*** ./src/app/pages/hotel-detail/hotel-detail.module.ts ***!
      \***********************************************************/

    /*! exports provided: HotelDetailPageModule */

    /***/
    function srcAppPagesHotelDetailHotelDetailModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HotelDetailPageModule", function () {
        return HotelDetailPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _hotel_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./hotel-detail-routing.module */
      "./src/app/pages/hotel-detail/hotel-detail-routing.module.ts");
      /* harmony import */


      var _hotel_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./hotel-detail.page */
      "./src/app/pages/hotel-detail/hotel-detail.page.ts");

      var HotelDetailPageModule = function HotelDetailPageModule() {
        _classCallCheck(this, HotelDetailPageModule);
      };

      HotelDetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _hotel_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__["HotelDetailPageRoutingModule"]],
        declarations: [_hotel_detail_page__WEBPACK_IMPORTED_MODULE_6__["HotelDetailPage"]]
      })], HotelDetailPageModule);
      /***/
    },

    /***/
    "./src/app/pages/hotel-detail/hotel-detail.page.scss":
    /*!***********************************************************!*\
      !*** ./src/app/pages/hotel-detail/hotel-detail.page.scss ***!
      \***********************************************************/

    /*! exports provided: default */

    /***/
    function srcAppPagesHotelDetailHotelDetailPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-content {\n  --background: white;\n}\n\n.main_content_div {\n  width: 100%;\n}\n\n.main_content_div ion-label {\n  display: block;\n}\n\n.main_content_div .back_image {\n  width: 100%;\n  height: 40vh;\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: cover;\n  position: relative;\n}\n\n.main_content_div .back_image ion-icon {\n  margin-left: 16px;\n  margin-top: 50px;\n  font-size: 30px;\n  color: white;\n}\n\n.main_content_div .white_div {\n  width: 100%;\n  padding: 16px;\n  border-top-left-radius: 35px;\n  border-top-right-radius: 35px;\n  margin-top: -30px;\n  position: fixed;\n  overflow: scroll;\n  background: white;\n  height: 60vh;\n  z-index: 999;\n}\n\n.main_content_div .white_div .head_lbl {\n  font-family: \"semi-bold\";\n  font-size: 18px;\n  margin-top: 15px;\n  margin-bottom: 16px;\n}\n\n.main_content_div .white_div .detail_lbl {\n  font-size: 15px;\n  color: grey;\n}\n\n.main_content_div .white_div .flex_div {\n  display: flex;\n  align-items: center;\n}\n\n.main_content_div .white_div .flex_div .light_box {\n  height: 50px;\n  width: 50px;\n  border-radius: 3px;\n  background: #f3f3f3;\n  position: relative;\n  margin-right: 16px;\n}\n\n.main_content_div .white_div .flex_div .light_box ion-icon {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  color: var(--ion-color-primary);\n  font-size: 20px;\n}\n\n.main_content_div .white_div .flex_div .inner_div {\n  margin-right: 20px;\n}\n\n.main_content_div .white_div .flex_div .inner_div .grey_lbl {\n  font-size: 14px;\n  color: grey;\n}\n\n.main_content_div .white_div .flex_div .inner_div .bold_lbl {\n  font-family: \"semi-bold\";\n}\n\n.main_content_div .white_div .flex_div .inner_div .star_lbl {\n  color: orange;\n  display: flex;\n  margin-top: 5px;\n}\n\n.main_content_div .white_div .flex_div .inner_div .star_lbl ion-icon {\n  margin-right: 1px;\n}\n\n.main_content_div ion-button {\n  margin-top: 20px;\n}\n\nion-button {\n  letter-spacing: 0.6px;\n  text-transform: capitalize;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvaG90ZWwtZGV0YWlsL2hvdGVsLWRldGFpbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSSxtQkFBQTtBQUFKOztBQUVBO0VBQ0ksV0FBQTtBQUNKOztBQUNJO0VBQ0ksY0FBQTtBQUNSOztBQUVJO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtBQUFSOztBQUVRO0VBQ0ksaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0FBQVo7O0FBSUk7RUFDSSxXQUFBO0VBQ0EsYUFBQTtFQUNBLDRCQUFBO0VBQ0EsNkJBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUVBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7QUFIUjs7QUFLUTtFQUNJLHdCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7QUFIWjs7QUFNUTtFQUNJLGVBQUE7RUFDQSxXQUFBO0FBSlo7O0FBT1E7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7QUFMWjs7QUFPWTtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QUFMaEI7O0FBT2dCO0VBQ0ksa0JBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLGdDQUFBO0VBQ0EsK0JBQUE7RUFDQSxlQUFBO0FBTHBCOztBQVNZO0VBQ0ksa0JBQUE7QUFQaEI7O0FBU2dCO0VBQ0ksZUFBQTtFQUNBLFdBQUE7QUFQcEI7O0FBU2dCO0VBQ0ksd0JBQUE7QUFQcEI7O0FBVWdCO0VBQ0ksYUFBQTtFQUNBLGFBQUE7RUFDQSxlQUFBO0FBUnBCOztBQVVvQjtFQUNJLGlCQUFBO0FBUnhCOztBQW1CSTtFQUNJLGdCQUFBO0FBakJSOztBQXFCQTtFQUNJLHFCQUFBO0VBQ0EsMEJBQUE7QUFsQkoiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9ob3RlbC1kZXRhaWwvaG90ZWwtZGV0YWlsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50e1xuICAgIC8vIC0tYmFja2dyb3VuZDogI0VGRjBGNTtcbiAgICAtLWJhY2tncm91bmQ6IHdoaXRlO1xufVxuLm1haW5fY29udGVudF9kaXZ7XG4gICAgd2lkdGg6IDEwMCU7XG5cbiAgICBpb24tbGFiZWwge1xuICAgICAgICBkaXNwbGF5OiBibG9jaztcbiAgICB9XG5cbiAgICAuYmFja19pbWFnZXtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIGhlaWdodDogNDB2aDtcbiAgICAgICAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xuICAgICAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICAgICAgICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG5cbiAgICAgICAgaW9uLWljb24ge1xuICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDE2cHg7XG4gICAgICAgICAgICBtYXJnaW4tdG9wOiA1MHB4O1xuICAgICAgICAgICAgZm9udC1zaXplOiAzMHB4O1xuICAgICAgICAgICAgY29sb3I6IHdoaXRlO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLndoaXRlX2RpdntcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIHBhZGRpbmc6IDE2cHg7XG4gICAgICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDM1cHg7XG4gICAgICAgIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAzNXB4O1xuICAgICAgICBtYXJnaW4tdG9wOiAtMzBweDtcbiAgICAgICAgcG9zaXRpb246IGZpeGVkO1xuICAgICAgICBvdmVyZmxvdzogc2Nyb2xsO1xuICAgICAgICAvLyBiYWNrZ3JvdW5kOiAjRUZGMEY1O1xuICAgICAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgICAgICAgaGVpZ2h0OiA2MHZoO1xuICAgICAgICB6LWluZGV4OiA5OTk7XG5cbiAgICAgICAgLmhlYWRfbGJse1xuICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdzZW1pLWJvbGQnO1xuICAgICAgICAgICAgZm9udC1zaXplOiAxOHB4O1xuICAgICAgICAgICAgbWFyZ2luLXRvcDogMTVweDtcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDE2cHg7XG4gICAgICAgIH1cblxuICAgICAgICAuZGV0YWlsX2xibHtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTVweDtcbiAgICAgICAgICAgIGNvbG9yOiBncmV5O1xuICAgICAgICB9XG5cbiAgICAgICAgLmZsZXhfZGl2IHtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuXG4gICAgICAgICAgICAubGlnaHRfYm94IHtcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDUwcHg7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDUwcHg7XG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogM3B4O1xuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICNmM2YzZjM7XG4gICAgICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTZweDtcblxuICAgICAgICAgICAgICAgIGlvbi1pY29uIHtcbiAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgICAgICAgICB0b3A6IDUwJTtcbiAgICAgICAgICAgICAgICAgICAgbGVmdDogNTAlO1xuICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLC01MCUpO1xuICAgICAgICAgICAgICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDIwcHg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAuaW5uZXJfZGl2IHtcbiAgICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDIwcHg7XG5cbiAgICAgICAgICAgICAgICAuZ3JleV9sYmwge1xuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiBncmV5O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAuYm9sZF9sYmwge1xuICAgICAgICAgICAgICAgICAgICBmb250LWZhbWlseTogJ3NlbWktYm9sZCc7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgLnN0YXJfbGJsIHtcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6IG9yYW5nZTtcbiAgICAgICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLXRvcDogNXB4O1xuXG4gICAgICAgICAgICAgICAgICAgIGlvbi1pY29uIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMXB4O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBcbiAgICAgICAgfVxuXG4gICAgXG4gICAgfVxuXG4gICAgaW9uLWJ1dHRvbiB7XG4gICAgICAgIG1hcmdpbi10b3A6IDIwcHg7XG4gICAgfVxufVxuXG5pb24tYnV0dG9uIHtcbiAgICBsZXR0ZXItc3BhY2luZzogMC42cHg7XG4gICAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XG59Il19 */";
      /***/
    },

    /***/
    "./src/app/pages/hotel-detail/hotel-detail.page.ts":
    /*!*********************************************************!*\
      !*** ./src/app/pages/hotel-detail/hotel-detail.page.ts ***!
      \*********************************************************/

    /*! exports provided: HotelDetailPage */

    /***/
    function srcAppPagesHotelDetailHotelDetailPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HotelDetailPage", function () {
        return HotelDetailPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

      var HotelDetailPage = /*#__PURE__*/function () {
        function HotelDetailPage(navCtrl, router) {
          _classCallCheck(this, HotelDetailPage);

          this.navCtrl = navCtrl;
          this.router = router;
        }

        _createClass(HotelDetailPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "goBack",
          value: function goBack() {
            this.navCtrl.back();
          }
        }, {
          key: "goToHotelBook",
          value: function goToHotelBook() {
            this.router.navigate(['/hotel-book']);
          }
        }]);

        return HotelDetailPage;
      }();

      HotelDetailPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]
        }];
      };

      HotelDetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-hotel-detail',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./hotel-detail.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/hotel-detail/hotel-detail.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./hotel-detail.page.scss */
        "./src/app/pages/hotel-detail/hotel-detail.page.scss"))["default"]]
      })], HotelDetailPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-hotel-detail-hotel-detail-module-es5.js.map