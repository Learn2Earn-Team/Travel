(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-add-hotel-flight-add-hotel-flight-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-hotel-flight/add-hotel-flight.page.html":
/*!*********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-hotel-flight/add-hotel-flight.page.html ***!
  \*********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header mode=\"ios\" class=\"ion-no-border\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\" mode=\"md\">\n        <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>Add Hotel and Flight</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <div class=\"main_content_div\">\n        \n        <ion-label class=\"bold_lbl\">Hotel</ion-label>\n        <div class=\"back_image\" [style.backgroundImage]=\"'url(assets/imgs/nature1.jpg)'\">\n            <ion-label class=\"place_lbl\">Hanging Gardens of Bali Hotel</ion-label>\n            <div class=\"star_flex\">\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n            </div>\n        </div>\n\n        <ion-label class=\"bold_lbl\">Flights</ion-label>\n        <div class=\"flight_flex\">\n\n            <div class=\"grey_flex\">\n                <div class=\"round_div\">\n                    <img src=\"assets/imgs/us.png\">\n                </div>\n                <ion-label class=\"loc_lbl\">LAX</ion-label>\n                <ion-label class=\"date\">20.03, 06:00 AM</ion-label>\n                <div class=\"ticket_flex\">\n                  <ion-icon name=\"ticket\"></ion-icon>\n                  <ion-label>First Class</ion-label>\n                </div>\n            </div>\n\n            <ion-icon name=\"arrow-forward\" class=\"forward_icn\"></ion-icon>\n\n            <div class=\"grey_flex\">\n                <div class=\"round_div\">\n                    <img src=\"assets/imgs/in.png\">\n                </div>\n                <ion-label class=\"loc_lbl\">DPS</ion-label>\n                <ion-label class=\"date\">20.03, 06:00 AM</ion-label>\n                <div class=\"ticket_flex\">\n                  <ion-icon name=\"ticket\"></ion-icon>\n                  <ion-label>First Class</ion-label>\n                </div>\n            </div>\n\n        </div>\n\n        <ion-label class=\"bold_lbl\">Costs</ion-label>\n\n        <div class=\"cost_flex\">\n            <ion-label>Hotel (4 Nights)</ion-label>\n            <div class=\"dash_div\">\n                <ion-label>----------------------------------------------------------</ion-label>\n            </div>\n            <ion-label class=\"green_lbl\">$765</ion-label>\n        </div>\n\n        <div class=\"cost_flex\">\n            <ion-label>Flights</ion-label>\n            <div class=\"dash_div\">\n              <ion-label>----------------------------------------------------------</ion-label>\n            </div>\n            <ion-label class=\"green_lbl\">$754</ion-label>\n        </div>\n\n        <div class=\"cost_flex\">\n            <ion-label>Total</ion-label>\n            <div class=\"dash_div\">\n                <ion-label>----------------------------------------------------------</ion-label>\n            </div>\n            <ion-label class=\"green_lbl\">$1519</ion-label>\n        </div>\n\n    </div>\n</ion-content>\n\n<ion-footer>\n    <ion-button expand=\"block\" shape=\"round\" (click)=\"goToHome()\">\n        Create trip plan\n    </ion-button>\n</ion-footer>\n");

/***/ }),

/***/ "./src/app/pages/add-hotel-flight/add-hotel-flight-routing.module.ts":
/*!***************************************************************************!*\
  !*** ./src/app/pages/add-hotel-flight/add-hotel-flight-routing.module.ts ***!
  \***************************************************************************/
/*! exports provided: AddHotelFlightPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddHotelFlightPageRoutingModule", function() { return AddHotelFlightPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _add_hotel_flight_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./add-hotel-flight.page */ "./src/app/pages/add-hotel-flight/add-hotel-flight.page.ts");




const routes = [
    {
        path: '',
        component: _add_hotel_flight_page__WEBPACK_IMPORTED_MODULE_3__["AddHotelFlightPage"]
    }
];
let AddHotelFlightPageRoutingModule = class AddHotelFlightPageRoutingModule {
};
AddHotelFlightPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AddHotelFlightPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/add-hotel-flight/add-hotel-flight.module.ts":
/*!*******************************************************************!*\
  !*** ./src/app/pages/add-hotel-flight/add-hotel-flight.module.ts ***!
  \*******************************************************************/
/*! exports provided: AddHotelFlightPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddHotelFlightPageModule", function() { return AddHotelFlightPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _add_hotel_flight_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./add-hotel-flight-routing.module */ "./src/app/pages/add-hotel-flight/add-hotel-flight-routing.module.ts");
/* harmony import */ var _add_hotel_flight_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./add-hotel-flight.page */ "./src/app/pages/add-hotel-flight/add-hotel-flight.page.ts");







let AddHotelFlightPageModule = class AddHotelFlightPageModule {
};
AddHotelFlightPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _add_hotel_flight_routing_module__WEBPACK_IMPORTED_MODULE_5__["AddHotelFlightPageRoutingModule"]
        ],
        declarations: [_add_hotel_flight_page__WEBPACK_IMPORTED_MODULE_6__["AddHotelFlightPage"]]
    })
], AddHotelFlightPageModule);



/***/ }),

/***/ "./src/app/pages/add-hotel-flight/add-hotel-flight.page.scss":
/*!*******************************************************************!*\
  !*** ./src/app/pages/add-hotel-flight/add-hotel-flight.page.scss ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".main_content_div {\n  padding: 16px;\n}\n.main_content_div ion-label {\n  display: block;\n}\n.main_content_div .bold_lbl {\n  font-family: \"semi-bold\";\n  margin-top: 40px;\n  margin-bottom: 10px;\n}\n.main_content_div .back_image {\n  width: 100%;\n  height: 100px;\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: cover;\n  border-radius: 5px;\n  padding: 16px;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n}\n.main_content_div .back_image .place_lbl {\n  font-size: 16px;\n  font-family: \"semi-bold\";\n  color: white;\n}\n.main_content_div .back_image .star_flex {\n  display: flex;\n  color: orange;\n  margin-top: 10px;\n  margin-bottom: 10px;\n}\n.main_content_div .back_image .star_flex ion-icon {\n  margin-right: 5px;\n  font-size: 15px;\n}\n.main_content_div .flight_flex {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\n.main_content_div .flight_flex .forward_icn {\n  font-size: 24px;\n}\n.main_content_div .flight_flex .grey_flex {\n  background: #f7f7f7;\n  padding: 16px;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n}\n.main_content_div .flight_flex .grey_flex .round_div {\n  background: #ebebeb;\n  height: 50px;\n  width: 50px;\n  border-radius: 50%;\n  margin-bottom: 20px;\n  position: relative;\n}\n.main_content_div .flight_flex .grey_flex .round_div img {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  width: 25px;\n}\n.main_content_div .flight_flex .grey_flex .loc_lbl {\n  font-size: 30px;\n}\n.main_content_div .flight_flex .grey_flex .date {\n  color: grey;\n  font-size: 14px;\n}\n.main_content_div .flight_flex .grey_flex .ticket_flex {\n  display: flex;\n  align-items: center;\n  color: violet;\n  margin-top: 30px;\n}\n.main_content_div .flight_flex .grey_flex .ticket_flex ion-icon {\n  color: violet;\n}\n.main_content_div .flight_flex .grey_flex .ticket_flex ion-label {\n  margin-left: 10px;\n}\n.main_content_div .cost_flex {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  margin-top: 10px;\n  margin-bottom: 10px;\n}\n.main_content_div .cost_flex ion-label {\n  white-space: nowrap;\n}\n.main_content_div .cost_flex .green_lbl {\n  color: var(--ion-color-primary);\n}\n.main_content_div .cost_flex .dash_div {\n  margin-left: 10px;\n  margin-right: 10px;\n  width: 100%;\n  overflow: hidden;\n}\n.main_content_div .cost_flex .dash_div ion-label {\n  color: lightgrey;\n}\nion-footer {\n  padding: 16px;\n}\nion-button {\n  letter-spacing: 0.6px;\n  text-transform: capitalize;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvYWRkLWhvdGVsLWZsaWdodC9hZGQtaG90ZWwtZmxpZ2h0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGFBQUE7QUFDSjtBQUNJO0VBQ0ksY0FBQTtBQUNSO0FBRUk7RUFDSSx3QkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7QUFBUjtBQUdJO0VBQ0ksV0FBQTtFQUNBLGFBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7RUFDQSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSx1QkFBQTtBQURSO0FBR1E7RUFDSSxlQUFBO0VBQ0Esd0JBQUE7RUFDQSxZQUFBO0FBRFo7QUFJUTtFQUNJLGFBQUE7RUFDQSxhQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtBQUZaO0FBSVk7RUFDSSxpQkFBQTtFQUNBLGVBQUE7QUFGaEI7QUFPSTtFQUNJLGFBQUE7RUFDQSw4QkFBQTtFQUNBLG1CQUFBO0FBTFI7QUFPUTtFQUNJLGVBQUE7QUFMWjtBQVFRO0VBQ0ksbUJBQUE7RUFDQSxhQUFBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsbUJBQUE7QUFOWjtBQVFZO0VBQ0ksbUJBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQU5oQjtBQVFnQjtFQUNJLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxnQ0FBQTtFQUNBLFdBQUE7QUFOcEI7QUFVWTtFQUNJLGVBQUE7QUFSaEI7QUFZWTtFQUNJLFdBQUE7RUFDQSxlQUFBO0FBVmhCO0FBYVk7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0VBQ0EsZ0JBQUE7QUFYaEI7QUFhZ0I7RUFDSSxhQUFBO0FBWHBCO0FBY2dCO0VBQ0ksaUJBQUE7QUFacEI7QUFrQkk7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSw4QkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7QUFoQlI7QUFrQlE7RUFDSSxtQkFBQTtBQWhCWjtBQW1CUTtFQUNJLCtCQUFBO0FBakJaO0FBb0JRO0VBQ0ksaUJBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxnQkFBQTtBQWxCWjtBQW9CWTtFQUNJLGdCQUFBO0FBbEJoQjtBQXVCQTtFQUNJLGFBQUE7QUFwQko7QUF1QkE7RUFDSSxxQkFBQTtFQUNBLDBCQUFBO0FBcEJKIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvYWRkLWhvdGVsLWZsaWdodC9hZGQtaG90ZWwtZmxpZ2h0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tYWluX2NvbnRlbnRfZGl2IHtcbiAgICBwYWRkaW5nOiAxNnB4O1xuXG4gICAgaW9uLWxhYmVsIHtcbiAgICAgICAgZGlzcGxheTogYmxvY2s7XG4gICAgfVxuXG4gICAgLmJvbGRfbGJsIHtcbiAgICAgICAgZm9udC1mYW1pbHk6ICdzZW1pLWJvbGQnO1xuICAgICAgICBtYXJnaW4tdG9wOiA0MHB4O1xuICAgICAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICAgIH1cblxuICAgIC5iYWNrX2ltYWdlIHtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIGhlaWdodDogMTAwcHg7XG4gICAgICAgIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcbiAgICAgICAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbiAgICAgICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgICAgICBwYWRkaW5nOiAxNnB4O1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcblxuICAgICAgICAucGxhY2VfbGJsIHtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAnc2VtaS1ib2xkJztcbiAgICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcbiAgICAgICAgfVxuXG4gICAgICAgIC5zdGFyX2ZsZXgge1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgIGNvbG9yOiBvcmFuZ2U7XG4gICAgICAgICAgICBtYXJnaW4tdG9wOiAxMHB4O1xuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMTBweDtcblxuICAgICAgICAgICAgaW9uLWljb24ge1xuICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDogNXB4O1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTVweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5mbGlnaHRfZmxleCB7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICAgICAgICAuZm9yd2FyZF9pY24ge1xuICAgICAgICAgICAgZm9udC1zaXplOiAyNHB4O1xuICAgICAgICB9XG5cbiAgICAgICAgLmdyZXlfZmxleCB7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiAjZjdmN2Y3O1xuICAgICAgICAgICAgcGFkZGluZzogMTZweDtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICAgICAgICAgICAgLnJvdW5kX2RpdiB7XG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogI2ViZWJlYjtcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDUwcHg7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDUwcHg7XG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XG4gICAgICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuXG4gICAgICAgICAgICAgICAgaW1nIHtcbiAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgICAgICAgICB0b3A6IDUwJTtcbiAgICAgICAgICAgICAgICAgICAgbGVmdDogNTAlO1xuICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLC01MCUpO1xuICAgICAgICAgICAgICAgICAgICB3aWR0aDogMjVweDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC5sb2NfbGJsIHtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDMwcHg7XG4gICAgICAgICAgICAgICAgLy8gZm9udC1mYW1pbHk6ICdzZW1pLWJvbGQnO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAuZGF0ZSB7XG4gICAgICAgICAgICAgICAgY29sb3I6IGdyZXk7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAudGlja2V0X2ZsZXgge1xuICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICAgICAgICBjb2xvcjogdmlvbGV0O1xuICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6IDMwcHg7XG5cbiAgICAgICAgICAgICAgICBpb24taWNvbiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiB2aW9sZXQ7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgaW9uLWxhYmVsIHtcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLmNvc3RfZmxleCB7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICAgICAgbWFyZ2luLXRvcDogMTBweDtcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogMTBweDtcblxuICAgICAgICBpb24tbGFiZWwge1xuICAgICAgICAgICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgICAgICAgfVxuXG4gICAgICAgIC5ncmVlbl9sYmwge1xuICAgICAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgICAgICAgfVxuXG4gICAgICAgIC5kYXNoX2RpdiB7XG4gICAgICAgICAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcblxuICAgICAgICAgICAgaW9uLWxhYmVsIHtcbiAgICAgICAgICAgICAgICBjb2xvcjogbGlnaHRncmV5O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufSBcbmlvbi1mb290ZXIge1xuICAgIHBhZGRpbmc6IDE2cHg7XG59XG5cbmlvbi1idXR0b24ge1xuICAgIGxldHRlci1zcGFjaW5nOiAwLjZweDtcbiAgICB0ZXh0LXRyYW5zZm9ybTogY2FwaXRhbGl6ZTtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/pages/add-hotel-flight/add-hotel-flight.page.ts":
/*!*****************************************************************!*\
  !*** ./src/app/pages/add-hotel-flight/add-hotel-flight.page.ts ***!
  \*****************************************************************/
/*! exports provided: AddHotelFlightPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddHotelFlightPage", function() { return AddHotelFlightPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");



let AddHotelFlightPage = class AddHotelFlightPage {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
    }
    goToHome() {
        this.router.navigate(['/tabs/home']);
    }
};
AddHotelFlightPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] }
];
AddHotelFlightPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
        selector: 'app-add-hotel-flight',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./add-hotel-flight.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-hotel-flight/add-hotel-flight.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./add-hotel-flight.page.scss */ "./src/app/pages/add-hotel-flight/add-hotel-flight.page.scss")).default]
    })
], AddHotelFlightPage);



/***/ })

}]);
//# sourceMappingURL=pages-add-hotel-flight-add-hotel-flight-module-es2015.js.map