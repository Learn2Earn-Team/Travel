(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-flights-flights-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/flights/flights.page.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/flights/flights.page.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n    <ion-toolbar>\n        <ion-button fill=\"clear\" (click)=\"goBack()\">\n            <ion-icon name=\"arrow-back\" style=\"color: black;\"></ion-icon>\n        </ion-button>\n        <ion-title>Flights</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <div class=\"main_content_div\">\n        <div class=\"card_box\" *ngFor=\"let item of [1,2,3,4]\">\n            <div class=\"flex_div\">\n                <div>\n                    <ion-label class=\"green_lbl\">Sdyney</ion-label>\n                    <ion-label class=\"green_small\">(SYD)</ion-label>\n                </div>\n                <ion-icon name=\"airplane-sharp\"></ion-icon>\n                <div>\n                    <ion-label class=\"green_lbl\">London</ion-label>\n                    <ion-label class=\"green_small\" style=\"text-align: right;\">(LCY)</ion-label>\n                </div>\n            </div>\n\n            <div class=\"flex_div\">\n                <ion-label class=\"grey_lbl\">Depart</ion-label>\n                <ion-label class=\"grey_lbl\">Depart</ion-label>\n            </div>\n            <div class=\"flex_div\">\n                <ion-label class=\"bold_lbl\">08:30 AM</ion-label>\n                <ion-label class=\"small_grey\">2hr30min</ion-label>\n                <ion-label class=\"bold_lbl\">11:00 AM</ion-label>\n            </div>\n            <div class=\"flex_div\">\n                <ion-label class=\"orange_lbl\">$200 <span>(Ticket Price)</span></ion-label>\n                <ion-button size=\"small\" (click)=\"goToFlightBook()\">\n                    Book Flight\n                </ion-button>\n            </div>\n        </div>\n    </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/pages/flights/flights-routing.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/flights/flights-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: FlightsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FlightsPageRoutingModule", function() { return FlightsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _flights_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./flights.page */ "./src/app/pages/flights/flights.page.ts");




const routes = [
    {
        path: '',
        component: _flights_page__WEBPACK_IMPORTED_MODULE_3__["FlightsPage"]
    }
];
let FlightsPageRoutingModule = class FlightsPageRoutingModule {
};
FlightsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], FlightsPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/flights/flights.module.ts":
/*!*************************************************!*\
  !*** ./src/app/pages/flights/flights.module.ts ***!
  \*************************************************/
/*! exports provided: FlightsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FlightsPageModule", function() { return FlightsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _flights_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./flights-routing.module */ "./src/app/pages/flights/flights-routing.module.ts");
/* harmony import */ var _flights_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./flights.page */ "./src/app/pages/flights/flights.page.ts");







let FlightsPageModule = class FlightsPageModule {
};
FlightsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _flights_routing_module__WEBPACK_IMPORTED_MODULE_5__["FlightsPageRoutingModule"]
        ],
        declarations: [_flights_page__WEBPACK_IMPORTED_MODULE_6__["FlightsPage"]]
    })
], FlightsPageModule);



/***/ }),

/***/ "./src/app/pages/flights/flights.page.scss":
/*!*************************************************!*\
  !*** ./src/app/pages/flights/flights.page.scss ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".main_content_div {\n  padding: 16px;\n}\n.main_content_div ion-label {\n  display: block;\n}\n.main_content_div .card_box {\n  padding: 16px;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.2);\n  border-radius: 3px;\n  margin-bottom: 20px;\n}\n.main_content_div .card_box .flex_div {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n.main_content_div .card_box .flex_div .green_lbl {\n  font-family: \"semi-bold\";\n}\n.main_content_div .card_box .flex_div .green_small {\n  font-family: \"medium\";\n  font-size: 13px;\n  margin-bottom: 10px;\n  color: grey;\n}\n.main_content_div .card_box .flex_div ion-icon {\n  font-size: 28px;\n  color: var(--ion-color-primary);\n  transform: rotate(-30deg);\n}\n.main_content_div .card_box .flex_div .grey_lbl {\n  font-size: 12px;\n  color: grey;\n}\n.main_content_div .card_box .flex_div .bold_lbl {\n  font-size: 15px;\n  font-family: \"semi-bold\";\n  margin-bottom: 10px;\n}\n.main_content_div .card_box .flex_div .small_grey {\n  font-size: 12px;\n  color: grey;\n  margin-bottom: 10px;\n}\n.main_content_div .card_box .flex_div .orange_lbl {\n  font-size: 20px;\n  font-family: \"bold\";\n  color: var(--ion-color-primary);\n}\n.main_content_div .card_box .flex_div .orange_lbl span {\n  color: grey;\n  font-family: \"regular\";\n  font-size: 12px;\n}\n.main_content_div .card_box .flex_div ion-button {\n  --border-radius: 3px;\n  letter-spacing: 0.5px;\n  margin: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvZmxpZ2h0cy9mbGlnaHRzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGFBQUE7QUFDSjtBQUNJO0VBQ0ksY0FBQTtBQUNSO0FBRUk7RUFDSSxhQUFBO0VBQ0EsMENBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FBQVI7QUFFUTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtFQUNBLDhCQUFBO0FBQVo7QUFFWTtFQUVJLHdCQUFBO0FBRGhCO0FBR1k7RUFFSSxxQkFBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7QUFGaEI7QUFJWTtFQUNJLGVBQUE7RUFDQSwrQkFBQTtFQUNBLHlCQUFBO0FBRmhCO0FBSVk7RUFDSSxlQUFBO0VBQ0EsV0FBQTtBQUZoQjtBQUlZO0VBQ0ksZUFBQTtFQUNBLHdCQUFBO0VBQ0EsbUJBQUE7QUFGaEI7QUFJWTtFQUNJLGVBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7QUFGaEI7QUFJWTtFQUNJLGVBQUE7RUFDQSxtQkFBQTtFQUNBLCtCQUFBO0FBRmhCO0FBR2dCO0VBQ0ksV0FBQTtFQUNBLHNCQUFBO0VBQ0EsZUFBQTtBQURwQjtBQUlZO0VBQ0ksb0JBQUE7RUFDQSxxQkFBQTtFQUNBLFdBQUE7QUFGaEIiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9mbGlnaHRzL2ZsaWdodHMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1haW5fY29udGVudF9kaXYge1xuICAgIHBhZGRpbmc6IDE2cHg7XG5cbiAgICBpb24tbGFiZWwge1xuICAgICAgICBkaXNwbGF5OiBibG9jaztcbiAgICB9XG5cbiAgICAuY2FyZF9ib3gge1xuICAgICAgICBwYWRkaW5nOiAxNnB4O1xuICAgICAgICBib3gtc2hhZG93OiAwcHggM3B4IDZweCByZ2JhKDAsMCwwLDAuMik7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDNweDtcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogMjBweDtcblxuICAgICAgICAuZmxleF9kaXYge1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG5cbiAgICAgICAgICAgIC5ncmVlbl9sYmwge1xuICAgICAgICAgICAgICAgIC8vIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gICAgICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdzZW1pLWJvbGQnO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLmdyZWVuX3NtYWxsIHtcbiAgICAgICAgICAgICAgICAvLyBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgICAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAnbWVkaXVtJztcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XG4gICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgICAgICAgICAgICAgICBjb2xvcjogZ3JleTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlvbi1pY29uIHtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDI4cHg7XG4gICAgICAgICAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IHJvdGF0ZSgtMzBkZWcpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLmdyZXlfbGJsIHtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgICAgICAgICAgICAgY29sb3I6IGdyZXk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAuYm9sZF9sYmwge1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTVweDtcbiAgICAgICAgICAgICAgICBmb250LWZhbWlseTogJ3NlbWktYm9sZCc7XG4gICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC5zbWFsbF9ncmV5IHtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgICAgICAgICAgICAgY29sb3I6IGdyZXk7XG4gICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC5vcmFuZ2VfbGJsIHtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDIwcHg7XG4gICAgICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdib2xkJztcbiAgICAgICAgICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgICAgICAgICAgICAgIHNwYW4ge1xuICAgICAgICAgICAgICAgICAgICBjb2xvcjogZ3JleTtcbiAgICAgICAgICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdyZWd1bGFyJztcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlvbi1idXR0b24ge1xuICAgICAgICAgICAgICAgIC0tYm9yZGVyLXJhZGl1czogM3B4O1xuICAgICAgICAgICAgICAgIGxldHRlci1zcGFjaW5nOiAwLjVweDtcbiAgICAgICAgICAgICAgICBtYXJnaW46IDBweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn0iXX0= */");

/***/ }),

/***/ "./src/app/pages/flights/flights.page.ts":
/*!***********************************************!*\
  !*** ./src/app/pages/flights/flights.page.ts ***!
  \***********************************************/
/*! exports provided: FlightsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FlightsPage", function() { return FlightsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");




let FlightsPage = class FlightsPage {
    constructor(navCtrl, router) {
        this.navCtrl = navCtrl;
        this.router = router;
    }
    ngOnInit() {
    }
    goBack() {
        this.navCtrl.back();
    }
    goToFlightBook() {
        this.router.navigate(['/book-flight']);
    }
};
FlightsPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] }
];
FlightsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-flights',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./flights.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/flights/flights.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./flights.page.scss */ "./src/app/pages/flights/flights.page.scss")).default]
    })
], FlightsPage);



/***/ })

}]);
//# sourceMappingURL=pages-flights-flights-module-es2015.js.map