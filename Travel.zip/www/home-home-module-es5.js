(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home/home.page.html":
    /*!*********************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home/home.page.html ***!
      \*********************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPagesHomeHomePageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header mode=\"ios\" class=\"ion-no-border\">\n    <div class=\"header_flex\">\n        <div>\n            <div class=\"weather_flex\">\n                <img src=\"assets/imgs/cloudy.png\">\n                <ion-label>27, Oslo</ion-label>\n            </div>\n            <ion-label class=\"name\">Hello, Adam</ion-label>\n        </div>\n        <div class=\"round_img\" [style.backgroundImage]=\"'url(assets/imgs/user.jpg)'\"></div>\n    </div>\n</ion-header>\n\n<ion-content>\n    <div class=\"main_content_div\">\n\n        <div class=\"upper_div\">\n            <ion-label class=\"bold_lbl\">Current Trip</ion-label>\n            <div class=\"back_image\" [style.backgroundImage]=\"'url(assets/imgs/nature4.jpg)'\">\n\n                <div class=\"users_flex\">\n                    <div class=\"user_round\" [style.backgroundImage]=\"'url(assets/imgs/user1.jpg)'\"></div>\n                    <div class=\"user_round\" [style.backgroundImage]=\"'url(assets/imgs/user2.jpg)'\"></div>\n                    <div class=\"user_round\" [style.backgroundImage]=\"'url(assets/imgs/user3.jpg)'\"></div>\n                </div>\n\n                <div class=\"manage_flex\">\n                    <div>\n                        <ion-label class=\"place_name\">Oslo, Norway</ion-label>\n                        <ion-label class=\"small_lbl\">3 more days</ion-label>\n                    </div>\n                    <div>\n                        <ion-button>\n                            Manage\n                        </ion-button>\n                    </div>\n                </div>\n\n            </div>\n        </div>\n\n        <div class=\"grey_box\">\n            <ion-label class=\"bold_lbl\">Trip Plan</ion-label>\n\n            <div class=\"tracking_div\">\n\n                <div class=\"first\">\n                    <span *ngFor=\"let item of orderDetail\">\n                        <ion-label>{{item.time}}</ion-label>\n                    </span>\n                </div>\n\n                <div class=\"left\">\n                    <span *ngFor=\"let item of orderDetail\">\n                        <div class=\"line_div\" [class.line_div_darkgray]=\"item.status == 1\"></div>\n                        <div class=\"round_div_gray\" [class.round_div_red]=\"item.status == 2\"\n                            [class.round_div_darkgray]=\"item.status == 1\">\n                            <ion-icon name=\"checkmark\"></ion-icon>\n                        </div>\n                    </span>\n                </div>\n\n                <div class=\"right\">\n                    <span *ngFor=\"let item of orderDetail\" style=\"width: 100%;\">\n                        <div class=\"round_div_gray\" [class.round_div_red]=\"item.status == 2\"\n                            [class.round_div_darkgray]=\"item.status == 1\">\n                            <div class=\"content_flex\">\n                                <div>\n                                    <ion-label class=\"act_lbl\">{{item.activity}}</ion-label>\n                                    <ion-label class=\"place_lbl\">{{item.location}}</ion-label>\n                                </div>\n                                <div class=\"image_div\">\n                                    <img src=\"{{item.img}}\">\n                                </div>\n                            </div>\n                        </div>\n                    </span>\n                </div>\n\n            </div>\n\n        </div>\n\n    </div>\n</ion-content>";
      /***/
    },

    /***/
    "./src/app/pages/home/home-routing.module.ts":
    /*!***************************************************!*\
      !*** ./src/app/pages/home/home-routing.module.ts ***!
      \***************************************************/

    /*! exports provided: HomePageRoutingModule */

    /***/
    function srcAppPagesHomeHomeRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HomePageRoutingModule", function () {
        return HomePageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _home_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./home.page */
      "./src/app/pages/home/home.page.ts");

      var routes = [{
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_3__["HomePage"]
      }];

      var HomePageRoutingModule = function HomePageRoutingModule() {
        _classCallCheck(this, HomePageRoutingModule);
      };

      HomePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], HomePageRoutingModule);
      /***/
    },

    /***/
    "./src/app/pages/home/home.module.ts":
    /*!*******************************************!*\
      !*** ./src/app/pages/home/home.module.ts ***!
      \*******************************************/

    /*! exports provided: HomePageModule */

    /***/
    function srcAppPagesHomeHomeModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HomePageModule", function () {
        return HomePageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _home_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./home-routing.module */
      "./src/app/pages/home/home-routing.module.ts");
      /* harmony import */


      var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./home.page */
      "./src/app/pages/home/home.page.ts");

      var HomePageModule = function HomePageModule() {
        _classCallCheck(this, HomePageModule);
      };

      HomePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _home_routing_module__WEBPACK_IMPORTED_MODULE_5__["HomePageRoutingModule"]],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]]
      })], HomePageModule);
      /***/
    },

    /***/
    "./src/app/pages/home/home.page.scss":
    /*!*******************************************!*\
      !*** ./src/app/pages/home/home.page.scss ***!
      \*******************************************/

    /*! exports provided: default */

    /***/
    function srcAppPagesHomeHomePageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-label {\n  display: flex;\n}\n\nion-header {\n  padding: 16px;\n}\n\nion-header .header_flex {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\n\nion-header .header_flex .weather_flex {\n  display: flex;\n  align-items: center;\n}\n\nion-header .header_flex .weather_flex img {\n  width: 20px;\n}\n\nion-header .header_flex .weather_flex ion-label {\n  margin-left: 10px;\n}\n\nion-header .header_flex .name {\n  font-size: 18px;\n  font-family: \"semi-bold\";\n  margin-top: 5px;\n}\n\nion-header .header_flex .round_img {\n  height: 45px;\n  width: 45px;\n  border-radius: 50%;\n  background-repeat: no-repeat;\n  background-size: cover;\n  background-position: center;\n}\n\n.main_content_div {\n  padding-top: 20px;\n}\n\n.main_content_div .upper_div {\n  padding: 16px;\n}\n\n.main_content_div .upper_div .bold_lbl {\n  font-family: \"semi-bold\";\n  margin-bottom: 16px;\n}\n\n.main_content_div .upper_div .back_image {\n  width: 100%;\n  height: 170px;\n  border-radius: 5px;\n  background-repeat: no-repeat;\n  background-size: cover;\n  background-position: center;\n  padding: 10px;\n  display: flex;\n  flex-direction: column;\n  justify-content: space-between;\n}\n\n.main_content_div .upper_div .back_image .users_flex {\n  display: flex;\n  justify-content: flex-end;\n}\n\n.main_content_div .upper_div .back_image .users_flex .user_round {\n  height: 40px;\n  width: 40px;\n  border-radius: 50%;\n  background-repeat: no-repeat;\n  background-position: center;\n  background-size: cover;\n  margin-left: -10px;\n}\n\n.main_content_div .upper_div .back_image .manage_flex {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\n\n.main_content_div .upper_div .back_image .manage_flex .place_name {\n  font-family: \"my-family\";\n  font-size: 20px;\n  color: white;\n}\n\n.main_content_div .upper_div .back_image .manage_flex .small_lbl {\n  color: white;\n}\n\n.main_content_div .upper_div .back_image .manage_flex ion-button {\n  --border-radius: 5px;\n}\n\n.main_content_div .grey_box {\n  background: #F7F7F7;\n  padding: 16px;\n  padding-top: 40px;\n}\n\n.main_content_div .grey_box .bold_lbl {\n  font-family: \"semi-bold\";\n  margin-bottom: 16px;\n}\n\n.main_content_div .grey_box .tracking_div {\n  margin-top: 30px;\n  display: flex;\n  flex-direction: row;\n}\n\n.main_content_div .grey_box .tracking_div .first {\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  width: 20px;\n  min-width: 20px;\n}\n\n.main_content_div .grey_box .tracking_div .first ion-label {\n  margin-top: 65px;\n}\n\n.main_content_div .grey_box .tracking_div .left {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  width: 100px;\n  min-width: 100px;\n}\n\n.main_content_div .grey_box .tracking_div .left .line_div {\n  height: 60px;\n  width: 4px;\n  background: linear-gradient(to bottom, var(--ion-color-primary) 0%, var(--ion-color-primary) 60%, lightgrey 50%, lightgrey 100%);\n}\n\n.main_content_div .grey_box .tracking_div .left .line_div_darkgray {\n  height: 60px;\n  width: 4px;\n  background: var(--ion-color-primary);\n}\n\n.main_content_div .grey_box .tracking_div .left .round_div_gray {\n  height: 26px;\n  width: 26px;\n  background-color: transparent;\n  border: 2px solid lightgrey;\n  border-radius: 50%;\n  margin-left: -10px;\n  position: relative;\n}\n\n.main_content_div .grey_box .tracking_div .left .round_div_gray ion-icon {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  font-size: 17px;\n  font-weight: 600;\n  color: #f7f7f7;\n}\n\n.main_content_div .grey_box .tracking_div .left .round_div_darkgray {\n  height: 26px;\n  width: 26px;\n  background-color: var(--ion-color-primary);\n  border-radius: 50%;\n  margin-left: -10px;\n  border: 2px solid var(--ion-color-primary);\n}\n\n.main_content_div .grey_box .tracking_div .left .round_div_red {\n  height: 26px;\n  width: 26px;\n  background-color: var(--ion-color-primary);\n  border-radius: 50%;\n  margin-left: -10px;\n}\n\n.main_content_div .grey_box .tracking_div .right {\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  width: 100%;\n}\n\n.main_content_div .grey_box .tracking_div .right .content_flex {\n  padding-top: 50px;\n  display: flex;\n  justify-content: space-between;\n}\n\n.main_content_div .grey_box .tracking_div .right .content_flex .act_lbl {\n  font-family: \"semi-bold\";\n  color: black;\n}\n\n.main_content_div .grey_box .tracking_div .right .content_flex .place_lbl {\n  color: gray;\n}\n\n.main_content_div .grey_box .tracking_div .right .content_flex .image_div {\n  height: 40px;\n  width: 40px;\n  border-radius: 50%;\n  background: #ebebeb;\n  position: relative;\n}\n\n.main_content_div .grey_box .tracking_div .right .content_flex .image_div img {\n  width: 25px;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n}\n\nion-button {\n  letter-spacing: 0.6px;\n  text-transform: capitalize;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvaG9tZS9ob21lLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGFBQUE7QUFDSjs7QUFDQTtFQUNJLGFBQUE7QUFFSjs7QUFESTtFQUNJLGFBQUE7RUFDQSw4QkFBQTtFQUNBLG1CQUFBO0FBR1I7O0FBRFE7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7QUFHWjs7QUFEWTtFQUNJLFdBQUE7QUFHaEI7O0FBQVk7RUFDSSxpQkFBQTtBQUVoQjs7QUFFUTtFQUNJLGVBQUE7RUFDQSx3QkFBQTtFQUNBLGVBQUE7QUFBWjs7QUFHUTtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSw0QkFBQTtFQUNBLHNCQUFBO0VBQ0EsMkJBQUE7QUFEWjs7QUFNQTtFQUVJLGlCQUFBO0FBSko7O0FBTUk7RUFDSSxhQUFBO0FBSlI7O0FBTVE7RUFDSSx3QkFBQTtFQUNBLG1CQUFBO0FBSlo7O0FBT1E7RUFDSSxXQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0EsNEJBQUE7RUFDQSxzQkFBQTtFQUNBLDJCQUFBO0VBQ0EsYUFBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtFQUNBLDhCQUFBO0FBTFo7O0FBT1k7RUFDSSxhQUFBO0VBQ0EseUJBQUE7QUFMaEI7O0FBTWdCO0VBQ0ksWUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLDRCQUFBO0VBQ0EsMkJBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0FBSnBCOztBQVNZO0VBQ0ksYUFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7QUFQaEI7O0FBU2dCO0VBQ0ksd0JBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtBQVBwQjs7QUFVZ0I7RUFDSSxZQUFBO0FBUnBCOztBQVdnQjtFQUNJLG9CQUFBO0FBVHBCOztBQWlCSTtFQUNJLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLGlCQUFBO0FBZlI7O0FBaUJRO0VBQ0ksd0JBQUE7RUFDQSxtQkFBQTtBQWZaOztBQWtCUTtFQUNJLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FBaEJaOztBQWtCWTtFQUNJLGFBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7QUFoQmhCOztBQWtCZ0I7RUFDSSxnQkFBQTtBQWhCcEI7O0FBb0JZO0VBQ0ksYUFBQTtFQUNBLHNCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7QUFsQmhCOztBQW1CZ0I7RUFDSSxZQUFBO0VBQ0EsVUFBQTtFQUNBLGdJQUFBO0FBakJwQjs7QUEwQmdCO0VBQ0ksWUFBQTtFQUNBLFVBQUE7RUFDQSxvQ0FBQTtBQXhCcEI7O0FBMkJnQjtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0EsNkJBQUE7RUFDQSwyQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtBQXpCcEI7O0FBMkJvQjtFQUNJLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxnQ0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUF6QnhCOztBQTRCZ0I7RUFDSSxZQUFBO0VBQ0EsV0FBQTtFQUNBLDBDQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLDBDQUFBO0FBMUJwQjs7QUE0QmdCO0VBQ0ksWUFBQTtFQUNBLFdBQUE7RUFDQSwwQ0FBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QUExQnBCOztBQThCWTtFQUNJLGFBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0EsV0FBQTtBQTVCaEI7O0FBOEJnQjtFQUNJLGlCQUFBO0VBQ0EsYUFBQTtFQUNBLDhCQUFBO0FBNUJwQjs7QUE4Qm9CO0VBQ0ksd0JBQUE7RUFDQSxZQUFBO0FBNUJ4Qjs7QUErQm9CO0VBQ0ksV0FBQTtBQTdCeEI7O0FBZ0NvQjtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FBOUJ4Qjs7QUFnQ3dCO0VBQ0ksV0FBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxnQ0FBQTtBQTlCNUI7O0FBdUNBO0VBQ0kscUJBQUE7RUFDQSwwQkFBQTtBQXBDSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2hvbWUvaG9tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tbGFiZWwge1xuICAgIGRpc3BsYXk6IGZsZXg7XG59XG5pb24taGVhZGVyIHtcbiAgICBwYWRkaW5nOiAxNnB4O1xuICAgIC5oZWFkZXJfZmxleCB7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICAgICAgICAud2VhdGhlcl9mbGV4IHtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuXG4gICAgICAgICAgICBpbWcge1xuICAgICAgICAgICAgICAgIHdpZHRoOiAyMHB4O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpb24tbGFiZWwge1xuICAgICAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLm5hbWUge1xuICAgICAgICAgICAgZm9udC1zaXplOiAxOHB4O1xuICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdzZW1pLWJvbGQnO1xuICAgICAgICAgICAgbWFyZ2luLXRvcDogNXB4O1xuICAgICAgICB9XG5cbiAgICAgICAgLnJvdW5kX2ltZyB7XG4gICAgICAgICAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgICAgICAgICB3aWR0aDogNDVweDtcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICAgICAgICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xuICAgICAgICAgICAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xuICAgICAgICB9XG4gICAgfVxufVxuXG4ubWFpbl9jb250ZW50X2RpdiB7XG4gICAgLy8gcGFkZGluZzogMTZweDtcbiAgICBwYWRkaW5nLXRvcDogMjBweDtcblxuICAgIC51cHBlcl9kaXYge1xuICAgICAgICBwYWRkaW5nOiAxNnB4OyAgICAgICAgXG5cbiAgICAgICAgLmJvbGRfbGJsIHtcbiAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAnc2VtaS1ib2xkJztcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDE2cHg7XG4gICAgICAgIH1cbiAgICBcbiAgICAgICAgLmJhY2tfaW1hZ2Uge1xuICAgICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgICAgICBoZWlnaHQ6IDE3MHB4O1xuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgICAgICAgICAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbiAgICAgICAgICAgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXI7XG4gICAgICAgICAgICBwYWRkaW5nOiAxMHB4O1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG5cbiAgICAgICAgICAgIC51c2Vyc19mbGV4IHtcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XG4gICAgICAgICAgICAgICAgLnVzZXJfcm91bmQge1xuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDQwcHg7XG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiA0MHB4O1xuICAgICAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IC0xMHB4O1xuICAgICAgICAgICAgICAgICAgICAvLyBib3JkZXI6IDVweCBzb2xpZCB3aGl0ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC5tYW5hZ2VfZmxleCB7XG4gICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICAgICAgICAgICAgICAgIC5wbGFjZV9uYW1lIHtcbiAgICAgICAgICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdteS1mYW1pbHknO1xuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDIwcHg7XG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAuc21hbGxfbGJsIHtcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6IHdoaXRlO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGlvbi1idXR0b24ge1xuICAgICAgICAgICAgICAgICAgICAtLWJvcmRlci1yYWRpdXM6IDVweDtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5ncmV5X2JveHtcbiAgICAgICAgYmFja2dyb3VuZDogI0Y3RjdGNztcbiAgICAgICAgcGFkZGluZzogMTZweDtcbiAgICAgICAgcGFkZGluZy10b3A6IDQwcHg7XG5cbiAgICAgICAgLmJvbGRfbGJsIHtcbiAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAnc2VtaS1ib2xkJztcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDE2cHg7XG4gICAgICAgIH1cbiAgICAgICAgXG4gICAgICAgIC50cmFja2luZ19kaXZ7XG4gICAgICAgICAgICBtYXJnaW4tdG9wOiAzMHB4O1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gICAgICAgIFxuICAgICAgICAgICAgLmZpcnN0IHtcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgICAgICAgICAgICAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDIwcHg7XG4gICAgICAgICAgICAgICAgbWluLXdpZHRoOiAyMHB4O1xuICAgICAgICBcbiAgICAgICAgICAgICAgICBpb24tbGFiZWwge1xuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiA2NXB4O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXG4gICAgICAgICAgICAubGVmdHtcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICAgICAgICB3aWR0aDogMTAwcHg7XG4gICAgICAgICAgICAgICAgbWluLXdpZHRoOiAxMDBweDtcbiAgICAgICAgICAgICAgICAubGluZV9kaXZ7XG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogNjBweDtcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDRweDtcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KFxuICAgICAgICAgICAgICAgICAgICAgICAgdG8gYm90dG9tLCBcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KSAwJSwgXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSkgNjAlLCBcbiAgICAgICAgICAgICAgICAgICAgICAgIGxpZ2h0Z3JleSA1MCUsIFxuICAgICAgICAgICAgICAgICAgICAgICAgbGlnaHRncmV5IDEwMCVcbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICAgICAgICAgIC5saW5lX2Rpdl9kYXJrZ3JheXtcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiA2MHB4O1xuICAgICAgICAgICAgICAgICAgICB3aWR0aDogNHB4O1xuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgICAgICAgICAucm91bmRfZGl2X2dyYXl7XG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogMjZweDtcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDI2cHg7XG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xuICAgICAgICAgICAgICAgICAgICBib3JkZXI6IDJweCBzb2xpZCBsaWdodGdyZXk7XG4gICAgICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IC0xMHB4O1xuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgIFxuICAgICAgICAgICAgICAgICAgICBpb24taWNvbiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0b3A6IDUwJTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxlZnQ6IDUwJTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsLTUwJSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE3cHg7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICNmN2Y3Zjc7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLnJvdW5kX2Rpdl9kYXJrZ3JheXtcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiAyNnB4O1xuICAgICAgICAgICAgICAgICAgICB3aWR0aDogMjZweDtcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgICAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAtMTBweDtcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAycHggc29saWQgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAucm91bmRfZGl2X3JlZHtcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiAyNnB4O1xuICAgICAgICAgICAgICAgICAgICB3aWR0aDogMjZweDtcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjp2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gICAgICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IC0xMHB4O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXG4gICAgICAgICAgICAucmlnaHR7XG4gICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0O1xuICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICBcbiAgICAgICAgICAgICAgICAuY29udGVudF9mbGV4IHtcbiAgICAgICAgICAgICAgICAgICAgcGFkZGluZy10b3A6IDUwcHg7XG4gICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIC5hY3RfbGJsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAnc2VtaS1ib2xkJztcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBibGFjaztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIC5wbGFjZV9sYmwge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IGdyYXk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIC5pbWFnZV9kaXYge1xuICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiA0MHB4O1xuICAgICAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDQwcHg7XG4gICAgICAgICAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjZWJlYmViO1xuICAgICAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgICAgIGltZyB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDI1cHg7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvcDogNTAlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxlZnQ6IDUwJTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLC01MCUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuXG5pb24tYnV0dG9uIHtcbiAgICBsZXR0ZXItc3BhY2luZzogMC42cHg7XG4gICAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XG59Il19 */";
      /***/
    },

    /***/
    "./src/app/pages/home/home.page.ts":
    /*!*****************************************!*\
      !*** ./src/app/pages/home/home.page.ts ***!
      \*****************************************/

    /*! exports provided: HomePage */

    /***/
    function srcAppPagesHomeHomePageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HomePage", function () {
        return HomePage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

      var HomePage = /*#__PURE__*/function () {
        function HomePage() {
          _classCallCheck(this, HomePage);

          this.orderDetail = [{
            status: 1,
            time: '05:30',
            activity: 'Trekking',
            location: 'Lofoten',
            img: 'assets/imgs/surfer.png'
          }, {
            status: 1,
            time: '07:00',
            activity: 'Breakfast',
            location: 'at the Hotel',
            img: 'assets/imgs/breakfast.png'
          }, {
            status: 1,
            time: '08:30',
            activity: 'Surfing',
            location: 'on the Lake',
            img: 'assets/imgs/surfer.png'
          }, {
            status: 0,
            time: '11:30',
            activity: 'Taking Some rest',
            location: 'at the Hotel',
            img: 'assets/imgs/bed.png'
          }];
        }

        _createClass(HomePage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return HomePage;
      }();

      HomePage.ctorParameters = function () {
        return [];
      };

      HomePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-home',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./home.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home/home.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./home.page.scss */
        "./src/app/pages/home/home.page.scss"))["default"]]
      })], HomePage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=home-home-module-es5.js.map