(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-book-flight-book-flight-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/book-flight/book-flight.page.html":
    /*!***********************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/book-flight/book-flight.page.html ***!
      \***********************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPagesBookFlightBookFlightPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n    <ion-toolbar>\n        <ion-button fill=\"clear\" (click)=\"goBack()\">\n            <ion-icon name=\"arrow-back\" style=\"color: black;\"></ion-icon>\n        </ion-button>\n        <ion-title>Book Flight</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <div class=\"main_content_div\">\n        <div class=\"flex_div\">\n            <div class=\"border_div\" [class.active]=\"tripType == 'oneway'\" (click)=\"changeTrip('oneway')\">\n                <ion-icon name=\"checkmark-circle\"></ion-icon>\n                <ion-label>One way</ion-label>\n            </div>\n            <div class=\"border_div\" [class.active]=\"tripType == 'roundtrip'\" (click)=\"changeTrip('roundtrip')\">\n                <ion-icon name=\"checkmark-circle\"></ion-icon>\n                <ion-label>Round Trip</ion-label>\n            </div>\n        </div>\n\n        <ion-label class=\"bold_lbl\">Enter Detail</ion-label>\n\n        <ion-label class=\"simp_lbl\">From</ion-label>\n        <ion-input type=\"text\" value=\"Sydney (SYD)\"></ion-input>\n\n        <div style=\"text-align: center;\">\n            <ion-icon class=\"icn_plane\" name=\"airplane-sharp\"></ion-icon>\n        </div>\n\n        <ion-label class=\"simp_lbl\">To</ion-label>\n        <ion-input type=\"text\" value=\"London (LCY)\"></ion-input>\n\n        <ion-row>\n            <ion-col size=\"6\">\n                <ion-label class=\"simp_lbl\">Adults</ion-label>\n                <ion-input type=\"text\" value=\"2\"></ion-input>\n            </ion-col>\n            <ion-col size=\"6\">\n                <ion-label class=\"simp_lbl\">Chilren</ion-label>\n                <ion-input type=\"text\" value=\"1\"></ion-input>\n            </ion-col>\n        </ion-row>\n\n        <ion-label class=\"simp_lbl\">Luggage (kg)</ion-label>\n        <ion-input type=\"text\" value=\"10\"></ion-input>\n\n        <ion-label class=\"simp_lbl\">Class</ion-label>\n        <div class=\"flex_div2\">\n            <ion-label (click)=\"changeClass('business')\" [class.active]=\"classType == 'business'\">Business Class</ion-label>\n            <ion-label (click)=\"changeClass('economy')\" [class.active]=\"classType == 'economy'\">Economy Class</ion-label>\n        </div>\n\n        <ion-button (click)=\"goToPlanTrip()\" expand=\"block\" shape=\"round\">\n            Book Flight\n        </ion-button>\n\n    </div>\n</ion-content>\n";
      /***/
    },

    /***/
    "./src/app/pages/book-flight/book-flight-routing.module.ts":
    /*!*****************************************************************!*\
      !*** ./src/app/pages/book-flight/book-flight-routing.module.ts ***!
      \*****************************************************************/

    /*! exports provided: BookFlightPageRoutingModule */

    /***/
    function srcAppPagesBookFlightBookFlightRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "BookFlightPageRoutingModule", function () {
        return BookFlightPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _book_flight_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./book-flight.page */
      "./src/app/pages/book-flight/book-flight.page.ts");

      var routes = [{
        path: '',
        component: _book_flight_page__WEBPACK_IMPORTED_MODULE_3__["BookFlightPage"]
      }];

      var BookFlightPageRoutingModule = function BookFlightPageRoutingModule() {
        _classCallCheck(this, BookFlightPageRoutingModule);
      };

      BookFlightPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], BookFlightPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/pages/book-flight/book-flight.module.ts":
    /*!*********************************************************!*\
      !*** ./src/app/pages/book-flight/book-flight.module.ts ***!
      \*********************************************************/

    /*! exports provided: BookFlightPageModule */

    /***/
    function srcAppPagesBookFlightBookFlightModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "BookFlightPageModule", function () {
        return BookFlightPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _book_flight_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./book-flight-routing.module */
      "./src/app/pages/book-flight/book-flight-routing.module.ts");
      /* harmony import */


      var _book_flight_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./book-flight.page */
      "./src/app/pages/book-flight/book-flight.page.ts");

      var BookFlightPageModule = function BookFlightPageModule() {
        _classCallCheck(this, BookFlightPageModule);
      };

      BookFlightPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _book_flight_routing_module__WEBPACK_IMPORTED_MODULE_5__["BookFlightPageRoutingModule"]],
        declarations: [_book_flight_page__WEBPACK_IMPORTED_MODULE_6__["BookFlightPage"]]
      })], BookFlightPageModule);
      /***/
    },

    /***/
    "./src/app/pages/book-flight/book-flight.page.scss":
    /*!*********************************************************!*\
      !*** ./src/app/pages/book-flight/book-flight.page.scss ***!
      \*********************************************************/

    /*! exports provided: default */

    /***/
    function srcAppPagesBookFlightBookFlightPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".main_content_div {\n  padding: 16px;\n}\n.main_content_div ion-label {\n  display: block;\n}\n.main_content_div .flex_div {\n  display: flex;\n  margin-bottom: 20px;\n}\n.main_content_div .flex_div .border_div {\n  border: 1px solid lightgrey;\n  display: flex;\n  align-items: center;\n  border-radius: 3px;\n  margin-right: 16px;\n  padding: 1px 10px;\n}\n.main_content_div .flex_div .border_div ion-icon {\n  color: lightgrey;\n  font-size: 20px;\n}\n.main_content_div .flex_div .border_div ion-label {\n  margin-left: 6px;\n  color: lightgrey;\n  font-size: 14px;\n}\n.main_content_div .flex_div .active {\n  border-color: var(--ion-color-primary) !important;\n  background: var(--ion-color-primary);\n}\n.main_content_div .flex_div .active ion-icon {\n  color: white !important;\n}\n.main_content_div .flex_div .active ion-label {\n  color: white !important;\n}\n.main_content_div .icn_plane {\n  color: var(--ion-color-primary);\n  font-size: 30px;\n  transform: rotate(30deg);\n}\n.main_content_div .bold_lbl {\n  font-size: 18px;\n  font-family: \"semi-bold\";\n  margin-bottom: 16px;\n}\n.main_content_div .simp_lbl {\n  color: grey;\n  margin-bottom: 5px;\n  font-size: 14px;\n}\n.main_content_div ion-input {\n  border: 1px solid lightgrey;\n  border-radius: 25px;\n  height: 48px;\n  --padding-start: 16px;\n  --padding-end: 16px;\n  margin-bottom: 20px;\n  font-family: \"semi-bold\";\n}\n.main_content_div .flex_div2 {\n  display: flex;\n  margin-bottom: 20px;\n}\n.main_content_div .flex_div2 ion-label {\n  color: grey;\n  font-family: \"semi-bold\";\n  margin-right: 16px;\n  border: 1px solid lightgrey;\n  border-radius: 3px;\n  padding: 2px 10px;\n}\n.main_content_div .flex_div2 .active {\n  border-color: var(--ion-color-primary);\n  color: var(--ion-color-primary);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvYm9vay1mbGlnaHQvYm9vay1mbGlnaHQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksYUFBQTtBQUNKO0FBQ0k7RUFDSSxjQUFBO0FBQ1I7QUFFSTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtBQUFSO0FBQ1E7RUFDSSwyQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBQUNaO0FBQVk7RUFDSSxnQkFBQTtFQUNBLGVBQUE7QUFFaEI7QUFBWTtFQUNJLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBRWhCO0FBQ1E7RUFDSSxpREFBQTtFQUNBLG9DQUFBO0FBQ1o7QUFDWTtFQUNJLHVCQUFBO0FBQ2hCO0FBQ1k7RUFDSSx1QkFBQTtBQUNoQjtBQUlJO0VBQ0ksK0JBQUE7RUFDQSxlQUFBO0VBQ0Esd0JBQUE7QUFGUjtBQUtJO0VBQ0ksZUFBQTtFQUNBLHdCQUFBO0VBQ0EsbUJBQUE7QUFIUjtBQUtJO0VBQ0ksV0FBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQUhSO0FBS0k7RUFDSSwyQkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLHdCQUFBO0FBSFI7QUFNSTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtBQUpSO0FBS1E7RUFDSSxXQUFBO0VBQ0Esd0JBQUE7RUFDQSxrQkFBQTtFQUNBLDJCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBQUhaO0FBS1E7RUFHSSxzQ0FBQTtFQUNBLCtCQUFBO0FBTFoiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9ib29rLWZsaWdodC9ib29rLWZsaWdodC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubWFpbl9jb250ZW50X2RpdiB7XG4gICAgcGFkZGluZzogMTZweDtcblxuICAgIGlvbi1sYWJlbCB7XG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIH1cblxuICAgIC5mbGV4X2RpdiB7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XG4gICAgICAgIC5ib3JkZXJfZGl2IHtcbiAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIGxpZ2h0Z3JleTtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogM3B4O1xuICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAxNnB4O1xuICAgICAgICAgICAgcGFkZGluZzogMXB4IDEwcHg7XG4gICAgICAgICAgICBpb24taWNvbiB7XG4gICAgICAgICAgICAgICAgY29sb3I6IGxpZ2h0Z3JleTtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDIwcHg7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpb24tbGFiZWwge1xuICAgICAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiA2cHg7XG4gICAgICAgICAgICAgICAgY29sb3I6IGxpZ2h0Z3JleTtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgLmFjdGl2ZSB7XG4gICAgICAgICAgICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KSAhaW1wb3J0YW50O1xuICAgICAgICAgICAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgIFxuICAgICAgICAgICAgaW9uLWljb24ge1xuICAgICAgICAgICAgICAgIGNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaW9uLWxhYmVsIHtcbiAgICAgICAgICAgICAgICBjb2xvcjogd2hpdGUgIWltcG9ydGFudDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBcbiAgICAuaWNuX3BsYW5lIHtcbiAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgICAgICAgZm9udC1zaXplOiAzMHB4O1xuICAgICAgICB0cmFuc2Zvcm06IHJvdGF0ZSgzMGRlZyk7XG4gICAgfVxuXG4gICAgLmJvbGRfbGJsIHtcbiAgICAgICAgZm9udC1zaXplOiAxOHB4O1xuICAgICAgICBmb250LWZhbWlseTogJ3NlbWktYm9sZCc7XG4gICAgICAgIG1hcmdpbi1ib3R0b206IDE2cHg7XG4gICAgfVxuICAgIC5zaW1wX2xibCB7XG4gICAgICAgIGNvbG9yOiBncmV5O1xuICAgICAgICBtYXJnaW4tYm90dG9tOiA1cHg7XG4gICAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICB9XG4gICAgaW9uLWlucHV0IHtcbiAgICAgICAgYm9yZGVyOiAxcHggc29saWQgbGlnaHRncmV5O1xuICAgICAgICBib3JkZXItcmFkaXVzOiAyNXB4O1xuICAgICAgICBoZWlnaHQ6IDQ4cHg7XG4gICAgICAgIC0tcGFkZGluZy1zdGFydDogMTZweDtcbiAgICAgICAgLS1wYWRkaW5nLWVuZDogMTZweDtcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogMjBweDtcbiAgICAgICAgZm9udC1mYW1pbHk6ICdzZW1pLWJvbGQnO1xuICAgIH1cblxuICAgIC5mbGV4X2RpdjIge1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xuICAgICAgICBpb24tbGFiZWwge1xuICAgICAgICAgICAgY29sb3I6IGdyZXk7XG4gICAgICAgICAgICBmb250LWZhbWlseTogJ3NlbWktYm9sZCc7XG4gICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDE2cHg7XG4gICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCBsaWdodGdyZXk7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAzcHg7XG4gICAgICAgICAgICBwYWRkaW5nOiAycHggMTBweDtcbiAgICAgICAgfVxuICAgICAgICAuYWN0aXZlIHtcbiAgICAgICAgICAgIC8vIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgICAgICAgICAgIC8vIGNvbG9yOiB3aGl0ZTtcbiAgICAgICAgICAgIGJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgICAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTs7XG4gICAgICAgIH1cbiAgICB9XG59Il19 */";
      /***/
    },

    /***/
    "./src/app/pages/book-flight/book-flight.page.ts":
    /*!*******************************************************!*\
      !*** ./src/app/pages/book-flight/book-flight.page.ts ***!
      \*******************************************************/

    /*! exports provided: BookFlightPage */

    /***/
    function srcAppPagesBookFlightBookFlightPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "BookFlightPage", function () {
        return BookFlightPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

      var BookFlightPage = /*#__PURE__*/function () {
        function BookFlightPage(navCtrl, router) {
          _classCallCheck(this, BookFlightPage);

          this.navCtrl = navCtrl;
          this.router = router;
          this.tripType = 'oneway';
          this.classType = "economy";
        }

        _createClass(BookFlightPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "goBack",
          value: function goBack() {
            this.navCtrl.back();
          }
        }, {
          key: "changeTrip",
          value: function changeTrip(val) {
            this.tripType = val;
            console.log(this.tripType);
          }
        }, {
          key: "changeClass",
          value: function changeClass(val) {
            this.classType = val;
          }
        }, {
          key: "goToPlanTrip",
          value: function goToPlanTrip() {
            this.router.navigate(['/trip-plan']);
          }
        }]);

        return BookFlightPage;
      }();

      BookFlightPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]
        }];
      };

      BookFlightPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-book-flight',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./book-flight.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/book-flight/book-flight.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./book-flight.page.scss */
        "./src/app/pages/book-flight/book-flight.page.scss"))["default"]]
      })], BookFlightPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-book-flight-book-flight-module-es5.js.map