(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-add-card-add-card-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-card/add-card.page.html":
    /*!*****************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-card/add-card.page.html ***!
      \*****************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPagesAddCardAddCardPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header mode=\"ios\" class=\"ion-no-border\">\n    <ion-toolbar>\n        <ion-button fill=\"clear\" (click)=\"goBack()\">\n            <ion-icon name=\"arrow-back\" style=\"color: black;\"></ion-icon>\n        </ion-button>\n        <ion-title>Add Card</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <div class=\"main_content_div\">\n\n        <ion-label class=\"title_lbl\">Enter Card Detail</ion-label>\n\n        <ion-label class=\"simp_lbl\">Card Holder Name</ion-label>\n        <ion-input type=\"text\" placeholder=\"Card Holder\">\n        </ion-input>\n\n        <ion-label class=\"simp_lbl\">Card Number</ion-label>\n        <ion-input type=\"text\" placeholder=\"Card Number\">\n        </ion-input>\n\n        <ion-row>\n            <ion-col size=\"6\">\n                <ion-label class=\"simp_lbl\">CVV</ion-label>\n                <ion-input type=\"text\" placeholder=\"CVV\">\n                </ion-input>\n            </ion-col>\n            <ion-col size=\"6\">\n                <ion-label class=\"simp_lbl\">Expiry</ion-label>\n                <ion-datetime display-format=\"MM/YYYY\" placeholder=\"MM/YYYY\">\n                </ion-datetime>\n            </ion-col>\n        </ion-row>\n\n        <div class=\"flex_div\">\n            <ion-checkbox></ion-checkbox>\n            <ion-label>Set as a default card</ion-label>\n        </div>\n\n        <ion-button expand=\"block\" shape=\"round\" (click)=\"goBack()\">\n          Add Card\n        </ion-button>\n\n    </div>\n</ion-content>\n";
      /***/
    },

    /***/
    "./src/app/pages/add-card/add-card-routing.module.ts":
    /*!***********************************************************!*\
      !*** ./src/app/pages/add-card/add-card-routing.module.ts ***!
      \***********************************************************/

    /*! exports provided: AddCardPageRoutingModule */

    /***/
    function srcAppPagesAddCardAddCardRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AddCardPageRoutingModule", function () {
        return AddCardPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _add_card_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./add-card.page */
      "./src/app/pages/add-card/add-card.page.ts");

      var routes = [{
        path: '',
        component: _add_card_page__WEBPACK_IMPORTED_MODULE_3__["AddCardPage"]
      }];

      var AddCardPageRoutingModule = function AddCardPageRoutingModule() {
        _classCallCheck(this, AddCardPageRoutingModule);
      };

      AddCardPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], AddCardPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/pages/add-card/add-card.module.ts":
    /*!***************************************************!*\
      !*** ./src/app/pages/add-card/add-card.module.ts ***!
      \***************************************************/

    /*! exports provided: AddCardPageModule */

    /***/
    function srcAppPagesAddCardAddCardModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AddCardPageModule", function () {
        return AddCardPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _add_card_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./add-card-routing.module */
      "./src/app/pages/add-card/add-card-routing.module.ts");
      /* harmony import */


      var _add_card_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./add-card.page */
      "./src/app/pages/add-card/add-card.page.ts");

      var AddCardPageModule = function AddCardPageModule() {
        _classCallCheck(this, AddCardPageModule);
      };

      AddCardPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _add_card_routing_module__WEBPACK_IMPORTED_MODULE_5__["AddCardPageRoutingModule"]],
        declarations: [_add_card_page__WEBPACK_IMPORTED_MODULE_6__["AddCardPage"]]
      })], AddCardPageModule);
      /***/
    },

    /***/
    "./src/app/pages/add-card/add-card.page.scss":
    /*!***************************************************!*\
      !*** ./src/app/pages/add-card/add-card.page.scss ***!
      \***************************************************/

    /*! exports provided: default */

    /***/
    function srcAppPagesAddCardAddCardPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".main_content_div {\n  padding: 16px;\n}\n.main_content_div ion-label {\n  display: block;\n}\n.main_content_div .title_lbl {\n  font-size: 20px;\n  margin-bottom: 20px;\n  font-family: \"semi-bold\";\n}\n.main_content_div .simp_lbl {\n  color: grey;\n  margin-bottom: 5px;\n}\n.main_content_div ion-input, .main_content_div ion-datetime {\n  border: 1px solid lightgrey;\n  border-radius: 25px;\n  height: 48px;\n  --padding-start: 16px;\n  --padding-end: 16px;\n  margin-bottom: 20px;\n}\n.main_content_div .flex_div {\n  display: flex;\n  align-items: center;\n  margin-bottom: 20px;\n}\n.main_content_div .flex_div ion-label {\n  margin-left: 16px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvYWRkLWNhcmQvYWRkLWNhcmQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksYUFBQTtBQUNKO0FBQ0k7RUFDSSxjQUFBO0FBQ1I7QUFFSTtFQUNJLGVBQUE7RUFDQSxtQkFBQTtFQUNBLHdCQUFBO0FBQVI7QUFHSTtFQUNJLFdBQUE7RUFDQSxrQkFBQTtBQURSO0FBR0k7RUFDSSwyQkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtBQURSO0FBSUk7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtBQUZSO0FBSVE7RUFDSSxpQkFBQTtBQUZaIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvYWRkLWNhcmQvYWRkLWNhcmQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1haW5fY29udGVudF9kaXYge1xuICAgIHBhZGRpbmc6IDE2cHg7XG5cbiAgICBpb24tbGFiZWwge1xuICAgICAgICBkaXNwbGF5OiBibG9jaztcbiAgICB9XG5cbiAgICAudGl0bGVfbGJsIHtcbiAgICAgICAgZm9udC1zaXplOiAyMHB4O1xuICAgICAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xuICAgICAgICBmb250LWZhbWlseTogJ3NlbWktYm9sZCc7XG4gICAgfVxuXG4gICAgLnNpbXBfbGJsIHtcbiAgICAgICAgY29sb3I6IGdyZXk7XG4gICAgICAgIG1hcmdpbi1ib3R0b206IDVweDtcbiAgICB9XG4gICAgaW9uLWlucHV0LCBpb24tZGF0ZXRpbWUge1xuICAgICAgICBib3JkZXI6IDFweCBzb2xpZCBsaWdodGdyZXk7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDI1cHg7XG4gICAgICAgIGhlaWdodDogNDhweDtcbiAgICAgICAgLS1wYWRkaW5nLXN0YXJ0OiAxNnB4O1xuICAgICAgICAtLXBhZGRpbmctZW5kOiAxNnB4O1xuICAgICAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xuICAgIH1cblxuICAgIC5mbGV4X2RpdiB7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XG5cbiAgICAgICAgaW9uLWxhYmVsIHtcbiAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAxNnB4O1xuICAgICAgICB9XG4gICAgfVxufSJdfQ== */";
      /***/
    },

    /***/
    "./src/app/pages/add-card/add-card.page.ts":
    /*!*************************************************!*\
      !*** ./src/app/pages/add-card/add-card.page.ts ***!
      \*************************************************/

    /*! exports provided: AddCardPage */

    /***/
    function srcAppPagesAddCardAddCardPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AddCardPage", function () {
        return AddCardPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

      var AddCardPage = /*#__PURE__*/function () {
        function AddCardPage(navCtrl) {
          _classCallCheck(this, AddCardPage);

          this.navCtrl = navCtrl;
        }

        _createClass(AddCardPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "goBack",
          value: function goBack() {
            this.navCtrl.back();
          }
        }]);

        return AddCardPage;
      }();

      AddCardPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["NavController"]
        }];
      };

      AddCardPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
        selector: 'app-add-card',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./add-card.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/add-card/add-card.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./add-card.page.scss */
        "./src/app/pages/add-card/add-card.page.scss"))["default"]]
      })], AddCardPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-add-card-add-card-module-es5.js.map