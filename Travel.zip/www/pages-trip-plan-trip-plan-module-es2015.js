(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-trip-plan-trip-plan-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/trip-plan/trip-plan.page.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/trip-plan/trip-plan.page.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\n    <div class=\"main_content_div\">\n\n        <div class=\"back_image\" [style.backgroundImage]=\"'url(assets/imgs/nature1.jpg)'\">  \n            <ion-icon name=\"arrow-back-outline\" (click)=\"goToBack()\"></ion-icon>\n            <ion-label>Bali, Indonesia</ion-label>\n        </div>\n\n        <div class=\"white_div\">\n\n          <ion-label class=\"head_lbl\">About Bali</ion-label>\n\n          <ion-label class=\"detail_lbl\">\n            Lorem ipsum dolor sit amet, consectetur adipisicing elit. \n            Cum commodi maxime dolore saepe adipisci perspiciatis quo, quidem hic iusto \n            tempore odit eveniet illum minima esse nulla \n            voluptates, natus itaque doloribus?\n          </ion-label>\n\n          <div class=\"rate_flex\">\n            <div style=\"display: flex;align-items: center;\">\n                <ion-rating [rate]=\"rate\" readonly=\"false\" size=\"small\" (rateChange)=\"onRateChange($event)\"></ion-rating>\n                <ion-label style=\"margin-left: 5px;\">4.9(32 Reviews)</ion-label>\n            </div>\n            <ion-label>See Reviews</ion-label>\n          </div>\n\n          <ion-label class=\"head_lbl\">Pricing</ion-label>\n\n          <div class=\"grey_box\" (click)=\"goToFlights()\">\n              <div class=\"round_box plane_div\">\n                <ion-icon name=\"airplane-sharp\"></ion-icon>\n              </div>\n              <div class=\"content_div\">\n                  <ion-label class=\"bold_lbl\">Flights</ion-label>\n                  <ion-label class=\"small_lbl\">from $199</ion-label>\n              </div>\n              <ion-icon name=\"arrow-forward-outline\" class=\"forward_icn\"></ion-icon>\n          </div>\n\n          <div class=\"grey_box\" style=\"border: 0px;\" (click)=\"goToHotelMap()\">\n              <div class=\"round_box hotel_div\">\n                <ion-icon name=\"bed\"></ion-icon>\n              </div>\n              <div class=\"content_div\">\n                  <ion-label class=\"bold_lbl\">Hotels</ion-label>\n                  <ion-label class=\"small_lbl\">from $150/night </ion-label>\n              </div>\n              <ion-icon name=\"arrow-forward-outline\" class=\"forward_icn\"></ion-icon>\n          </div>\n\n          <ion-button expand=\"block\" shape=\"round\" (click)=\"goToAddPlan()\">\n            Plan Trip\n          </ion-button>\n        </div>\n\n    </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/pages/trip-plan/trip-plan-routing.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/pages/trip-plan/trip-plan-routing.module.ts ***!
  \*************************************************************/
/*! exports provided: TripPlanPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TripPlanPageRoutingModule", function() { return TripPlanPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _trip_plan_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./trip-plan.page */ "./src/app/pages/trip-plan/trip-plan.page.ts");




const routes = [
    {
        path: '',
        component: _trip_plan_page__WEBPACK_IMPORTED_MODULE_3__["TripPlanPage"]
    }
];
let TripPlanPageRoutingModule = class TripPlanPageRoutingModule {
};
TripPlanPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], TripPlanPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/trip-plan/trip-plan.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/pages/trip-plan/trip-plan.module.ts ***!
  \*****************************************************/
/*! exports provided: TripPlanPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TripPlanPageModule", function() { return TripPlanPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _trip_plan_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./trip-plan-routing.module */ "./src/app/pages/trip-plan/trip-plan-routing.module.ts");
/* harmony import */ var _trip_plan_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./trip-plan.page */ "./src/app/pages/trip-plan/trip-plan.page.ts");
/* harmony import */ var ionic_rating__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ionic-rating */ "./node_modules/ionic-rating/__ivy_ngcc__/fesm2015/ionic-rating.js");








let TripPlanPageModule = class TripPlanPageModule {
};
TripPlanPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            ionic_rating__WEBPACK_IMPORTED_MODULE_7__["IonicRatingModule"],
            _trip_plan_routing_module__WEBPACK_IMPORTED_MODULE_5__["TripPlanPageRoutingModule"]
        ],
        declarations: [_trip_plan_page__WEBPACK_IMPORTED_MODULE_6__["TripPlanPage"]]
    })
], TripPlanPageModule);



/***/ }),

/***/ "./src/app/pages/trip-plan/trip-plan.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/pages/trip-plan/trip-plan.page.scss ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content {\n  --background: white;\n}\n\n.main_content_div {\n  width: 100%;\n}\n\n.main_content_div ion-label {\n  display: block;\n}\n\n.main_content_div .back_image {\n  width: 100%;\n  height: 40vh;\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: cover;\n  position: relative;\n}\n\n.main_content_div .back_image ion-icon {\n  margin-left: 16px;\n  margin-top: 50px;\n  font-size: 30px;\n  color: white;\n}\n\n.main_content_div .back_image ion-label {\n  position: absolute;\n  bottom: 45px;\n  font-size: 26px;\n  font-family: \"my-family\";\n  color: white;\n  text-align: center;\n  left: 50%;\n  transform: translate(-50%);\n}\n\n.main_content_div .white_div {\n  width: 100%;\n  padding: 16px;\n  border-top-left-radius: 35px;\n  border-top-right-radius: 35px;\n  margin-top: -30px;\n  position: fixed;\n  overflow: scroll;\n  background: white;\n  height: 60vh;\n  z-index: 999;\n}\n\n.main_content_div .white_div .head_lbl {\n  font-family: \"semi-bold\";\n  font-size: 18px;\n  margin-top: 15px;\n}\n\n.main_content_div .white_div .detail_lbl {\n  font-size: 15px;\n  color: grey;\n}\n\n.main_content_div .white_div .rate_flex {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  font-size: 14px;\n  color: grey;\n}\n\n.main_content_div .white_div .rate_flex ion-button {\n  margin: 0px;\n}\n\n.main_content_div .white_div .grey_box {\n  padding: 16px 0px;\n  display: flex;\n  align-items: center;\n  border-bottom: 1px solid lightgrey;\n  position: relative;\n}\n\n.main_content_div .white_div .grey_box .round_box {\n  height: 45px;\n  width: 45px;\n  border-radius: 50%;\n  position: relative;\n}\n\n.main_content_div .white_div .grey_box .round_box ion-icon {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  font-size: 24px;\n}\n\n.main_content_div .white_div .grey_box .plane_div {\n  background: rgba(56, 128, 255, 0.2);\n}\n\n.main_content_div .white_div .grey_box .plane_div ion-icon {\n  color: #3880ff;\n}\n\n.main_content_div .white_div .grey_box .hotel_div {\n  background: rgba(255, 165, 0, 0.2);\n}\n\n.main_content_div .white_div .grey_box .hotel_div ion-icon {\n  color: #ffa500;\n}\n\n.main_content_div .white_div .grey_box .content_div {\n  padding-left: 16px;\n}\n\n.main_content_div .white_div .grey_box .content_div .bold_lbl {\n  font-family: \"semi-bold\";\n  margin-bottom: 3px;\n}\n\n.main_content_div .white_div .grey_box .content_div .small_lbl {\n  font-size: 14px;\n  color: grey;\n}\n\n.main_content_div .white_div .grey_box .forward_icn {\n  color: lightgray;\n  position: absolute;\n  right: 0;\n  font-size: 20px;\n}\n\n.main_content_div ion-button {\n  margin-top: 20px;\n}\n\nion-button {\n  letter-spacing: 0.6px;\n  text-transform: capitalize;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvdHJpcC1wbGFuL3RyaXAtcGxhbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSSxtQkFBQTtBQUFKOztBQUVBO0VBQ0ksV0FBQTtBQUNKOztBQUNJO0VBQ0ksY0FBQTtBQUNSOztBQUVJO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtBQUFSOztBQUVRO0VBQ0ksaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0FBQVo7O0FBR1E7RUFDSSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0Esd0JBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0VBQ0EsMEJBQUE7QUFEWjs7QUFLSTtFQUNJLFdBQUE7RUFDQSxhQUFBO0VBQ0EsNEJBQUE7RUFDQSw2QkFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBRUEsaUJBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtBQUpSOztBQU1RO0VBQ0ksd0JBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUFKWjs7QUFPUTtFQUNJLGVBQUE7RUFDQSxXQUFBO0FBTFo7O0FBUVE7RUFDSSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0FBTlo7O0FBUVk7RUFDSSxXQUFBO0FBTmhCOztBQVVRO0VBRUksaUJBQUE7RUFFQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQ0FBQTtFQUNBLGtCQUFBO0FBVlo7O0FBWVk7RUFDSSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QUFWaEI7O0FBWWdCO0VBQ0ksa0JBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLGdDQUFBO0VBQ0EsZUFBQTtBQVZwQjs7QUFhWTtFQUNJLG1DQUFBO0FBWGhCOztBQWFnQjtFQUNJLGNBQUE7QUFYcEI7O0FBZVk7RUFDSSxrQ0FBQTtBQWJoQjs7QUFjZ0I7RUFDSSxjQUFBO0FBWnBCOztBQWdCWTtFQUNJLGtCQUFBO0FBZGhCOztBQWdCZ0I7RUFDSSx3QkFBQTtFQUNBLGtCQUFBO0FBZHBCOztBQWlCZ0I7RUFDSSxlQUFBO0VBQ0EsV0FBQTtBQWZwQjs7QUFtQlk7RUFDSSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLGVBQUE7QUFqQmhCOztBQXNCSTtFQUNJLGdCQUFBO0FBcEJSOztBQXdCQTtFQUNJLHFCQUFBO0VBQ0EsMEJBQUE7QUFyQkoiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy90cmlwLXBsYW4vdHJpcC1wbGFuLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50e1xuICAgIC8vIC0tYmFja2dyb3VuZDogI0VGRjBGNTtcbiAgICAtLWJhY2tncm91bmQ6IHdoaXRlO1xufVxuLm1haW5fY29udGVudF9kaXZ7XG4gICAgd2lkdGg6IDEwMCU7XG5cbiAgICBpb24tbGFiZWwge1xuICAgICAgICBkaXNwbGF5OiBibG9jaztcbiAgICB9XG5cbiAgICAuYmFja19pbWFnZXtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIGhlaWdodDogNDB2aDtcbiAgICAgICAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xuICAgICAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICAgICAgICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG5cbiAgICAgICAgaW9uLWljb24ge1xuICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDE2cHg7XG4gICAgICAgICAgICBtYXJnaW4tdG9wOiA1MHB4O1xuICAgICAgICAgICAgZm9udC1zaXplOiAzMHB4O1xuICAgICAgICAgICAgY29sb3I6IHdoaXRlO1xuICAgICAgICB9XG5cbiAgICAgICAgaW9uLWxhYmVsIHtcbiAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICAgIGJvdHRvbTogNDVweDtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMjZweDtcbiAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAnbXktZmFtaWx5JztcbiAgICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcbiAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgICAgICAgIGxlZnQ6IDUwJTtcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLndoaXRlX2RpdntcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIHBhZGRpbmc6IDE2cHg7XG4gICAgICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDM1cHg7XG4gICAgICAgIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAzNXB4O1xuICAgICAgICBtYXJnaW4tdG9wOiAtMzBweDtcbiAgICAgICAgcG9zaXRpb246IGZpeGVkO1xuICAgICAgICBvdmVyZmxvdzogc2Nyb2xsO1xuICAgICAgICAvLyBiYWNrZ3JvdW5kOiAjRUZGMEY1O1xuICAgICAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgICAgICAgaGVpZ2h0OiA2MHZoO1xuICAgICAgICB6LWluZGV4OiA5OTk7XG5cbiAgICAgICAgLmhlYWRfbGJse1xuICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdzZW1pLWJvbGQnO1xuICAgICAgICAgICAgZm9udC1zaXplOiAxOHB4O1xuICAgICAgICAgICAgbWFyZ2luLXRvcDogMTVweDtcbiAgICAgICAgfVxuXG4gICAgICAgIC5kZXRhaWxfbGJse1xuICAgICAgICAgICAgZm9udC1zaXplOiAxNXB4O1xuICAgICAgICAgICAgY29sb3I6IGdyZXk7XG4gICAgICAgIH1cblxuICAgICAgICAucmF0ZV9mbGV4IHtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgICAgICAgY29sb3I6IGdyZXk7IFxuICAgIFxuICAgICAgICAgICAgaW9uLWJ1dHRvbiB7XG4gICAgICAgICAgICAgICAgbWFyZ2luOiAwcHg7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAuZ3JleV9ib3gge1xuICAgICAgICAgICAgLy8gYmFja2dyb3VuZDogI2Y1ZjVmNTtcbiAgICAgICAgICAgIHBhZGRpbmc6IDE2cHggMHB4O1xuICAgICAgICAgICAgLy8gbWFyZ2luLXRvcDogMTZweDtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JleTtcbiAgICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICBcbiAgICAgICAgICAgIC5yb3VuZF9ib3gge1xuICAgICAgICAgICAgICAgIGhlaWdodDogNDVweDtcbiAgICAgICAgICAgICAgICB3aWR0aDogNDVweDtcbiAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIFxuICAgICAgICAgICAgICAgIGlvbi1pY29uIHtcbiAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgICAgICAgICB0b3A6IDUwJTtcbiAgICAgICAgICAgICAgICAgICAgbGVmdDogNTAlO1xuICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLC01MCUpO1xuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDI0cHg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLnBsYW5lX2RpdiB7XG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogcmdiYSg1NiwgMTI4LCAyNTUsIDAuMik7XG5cbiAgICAgICAgICAgICAgICBpb24taWNvbiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjMzg4MGZmO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLmhvdGVsX2RpdiB7XG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogcmdiYSgyNTUsIDE2NSwgMCwgMC4yKTtcbiAgICAgICAgICAgICAgICBpb24taWNvbiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjZmZhNTAwO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICBcbiAgICAgICAgICAgIC5jb250ZW50X2RpdiB7XG4gICAgICAgICAgICAgICAgcGFkZGluZy1sZWZ0OiAxNnB4O1xuICAgIFxuICAgICAgICAgICAgICAgIC5ib2xkX2xibCB7XG4gICAgICAgICAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAnc2VtaS1ib2xkJztcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogM3B4O1xuICAgICAgICAgICAgICAgIH1cbiAgICBcbiAgICAgICAgICAgICAgICAuc21hbGxfbGJsIHtcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgICAgICAgICAgICAgICBjb2xvcjogZ3JleTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC5mb3J3YXJkX2ljbiB7XG4gICAgICAgICAgICAgICAgY29sb3I6IGxpZ2h0Z3JheTtcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICAgICAgcmlnaHQ6IDA7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAyMHB4O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgaW9uLWJ1dHRvbiB7XG4gICAgICAgIG1hcmdpbi10b3A6IDIwcHg7XG4gICAgfVxufVxuXG5pb24tYnV0dG9uIHtcbiAgICBsZXR0ZXItc3BhY2luZzogMC42cHg7XG4gICAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XG59Il19 */");

/***/ }),

/***/ "./src/app/pages/trip-plan/trip-plan.page.ts":
/*!***************************************************!*\
  !*** ./src/app/pages/trip-plan/trip-plan.page.ts ***!
  \***************************************************/
/*! exports provided: TripPlanPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TripPlanPage", function() { return TripPlanPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");




let TripPlanPage = class TripPlanPage {
    constructor(navCtrl, router) {
        this.navCtrl = navCtrl;
        this.router = router;
        this.rate = 4;
    }
    ngOnInit() {
    }
    goToBack() {
        this.navCtrl.back();
    }
    onRateChange(eve) {
    }
    goToHotelMap() {
        this.router.navigate(['/hotel-map']);
    }
    goToAddPlan() {
        this.router.navigate(['/add-plan']);
    }
    goToFlights() {
        this.router.navigate(['/flights']);
    }
};
TripPlanPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] }
];
TripPlanPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-trip-plan',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./trip-plan.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/trip-plan/trip-plan.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./trip-plan.page.scss */ "./src/app/pages/trip-plan/trip-plan.page.scss")).default]
    })
], TripPlanPage);



/***/ })

}]);
//# sourceMappingURL=pages-trip-plan-trip-plan-module-es2015.js.map