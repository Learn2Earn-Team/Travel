(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-hotel-map-hotel-map-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/hotel-map/hotel-map.page.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/hotel-map/hotel-map.page.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\n    <div class=\"main_content_div\">\n\n        <div class=\"upper_div\">\n            <div #map id=\"map\" class=\"map\"></div>\n            <div class=\"abs_div\">\n\n                <div class=\"search_flex\">\n                    <div class=\"white_back\" (click)=\"goToBack()\">\n                        <ion-icon name=\"arrow-back-outline\"></ion-icon>\n                    </div>\n                    <ion-input type=\"text\" placeholder=\"Search\">\n                        <ion-icon name=\"search\"></ion-icon>\n                    </ion-input>\n                    <div class=\"option_back\">\n                        <ion-icon name=\"options-outline\"></ion-icon>\n                    </div>\n                </div>\n\n                <div class=\"slider_div\">\n                    <ion-label class=\"bold_lbl\">Hotels in Bali</ion-label>\n                    <ion-slides mode=\"ios\" scrollbar=\"ios\" [options]=\"slideOpts\">\n                        <ion-slide *ngFor=\"let item of sliderImg\">\n                            <div class=\"slide_div\">\n                                <div class=\"back_image\" [style.backgroundImage]=\"'url('+ item +')'\"></div>\n                                <div class=\"content_div\">\n                                    <ion-label class=\"name\">Hanging Gardens of Bali Hotel</ion-label>\n                                    <div class=\"star_flex\">\n                                        <ion-icon name=\"star\"></ion-icon>\n                                        <ion-icon name=\"star\"></ion-icon>\n                                        <ion-icon name=\"star\"></ion-icon>\n                                        <ion-icon name=\"star\"></ion-icon>\n                                        <ion-icon name=\"star\"></ion-icon>\n                                    </div>\n                                    <div class=\"price_flex\">\n                                        <div>\n                                            <ion-label class=\"price_lbl\">from $199/night</ion-label>\n                                        </div>\n                                        <div class=\"green_div\" (click)=\"goToHotelDetail()\">\n                                            <ion-icon name=\"arrow-forward-outline\"></ion-icon>\n                                        </div>\n                                    </div>\n                                </div>\n                            </div>\n                        </ion-slide>\n                    </ion-slides>\n                </div>\n\n            </div>\n        </div>\n\n    </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/pages/hotel-map/hotel-map-routing.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/pages/hotel-map/hotel-map-routing.module.ts ***!
  \*************************************************************/
/*! exports provided: HotelMapPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HotelMapPageRoutingModule", function() { return HotelMapPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _hotel_map_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./hotel-map.page */ "./src/app/pages/hotel-map/hotel-map.page.ts");




const routes = [
    {
        path: '',
        component: _hotel_map_page__WEBPACK_IMPORTED_MODULE_3__["HotelMapPage"]
    }
];
let HotelMapPageRoutingModule = class HotelMapPageRoutingModule {
};
HotelMapPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], HotelMapPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/hotel-map/hotel-map.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/pages/hotel-map/hotel-map.module.ts ***!
  \*****************************************************/
/*! exports provided: HotelMapPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HotelMapPageModule", function() { return HotelMapPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _hotel_map_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./hotel-map-routing.module */ "./src/app/pages/hotel-map/hotel-map-routing.module.ts");
/* harmony import */ var _hotel_map_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./hotel-map.page */ "./src/app/pages/hotel-map/hotel-map.page.ts");
/* harmony import */ var ionic_rating__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ionic-rating */ "./node_modules/ionic-rating/__ivy_ngcc__/fesm2015/ionic-rating.js");








let HotelMapPageModule = class HotelMapPageModule {
};
HotelMapPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            ionic_rating__WEBPACK_IMPORTED_MODULE_7__["IonicRatingModule"],
            _hotel_map_routing_module__WEBPACK_IMPORTED_MODULE_5__["HotelMapPageRoutingModule"]
        ],
        declarations: [_hotel_map_page__WEBPACK_IMPORTED_MODULE_6__["HotelMapPage"]]
    })
], HotelMapPageModule);



/***/ }),

/***/ "./src/app/pages/hotel-map/hotel-map.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/pages/hotel-map/hotel-map.page.scss ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-label {\n  display: block;\n}\n\n.main_content_div {\n  width: 100%;\n  height: 100%;\n}\n\n.main_content_div .upper_div {\n  height: 100%;\n}\n\n.main_content_div .upper_div #map {\n  width: 100%;\n  height: 100%;\n}\n\n.main_content_div .abs_div {\n  width: 100%;\n  height: 100%;\n  display: flex;\n  flex-direction: column;\n  justify-content: space-between;\n  position: absolute;\n  top: 0;\n}\n\n.main_content_div .search_flex {\n  display: flex;\n  padding: 16px;\n}\n\n.main_content_div .search_flex .white_back {\n  height: 45px;\n  width: 45px;\n  background: white;\n  border-radius: 50%;\n  position: relative;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.3);\n}\n\n.main_content_div .search_flex .white_back ion-icon {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  font-size: 24px;\n}\n\n.main_content_div .search_flex ion-input {\n  border: 1px solid lightgrey;\n  border-radius: 25px;\n  --padding-start: 8px;\n  --padding-end: 8px;\n  height: 45px;\n  margin-left: 10px;\n  margin-right: 10px;\n  background: white;\n}\n\n.main_content_div .search_flex ion-input ion-icon {\n  margin-left: 16px;\n  color: grey;\n}\n\n.main_content_div .search_flex .option_back {\n  height: 45px;\n  width: 45px;\n  border-radius: 50%;\n  background: var(--ion-color-primary);\n  position: relative;\n}\n\n.main_content_div .search_flex .option_back ion-icon {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  color: white;\n  font-size: 24px;\n}\n\n.main_content_div .slider_div {\n  padding: 0px 16px;\n}\n\n.main_content_div .slider_div .bold_lbl {\n  font-family: \"semi-bold\";\n  font-size: 24px;\n}\n\n.main_content_div .slider_div ion-slide {\n  margin-right: 16px;\n  margin-top: 16px;\n  margin-bottom: 16px;\n}\n\n.main_content_div .slider_div .slide_div {\n  background: white;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.2);\n  padding: 10px;\n  width: 100%;\n  height: 140px;\n  display: flex;\n  border-radius: 5px;\n}\n\n.main_content_div .slider_div .slide_div .back_image {\n  width: 80px;\n  min-width: 80px;\n  height: 100%;\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: cover;\n  border-radius: 5px;\n}\n\n.main_content_div .slider_div .slide_div .content_div {\n  padding-left: 10px;\n  text-align: left;\n}\n\n.main_content_div .slider_div .slide_div .content_div .name {\n  font-family: \"semi-bold\";\n}\n\n.main_content_div .slider_div .slide_div .content_div .star_flex {\n  display: flex;\n  color: orange;\n  margin-top: 5px;\n}\n\n.main_content_div .slider_div .slide_div .content_div .star_flex ion-icon {\n  margin-right: 5px;\n  font-size: 15px;\n}\n\n.main_content_div .slider_div .slide_div .content_div .price_flex {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n\n.main_content_div .slider_div .slide_div .content_div .price_flex .price_lbl {\n  font-size: 15px;\n}\n\n.main_content_div .slider_div .slide_div .content_div .price_flex .green_div {\n  height: 40px;\n  width: 40px;\n  background: var(--ion-color-primary);\n  border-radius: 50%;\n  position: relative;\n}\n\n.main_content_div .slider_div .slide_div .content_div .price_flex .green_div ion-icon {\n  position: absolute;\n  color: white;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvaG90ZWwtbWFwL2hvdGVsLW1hcC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxjQUFBO0FBQ0o7O0FBQ0E7RUFDSSxXQUFBO0VBQ0EsWUFBQTtBQUVKOztBQUFJO0VBQ0ksWUFBQTtBQUVSOztBQUFRO0VBQ0ksV0FBQTtFQUNBLFlBQUE7QUFFWjs7QUFFSTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsOEJBQUE7RUFDQSxrQkFBQTtFQUNBLE1BQUE7QUFBUjs7QUFHSTtFQUNJLGFBQUE7RUFDQSxhQUFBO0FBRFI7O0FBR1E7RUFDSSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLDBDQUFBO0FBRFo7O0FBR1k7RUFDSSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsZ0NBQUE7RUFDQSxlQUFBO0FBRGhCOztBQUtRO0VBQ0ksMkJBQUE7RUFDQSxtQkFBQTtFQUNBLG9CQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0FBSFo7O0FBS1k7RUFDSSxpQkFBQTtFQUNBLFdBQUE7QUFIaEI7O0FBT1E7RUFDSSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0Esb0NBQUE7RUFDQSxrQkFBQTtBQUxaOztBQU9ZO0VBQ0ksa0JBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLGdDQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7QUFMaEI7O0FBWUk7RUFDSSxpQkFBQTtBQVZSOztBQVlRO0VBQ0ksd0JBQUE7RUFDQSxlQUFBO0FBVlo7O0FBYVE7RUFDSSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7QUFYWjs7QUFjUTtFQUNJLGlCQUFBO0VBQ0EsMENBQUE7RUFFQSxhQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7QUFiWjs7QUFlWTtFQUNJLFdBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0FBYmhCOztBQWdCWTtFQUNJLGtCQUFBO0VBQ0EsZ0JBQUE7QUFkaEI7O0FBZWdCO0VBQ0ksd0JBQUE7QUFicEI7O0FBZ0JnQjtFQUNJLGFBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtBQWRwQjs7QUFpQm9CO0VBQ0ksaUJBQUE7RUFDQSxlQUFBO0FBZnhCOztBQW1CZ0I7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSw4QkFBQTtBQWpCcEI7O0FBbUJvQjtFQUNJLGVBQUE7QUFqQnhCOztBQW9Cb0I7RUFDSSxZQUFBO0VBQ0EsV0FBQTtFQUNBLG9DQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtBQWxCeEI7O0FBb0J3QjtFQUNJLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsZ0NBQUE7QUFsQjVCIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvaG90ZWwtbWFwL2hvdGVsLW1hcC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tbGFiZWwge1xuICAgIGRpc3BsYXk6IGJsb2NrO1xufVxuLm1haW5fY29udGVudF9kaXYge1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGhlaWdodDogMTAwJTtcblxuICAgIC51cHBlcl9kaXZ7XG4gICAgICAgIGhlaWdodDogMTAwJTtcblxuICAgICAgICAjbWFwe1xuICAgICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgICAgICBoZWlnaHQ6IDEwMCU7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAuYWJzX2RpdiB7XG4gICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICBoZWlnaHQ6IDEwMCU7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICB0b3A6IDA7XG4gICAgfVxuXG4gICAgLnNlYXJjaF9mbGV4IHtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgcGFkZGluZzogMTZweDtcblxuICAgICAgICAud2hpdGVfYmFjayB7XG4gICAgICAgICAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgICAgICAgICB3aWR0aDogNDVweDtcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IHdoaXRlO1xuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICAgICAgYm94LXNoYWRvdzogMHB4IDNweCA2cHggcmdiYSgwLDAsMCwwLjMpO1xuXG4gICAgICAgICAgICBpb24taWNvbiB7XG4gICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgICAgIHRvcDogNTAlO1xuICAgICAgICAgICAgICAgIGxlZnQ6IDUwJTtcbiAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLC01MCUpO1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMjRweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGlvbi1pbnB1dCB7XG4gICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCBsaWdodGdyZXk7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAyNXB4O1xuICAgICAgICAgICAgLS1wYWRkaW5nLXN0YXJ0OiA4cHg7XG4gICAgICAgICAgICAtLXBhZGRpbmctZW5kOiA4cHg7XG4gICAgICAgICAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgICAgICAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IHdoaXRlO1xuXG4gICAgICAgICAgICBpb24taWNvbiB7XG4gICAgICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDE2cHg7XG4gICAgICAgICAgICAgICAgY29sb3I6IGdyZXk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAub3B0aW9uX2JhY2sge1xuICAgICAgICAgICAgaGVpZ2h0OiA0NXB4O1xuICAgICAgICAgICAgd2lkdGg6IDQ1cHg7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG5cbiAgICAgICAgICAgIGlvbi1pY29uIHtcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICAgICAgdG9wOiA1MCU7XG4gICAgICAgICAgICAgICAgbGVmdDogNTAlO1xuICAgICAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsLTUwJSk7XG4gICAgICAgICAgICAgICAgY29sb3I6IHdoaXRlO1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMjRweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIFxuXG4gICAgLnNsaWRlcl9kaXYge1xuICAgICAgICBwYWRkaW5nOiAwcHggMTZweDtcblxuICAgICAgICAuYm9sZF9sYmwge1xuICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdzZW1pLWJvbGQnO1xuICAgICAgICAgICAgZm9udC1zaXplOiAyNHB4O1xuICAgICAgICB9XG5cbiAgICAgICAgaW9uLXNsaWRlIHtcbiAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTZweDtcbiAgICAgICAgICAgIG1hcmdpbi10b3A6IDE2cHg7XG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAxNnB4O1xuICAgICAgICB9XG5cbiAgICAgICAgLnNsaWRlX2RpdiB7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgICAgICAgICAgIGJveC1zaGFkb3c6IDBweCAzcHggNnB4IHJnYmEoMCwwLDAsMC4yKTtcbiAgICAgICAgICAgIC8vIGJvcmRlcjogMXB4IHNvbGlkO1xuICAgICAgICAgICAgcGFkZGluZzogMTBweDtcbiAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgaGVpZ2h0OiAxNDBweDtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1cHg7XG5cbiAgICAgICAgICAgIC5iYWNrX2ltYWdlIHtcbiAgICAgICAgICAgICAgICB3aWR0aDogODBweDtcbiAgICAgICAgICAgICAgICBtaW4td2lkdGg6IDgwcHg7XG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAxMDAlO1xuICAgICAgICAgICAgICAgIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICAgICAgICAgICAgICAgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAuY29udGVudF9kaXYge1xuICAgICAgICAgICAgICAgIHBhZGRpbmctbGVmdDogMTBweDtcbiAgICAgICAgICAgICAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgICAgICAgICAgICAgIC5uYW1lIHtcbiAgICAgICAgICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdzZW1pLWJvbGQnO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC5zdGFyX2ZsZXgge1xuICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgICAgICAgICBjb2xvcjogb3JhbmdlO1xuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiA1cHg7XG4gICAgICAgICAgICAgICAgICAgIC8vIG1hcmdpbi1ib3R0b206IDEwcHg7XG5cbiAgICAgICAgICAgICAgICAgICAgaW9uLWljb24ge1xuICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiA1cHg7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE1cHg7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAucHJpY2VfZmxleCB7XG4gICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgICAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICBcbiAgICAgICAgICAgICAgICAgICAgLnByaWNlX2xibCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE1cHg7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAuZ3JlZW5fZGl2IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogNDBweDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOiA0MHB4O1xuICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgICAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBpb24taWNvbntcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IHdoaXRlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvcDogNTAlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxlZnQ6IDUwJTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLC01MCUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufSJdfQ== */");

/***/ }),

/***/ "./src/app/pages/hotel-map/hotel-map.page.ts":
/*!***************************************************!*\
  !*** ./src/app/pages/hotel-map/hotel-map.page.ts ***!
  \***************************************************/
/*! exports provided: HotelMapPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HotelMapPage", function() { return HotelMapPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");




let HotelMapPage = class HotelMapPage {
    constructor(navCrtl, router) {
        this.navCrtl = navCrtl;
        this.router = router;
        this.slideOpts = {
            slidesPerView: 1.2,
        };
        this.rate = 4;
        this.sliderImg = [
            'assets/imgs/nature1.jpg',
            'assets/imgs/nature2.jpg',
            'assets/imgs/nature3.jpg',
            'assets/imgs/nature4.jpg',
            'assets/imgs/nature5.jpg',
        ];
        this.autocompleteItems1 = [];
        this.autocompleteItems2 = [];
        this.latOri = -14.5931473;
        this.longOri = -56.1224024;
        this.latDest = -15.5931473;
        this.longDest = -56.1224024;
    }
    ngOnInit() {
        // this.loadMap(this.latOri, this.longOri, this.latDest, this.longDest);
    }
    onRateChange(eve) {
    }
    goToBack() {
        this.navCrtl.back();
    }
    loadMap(latOri, lngOri, latDest, lngDest) {
        var directionsService = new google.maps.DirectionsService;
        var directionsDisplay = new google.maps.DirectionsRenderer;
        directionsDisplay = new google.maps.DirectionsRenderer();
        var bounds = new google.maps.LatLngBounds;
        var origin1 = { lat: parseFloat(latOri), lng: parseFloat(lngOri) };
        var destinationA = { lat: latDest, lng: lngDest };
        var destinationIcon = 'https://chart.googleapis.com/chart?' +
            'chst=d_map_pin_letter&chld=D|FF0000|000000';
        var originIcon = 'https://chart.googleapis.com/chart?' +
            'chst=d_map_pin_letter&chld=O|FFFF00|000000';
        var map = new google.maps.Map(this.mapElement.nativeElement, {
            center: { lat: latOri, lng: lngOri },
            disableDefaultUI: true,
            zoom: 100
        });
        directionsDisplay.setMap(map);
        var geocoder = new google.maps.Geocoder;
        var service = new google.maps.DistanceMatrixService;
        service.getDistanceMatrix({
            origins: [origin1],
            destinations: [destinationA],
            travelMode: 'DRIVING',
            unitSystem: google.maps.UnitSystem.METRIC,
            avoidHighways: false,
            avoidTolls: false
        }, function (response, status) {
            if (status !== 'OK') {
                alert('Error was: ' + status);
            }
            else {
                var originList = response.originAddresses;
                var destinationList = response.destinationAddresses;
                var outputDiv = document.getElementById('output');
                // outputDiv.innerHTML = '';
                // deleteMarkers(markersArray);
                var showGeocodedAddressOnMap = function (asDestination) {
                    var icon = asDestination ? destinationIcon : originIcon;
                    return function (results, status) {
                        if (status === 'OK') {
                            map.fitBounds(bounds.extend(results[0].geometry.location));
                            /*markersArray.push(new google.maps.Marker({
                              map: map,
                              position: results[0].geometry.location,
                              icon: icon
                            }));*/
                        }
                        else {
                            alert('Geocode was not successful due to: ' + status);
                        }
                    };
                };
                directionsService.route({
                    origin: origin1,
                    destination: destinationA,
                    travelMode: 'DRIVING'
                }, function (response, status) {
                    if (status === 'OK') {
                        directionsDisplay.setDirections(response);
                    }
                    else {
                        window.alert('Directions request failed due to ' + status);
                    }
                });
                for (var i = 0; i < originList.length; i++) {
                    var results = response.rows[i].elements;
                    geocoder.geocode({ 'address': originList[i] }, showGeocodedAddressOnMap(false));
                    for (var j = 0; j < results.length; j++) {
                        geocoder.geocode({ 'address': destinationList[j] }, showGeocodedAddressOnMap(true));
                        // outputDiv.innerHTML += 'DE: ' + originList[i] + ' || PARA: ' + destinationList[j] +
                        //     '|| DISTÂNCIA: ' + results[j].distance.text + ' EM ' +
                        //     results[j].duration.text + '<br>';
                    }
                }
            }
        });
        // let latLng = new google.maps.LatLng(-34.9290, 138.6010);
        // let mapOptions = {
        //   center: latLng,
        //   zoom: 15,
        //   disableDefaultUI: true,
        //   mapTypeId: google.maps.MapTypeId.ROADMAP
        // }
        // this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
    }
    goToHotelDetail() {
        this.router.navigate(['/hotel-detail']);
    }
};
HotelMapPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] }
];
HotelMapPage.propDecorators = {
    mapElement: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['map', { static: true },] }]
};
HotelMapPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-hotel-map',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./hotel-map.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/hotel-map/hotel-map.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./hotel-map.page.scss */ "./src/app/pages/hotel-map/hotel-map.page.scss")).default]
    })
], HotelMapPage);



/***/ })

}]);
//# sourceMappingURL=pages-hotel-map-hotel-map-module-es2015.js.map